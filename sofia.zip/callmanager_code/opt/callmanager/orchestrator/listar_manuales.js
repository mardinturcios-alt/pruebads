'use strict';
require('dotenv').config({ path: '/etc/callmanager/orchestrator.env' });
const { GoogleAuth } = require('google-auth-library');

const PROJECT_ID = process.env.GCP_PROJECT_ID;
const DATASTORE_ID = 'callmanager-kb-v2'; // <--- EL ID REAL QUE DESCUBRIMOS

const auth = new GoogleAuth({
  scopes: ['https://www.googleapis.com/auth/cloud-platform']
});

async function verManuales() {
  try {
    console.log(`Extrayendo manuales del Data Store: ${DATASTORE_ID}...`);
    const client = await auth.getClient();
    const token  = await client.getAccessToken();

    // Endpoint oficial de Google para listar documentos
    const url = `https://discoveryengine.googleapis.com/v1/projects/${PROJECT_ID}/locations/global/collections/default_collection/dataStores/${DATASTORE_ID}/branches/0/documents`;

    const res = await fetch(url, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${token.token}`,
        'x-goog-user-project': PROJECT_ID,
      }
    });

    if (!res.ok) {
      console.error(`Error HTTP: ${res.status} - ${await res.text()}`);
      return;
    }

    const data = await res.json();
    const docs = data.documents || [];

    console.log(`\n📚 ¡Éxito! Encontré ${docs.length} documento(s) en la base de conocimientos:\n`);
    
    docs.forEach((doc, i) => {
      // Extraemos el título del JSON o el nombre del archivo si es PDF
      const title = doc.structData?.title || doc.name.split('/').pop();
      console.log(` ${i + 1}. ${title}`);
    });

  } catch (error) {
    console.error('Error conectando a GCP:', error.message);
  }
}

verManuales();
