'use strict';
const { STTStream }    = require('./sttStream');
const { GeminiAgent }  = require('./geminiAgent');
const { TTSClient }    = require('./ttsClient');
const { SessionStore } = require('./sessionStore');
const { PubSubClient } = require('./pubsubClient');
const { AriClient }    = require('./ariClient');
const { DB }           = require('./database'); // Ahora también tiene horarios
const { HelpdeskClient } = require('./helpdeskClient');

class CallSession {
  constructor({ callId, caller, lang, socket }) {
    this.callId  = callId;
    this.caller  = caller;
    this.lang    = lang;
    this.socket  = socket;

    this.stt     = new STTStream({ lang });
    this.agent   = new GeminiAgent({ callId });
    this.tts     = new TTSClient({ lang });
    this.ari     = new AriClient();
    this.helpdesk = new HelpdeskClient();

    this.processing = false;
    this.ended      = false;
    this.messages   = [];
    this.silenceTimer    = null;
    this.reminderSent    = false;

    this.ttsPlaying      = false;
    this.stopTTS         = false;
    this.ttsQueue        = [];

    this.SILENCE_REMIND  = 8000;
    this.SILENCE_HANGUP  = 15000;

    this.startTime = Date.now();
    this.funcionario = null;

    this.sessionData = {
      callId, callerNumber: caller, startedAt: new Date().toISOString(),
      status: 'active_ai', messages: [], escalationReason: null,
      agentId: null, summary: null, modoContingenciaTicket: false // NUEVO FLAG
    };
  }

  async start() {
    const numeroReal = await this.ari.getCallerNumber(this.callId);
    if (numeroReal !== 'unknown') {
      this.caller = numeroReal;
      this.sessionData.callerNumber = numeroReal;
    }

    console.log(`[Session ${this.callId}] Iniciando flujo para el teléfono/ext: ${this.caller}`);

    const funcionario = await DB.buscarPorTelefono(this.caller);

    if (funcionario) {
      console.log(`[Session] Funcionario reconocido: ${funcionario.nombre}`);
      this.funcionario = funcionario;

      this.sessionData.funcionario = funcionario.nombre;
      this.sessionData.area = funcionario.area;
      this.sessionData.correo = funcionario.correo;
      this.sessionData.jefe = funcionario.jefe;
      this.sessionData.peoplesoft_id = funcionario.peoplesoft_id;

      if (this.agent.setFuncionarioContext) {
        this.agent.setFuncionarioContext(funcionario, this.caller);
      }
    } else {
      console.log(`[Session] Teléfono desconocido. Sofía enrolará al usuario.`);
      if (this.agent.setFuncionarioContext) {
        this.agent.setFuncionarioContext(null, this.caller);
      }
    }

    await SessionStore.save(this.sessionData);
    this._lastTranscript = '';
    this._debounceTimer  = null;

    this.stt.onTranscript(async (text, isFinal) => {
      if (this.processing || this.ended || !text.trim()) return;

      if (this.ttsPlaying) {
        if (text.trim().length > 5) {
          this.stopTTS = true;
          this.ttsQueue = [];
          this.audioClock = null;
          this.ttsPlaying = false;
          console.log(`[Session ${this.callId}] 🛑 Interrupción inteligente detectada: "${text}"`);
        } else {
          return; 
        }
      }

      this._lastTranscript = text;
      this._resetSilenceTimer();
      if (this._debounceTimer) clearTimeout(this._debounceTimer);

      if (isFinal) {
        this.processing = true;
        try { await this.processUserTurn(text); }
        catch (e) { console.error(`[Session Error]`, e.message); }
        finally { this.processing = false; }
      } else {
        this._debounceTimer = setTimeout(async () => {
          if (this.processing || this.ended || !this._lastTranscript.trim()) return;
          this.processing = true;
          const t = this._lastTranscript;
          this._lastTranscript = '';
          try { await this.processUserTurn(t); }
          catch (e) { console.error(`[Session Error]`, e.message); }
          finally { this.processing = false; }
        }, 800);
      }
    });

    this.stt.start();

    const greeting = this.funcionario
        ? `Hola ${this.funcionario.nombre.split(' ')[0]}. Le Saluda Sofía del Centro de Atención al Usuario.`
        : 'Hola, gracias por llamar al Centro de Atención al Usuario. Le Saluda Sofía, ¿con quién tengo el gusto?';
    await this.speak(greeting);
    this.addMessage('assistant', greeting);
    this._resetSilenceTimer();
  }

  onAudioFrame(audioBuffer) {
    if (this.ended) return;

    if (!this.processing) {
      this.stt.sendAudio(audioBuffer);
    } else {
      this.stt.sendAudio(Buffer.alloc(audioBuffer.length, 0));
    }
  }

  _sendNextFrame() {
    if (!this.ttsQueue || this.ttsQueue.length === 0 || this.stopTTS || this.ended) return;

    let currentBuffer = this.ttsQueue[0];
    const FRAME_SIZE = 320;

    if (currentBuffer.length === 0) {
      this.ttsQueue.shift();
        if (this.ttsQueue.length === 0) {
            this.ttsPlaying = false;
        if (this.audioClock) { clearInterval(this.audioClock); this.audioClock = null; } 
        return;
      }
      currentBuffer = this.ttsQueue[0];
    }

    const chunk = currentBuffer.slice(0, FRAME_SIZE);
    this.ttsQueue[0] = currentBuffer.slice(FRAME_SIZE);

    let frame = chunk;
    if (chunk.length < FRAME_SIZE) {
      frame = Buffer.alloc(FRAME_SIZE);
      chunk.copy(frame);
    }
    const header = Buffer.alloc(3);
    header[0]    = 0x10;
    header.writeUInt16BE(FRAME_SIZE, 1);

    try {
      if (this.socket.writable) this.socket.write(Buffer.concat([header, frame]));
    } catch(_) {}
  }

async processUserTurn(text) {
    console.log(`[Session ${this.callId}] Cliente: "${text}"`);

    // 🔥 NUEVO: Si estamos en modo de creación de ticket nocturno
    if (this.sessionData.modoContingenciaTicket) {

// FILTRO DE PACIENCIA: Si el usuario dijo menos de 15 letras
       if (text.trim().length < 15) {
           console.log(`[Session ${this.callId}] Texto muy corto para ticket: "${text}"`);
           await this.speak("Por favor, bríndeme un poco más de detalle sobre el problema que presenta para registrar el requerimiento correctamente.");
           return; // Pausamos y esperamos a que el usuario hable más
       }

       console.log(`[Session ${this.callId}] Procesando creación de ticket en Helpdesk oficial fuera de horario.`);
       
       // 👇 ENVIAMOS LOS DATOS DIRECTO A TU API REST
       const helpdeskRes = await this.helpdesk.createCase({
           asunto: 'Soporte Fuera de Horario - Reporte automatizado',
           descripcion: text,
           nombre: this.funcionario ? this.funcionario.nombre : 'Usuario Desconocido',
           area: this.funcionario ? this.funcionario.area : 'No indicada',
           jefe: this.funcionario ? this.funcionario.jefe : 'No indicado',
           callId: this.callId
       });

       if (helpdeskRes && helpdeskRes.caseId) {
          await this.speak(`Perfecto, he registrado su requerimiento bajo el número ${helpdeskRes.caseId}. Un técnico lo revisará a primera hora hábil. Gracias por contactar a Davivienda, que pase un excelente día.`);
       } else {
          await this.speak("Lo lamento, hubo un inconveniente al generar su requerimiento. Por favor, comuníquese más tarde.");
       }
       await this.sleep(13000);
       this.terminate();
       return;
    }

    // FLUJO NORMAL
    const decision = await this.agent.process(text, this.messages);
    console.log(`[Session ${this.callId}] Decisión: ${decision.action}`);

    this.addMessage('user', text);
    await SessionStore.addMessage(this.callId, 'user', text);

    if (decision.action === 'respond') {
      await this.speak(decision.text);
      this.addMessage('assistant', decision.text);
      await SessionStore.addMessage(this.callId, 'assistant', decision.text);
    } else if (decision.action === 'escalate') {
      await this.escalate(decision.reason || 'Derivado por IA');
    } else if (decision.action === 'end') {
      await this.speak(decision.text || 'Gracias por comunicarse. Hasta luego.');
      await this.sleep(2500);
      this.terminate();
    }
  }

  _resetSilenceTimer() {
    if (this.silenceTimer) clearTimeout(this.silenceTimer);
    this.reminderSent = false;
    this.silenceTimer = setTimeout(async () => {
      if (this.ended || this.processing) return;
      if (!this.reminderSent) {
        this.reminderSent = true;
        await this.speak('¿Sigue ahí? ¿En qué le puedo ayudar?');
        this.silenceTimer = setTimeout(async () => {
          if (this.ended) return;
          await this.speak('No escucho respuesta. Que tenga buen día.');
          await this.sleep(2500);
          this.end();
        }, this.SILENCE_HANGUP);
      }
    }, this.SILENCE_REMIND);
  }

  async speak(text) {
    if (!text || this.ended) return;
    try {
      this.stopTTS = false;
      if (this.silenceTimer) { clearTimeout(this.silenceTimer); this.silenceTimer = null; }

      const audioBuffer = await this.tts.synthesize(text);
      console.log(`[TTS] "${text.replace(/\n/g, ' ')}" → ${audioBuffer.length} bytes`);

      if (!this.ttsQueue) this.ttsQueue = [];
      this.ttsQueue.push(audioBuffer);
      this.ttsPlaying = true;

      if (!this.audioClock) {
        this.audioClock = setInterval(() => {
          this._sendNextFrame();
        }, 20); 
      }
    } catch (e) {
      console.error(`[Session Error] TTS error:`, e.message);
    }
  }

  // 🔥 NUEVO: Función escalate modificada para validar el horario
  async escalate(reason) {
    if (this.ended) return;
    console.log(`[Session ${this.callId}] Solicitud de Escalación. Motivo: ${reason}`);

    // 1. Validar el Cerebro de Horarios
    const estadoHorario = await DB.verificarDisponibilidadAgentes();

    // 2. FUERA DE HORARIO: Plan de contingencia
    if (!estadoHorario.disponible) {
      console.log(`[Session ${this.callId}] Escalación bloqueada: ${estadoHorario.motivo}`);
      this.sessionData.modoContingenciaTicket = true;
      
      let mensajeContingencia = "En este momento nuestros agentes de soporte se encuentran fuera del horario de atención. ";
      if (estadoHorario.motivo === 'asueto') {
        mensajeContingencia = `En este momento nuestros agentes no están disponibles debido a que hoy es ${estadoHorario.detalle}. `;
      }
      mensajeContingencia += "¿Le gustaría indicarme cuál es su inconveniente para crear un requerimiento técnico y que lo revisen a primera hora del próximo día hábil?";
      
      await this.speak(mensajeContingencia);
      this.addMessage('assistant', mensajeContingencia);
      return; // Detenemos aquí, NO transferimos a Asterisk
    }

    // 3. DENTRO DE HORARIO: Transferencia normal
    console.log(`[Session ${this.callId}] Agentes disponibles. Iniciando transferencia...`);
    await this.speak('Un momento por favor, le voy a transferir con un técnico.');

    const summary = await this.agent.summarize(this.messages);
    this.sessionData.summary = summary;

    await SessionStore.update(this.callId, {
      status: 'escalated',
      escalationReason: reason,
      summary: summary,
      intencion_detectada: summary
    });

    await PubSubClient.publish({ callId: this.callId, caller: this.caller, summary, reason, timestamp: new Date().toISOString() });

    try { await this.transferToAgent('9000'); }
    catch (e) { this.terminate(); }
  }

  async transferToAgent(agentExtension) {
    console.log(`[Session ${this.callId}] Iniciando transferencia a ext.${agentExtension}`);
    await SessionStore.update(this.callId, { status: 'with_agent', agentId: agentExtension });

    try {
      this.processing = true;
      if (this.stt) this.stt.stop();
      if (this.stt) {
        this.stt.stop();
        if (typeof this.stt.destroy === 'function') this.stt.destroy();
        this.stt = null; // 🚀 Liberamos a Google de la memoria
      }
      if (this.silenceTimer) clearTimeout(this.silenceTimer);

      await this.ari.transferCall(this.callId, agentExtension, this.sessionData.summary);
      await this._registrarMetricasLocal('Transferida a Humano', true);
      
      if (global.io) {
        global.io.emit('nueva_transferencia', {
          agente_destino: agentExtension,
          telefono_cliente: this.caller,
          intencion: this.sessionData.summary || 'Consulta general',
          funcionario: this.funcionario ? this.funcionario.nombre : 'Usuario Desconocido',
          callId: this.callId
        });
        console.log(`[WebSocket] 📡 Alerta enviada al Agent Desktop para ext. ${agentExtension}`);
      }
      this.ended = true;
    } catch (e) {
      console.error(`[Session Error] AMI:`, e.message);
      this.processing = false;
      this.ended = false;
    }
  }

  async _registrarMetricasLocal(evaluacion, transferida) {
    try {
      const tiempoSofiaSegundos = Math.round((Date.now() - this.startTime) / 1000);
      const peoplesoftId = this.funcionario ? this.funcionario.peoplesoft_id : 'Desconocido';
      const intencion = this.sessionData.summary || 'Consulta o gestión general';

      await DB.registrarLlamada({
        callId: this.callId, peoplesoftId: peoplesoftId, telefono: this.caller,
        intencion: intencion, ticketId: null, evaluacion: evaluacion,
        transferida: transferida ? 1 : 0, tiempoSofia: tiempoSofiaSegundos
      });
      console.log(`[Metricas] Guardadas en DB local. Duración IA: ${tiempoSofiaSegundos}s.`);
    } catch (err) {
      console.error(`[Metricas] Error al registrar:`, err.message);
    }
  }

  async terminate() { this.end(); }

  async end() {
    if (this.ended) return;
    this.ended = true;
    await this._registrarMetricasLocal('Atendida por IA', false);
    if (this.silenceTimer) clearTimeout(this.silenceTimer);
    this.stt.stop();
    await SessionStore.update(this.callId, { status: 'ended', endedAt: new Date().toISOString() }).catch(() => {});
    console.log(`[Session ${this.callId}] Terminada`);
  }

  addMessage(role, content) { this.messages.push({ role, content, ts: new Date().toISOString() }); }
  sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
}

module.exports = { CallSession };
