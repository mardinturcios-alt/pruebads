'use strict';
const { GoogleGenerativeAI } = require('@google/generative-ai');
const { KnowledgeBase }      = require('./knowledgeBase');
const { HelpdeskClient }     = require('./helpdeskClient');
const { DB }                 = require('./database');
const { publicarSolicitudAutogestion } = require('./gcpPubSub');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

let BASE_SYSTEM_PROMPT = ``;

const TOOLS = [{
  functionDeclarations: [
    {
      name: 'registrar_nuevo_funcionario',
      description: 'Guarda o actualiza los datos de un funcionario en la base de datos local.',
      parameters: {
        type: 'object',
        properties: {
          peoplesoft_id: { type: 'string' },
          nombre:        { type: 'string' },
          correo:        { type: 'string' },
          area:          { type: 'string' },
          jefe:          { type: 'string' }
        },
        required: ['peoplesoft_id', 'nombre', 'correo', 'area', 'jefe']
      }
    },
    {
      name: 'enviar_enlace_autogestion',
      description: 'Envía un enlace seguro de autogestión. Úsalo SOLO si la Base de Conocimientos lo indica.',
      parameters: {
        type: 'object',
        properties: {
          tipo_gestion: { type: 'string' },
          sistema: { type: 'string' }
        },
        required: ['tipo_gestion', 'sistema']
      }
    },
    {
      name: 'buscar_informacion',
      description: 'Busca información en la base de conocimientos.',
      parameters: {
        type: 'object',
        properties: { query: { type: 'string' } },
        required: ['query']
      }
    },
    {
      name: 'crear_caso',
      description: 'Crea un ticket de soporte.',
      parameters: {
        type: 'object',
        properties: {
          asunto:        { type: 'string' },
          descripcion:   { type: 'string' },
          nombre:        { type: 'string' },
          area:          { type: 'string' },
          jefe:          { type: 'string' },
          peoplesoft_id: { type: 'string' }
        },
        required: ['asunto', 'descripcion']
      }
    },
    {
      name: 'escalar_agente',
      description: 'Escala la llamada a un humano.',
      parameters: {
        type: 'object',
        properties: { razon: { type: 'string' } },
        required: ['razon']
      }
    }
  ]
}];

const ESCALATION_PHRASES = [
  'agente', 'hablar con persona', 'operador', 'representante', 'fraude',
  'transferir', 'transfiéreme', 'pásame con', 'ingeniero', 'soporte técnico'
];

class GeminiAgent {
  constructor({ callId }) {
    this.callId   = callId;
    this.kb       = new KnowledgeBase();
    this.helpdesk = new HelpdeskClient();
    this.telefono = 'Desconocido'; 
    this._initModel(BASE_SYSTEM_PROMPT.replace('{{CONTEXTO_USUARIO}}', 'Analizando identidad...'));
  }

  _initModel(systemInstruction) {
    this.model = genAI.getGenerativeModel({
      model: 'gemini-2.5-flash',
      systemInstruction: systemInstruction,
      tools: TOOLS,
      generationConfig: { temperature: 0.3, maxOutputTokens: 300 }
    });
  }

async setFuncionarioContext(funcionario, telefono) {
    if (telefono) this.telefono = telefono;
    let contextoDinamico = '';

    if (funcionario) {
      contextoDinamico = `[USUARIO RECONOCIDO]
Nombre: ${funcionario.nombre}
ID PeopleSoft: ${funcionario.peoplesoft_id}
Área: ${funcionario.area}
Jefe: ${funcionario.jefe}
Correo: ${funcionario.correo}

REGLA DE CONFIRMACIÓN OBLIGATORIA:
1. Para tu PRIMERA respuesta, hazle UNA sola pregunta rápida para confirmar si sigue estando en el área registrada (Ej: "¿nos llama siempre de ${funcionario.area}?"). NUNCA repitas la palabra "Bienvenido" ni lo saludes, porque el sistema ya lo hizo.
2. Si te dice que SÍ: Pregúntale en qué le puedes ayudar hoy.
3. Si te dice que NO: Pídele su nueva área y jefe, y ejecuta "registrar_nuevo_funcionario".`;
    } else {
      contextoDinamico = `[USUARIO DESCONOCIDO]
ESTADO: NO REGISTRADO.
ACCIÓN OBLIGATORIA: Tienes ESTRICTAMENTE PROHIBIDO ayudarle o crear tickets todavía.
1. Salúdalo diciendo que necesitas registrarlo.
2. Pídele: ID de PeopleSoft, Nombre, Correo, Área y Jefe.
3. Al tenerlos, ejecuta "registrar_nuevo_funcionario".`;
    }

    // Traemos el prompt fresco de la BD
    BASE_SYSTEM_PROMPT = await DB.obtenerPromptIA();

    const nuevoPrompt = BASE_SYSTEM_PROMPT.replace('{{CONTEXTO_USUARIO}}', contextoDinamico);
    this._initModel(nuevoPrompt);
  }

  async process(text, history) {
    const lower = text.toLowerCase();
    if (ESCALATION_PHRASES.some(p => lower.includes(p))) {
      return { action: 'escalate', reason: 'Solicitud directa del cliente' };
    }

    try {
      let kbContext = '';
      const kbResult = await this.kb.search(text);
      if (kbResult.found && kbResult.summary) {
        kbContext = `[INFO DE BASE DE CONOCIMIENTOS]\n${kbResult.summary}\n[FIN DE INFO]\n\n`;
      }

const textWithContext = `${kbContext}Usuario dice: "${text}"`;
      
      // --- INICIO DEL FILTRO ESTRICTO DE HISTORIAL ---
      const filteredHistory = [];
      const recentHistory = history.slice(-10);
      
      // 1. Buscar el primer mensaje del usuario (ignorar saludos iniciales de Sofía)
      let startIdx = 0;
      while (startIdx < recentHistory.length && recentHistory[startIdx].role !== 'user') {
        startIdx++;
      }
      
      // 2. Construir historial alternado para evitar bloqueos de Gemini
      for (let i = startIdx; i < recentHistory.length; i++) {
        const mappedRole = recentHistory[i].role === 'user' ? 'user' : 'model';
        
        if (filteredHistory.length === 0 || filteredHistory[filteredHistory.length - 1].role !== mappedRole) {
          filteredHistory.push({ role: mappedRole, parts: [{ text: recentHistory[i].content }] });
        } else {
          // Si hay dos roles iguales seguidos, los concatenamos
          filteredHistory[filteredHistory.length - 1].parts[0].text += `\n${recentHistory[i].content}`;
        }
      }
      // --- FIN DEL FILTRO ESTRICTO ---

      const chat = this.model.startChat({ history: filteredHistory });

      let response = await chat.sendMessage(textWithContext);

let maxIter = 5;
      while (maxIter-- > 0) {
        const candidate = response.response.candidates?.[0];
        const fnCalls   = candidate?.content?.parts?.filter(p => p.functionCall) || [];
        if (fnCalls.length === 0) break;

        const escalateCall = fnCalls.find(p => p.functionCall.name === 'escalar_agente');
        if (escalateCall) {
          // --- INICIO DE LA MODIFICACIÓN ---
          const razonEscalamiento = escalateCall.functionCall.args?.razon || 'Derivado por IA';
          
          // Registramos la métrica como ESCALADA (transferida: 1)
          DB.registrarLlamada({
            callId: this.callId,
            peoplesoftId: null, // Si tienes esta info en el contexto, úsala
            telefono: this.telefono,
            intencion: razonEscalamiento,
            ticketId: null,
            evaluacion: "Escalado a agente humano",
            transferida: 1, // ¡AQUÍ ESTÁ LA CLAVE PARA EL DASHBOARD!
            tiempoSofia: 0 // Puedes calcular el tiempo si llevas un registro en this
          }).catch(err => console.error("Error registrando escalamiento:", err));
          // --- FIN DE LA MODIFICACIÓN ---

          return { action: 'escalate', reason: razonEscalamiento };
        }

        const fnResponses = await Promise.all(fnCalls.map(async part => {
          const { name, args } = part.functionCall;
          const result = await this.executeTool(name, args);
          return { functionResponse: { name, response: { result } } };
        }));

        response = await chat.sendMessage(fnResponses);
      }

      let responseText = response.response.text().trim();
      if (!responseText || responseText.length < 5) {
        responseText = "¿Me podría repetir la información por favor?";
      }

      return { action: 'respond', text: responseText };
    } catch (e) {
      console.error(`[Gemini] Error:`, e.message);
      return { action: 'escalate', reason: 'Error en procesamiento IA' };
    }
  }

  async executeTool(name, args) {
    console.log(`[Gemini ${this.callId}] Tool: ${name}`, args);
    switch (name) {
      case 'buscar_informacion': return await this.kb.search(args.query);
      case 'consultar_caso':     return await this.helpdesk.getCase(args.numero_caso, args.numero_cliente);
      
      case 'registrar_nuevo_funcionario': {
        const exito = await DB.guardarFuncionario(args.peoplesoft_id, this.telefono, args.nombre, args.correo, args.area, args.jefe);
        return { exito, mensaje: exito ? 'Guardado exitosamente.' : 'Error al guardar.' };
      }

      case 'enviar_enlace_autogestion': {
        const funcionario = await DB.buscarPorTelefono(this.telefono);
        if (!funcionario || !funcionario.correo) {
          return { error: "No tengo el correo registrado." };
        }
        await publicarSolicitudAutogestion({
          peoplesoft_id: funcionario.peoplesoft_id,
          nombre: funcionario.nombre,
          correo: funcionario.correo,
          area: funcionario.area,
          tipo_gestion: args.tipo_gestion,
          sistema: args.sistema
        });
        return { status: `Enlace enviado exitosamente a ${funcionario.correo}` };
      }

      case 'crear_caso': {
        return await this.helpdesk.createCase({ ...args, callId: this.callId });
      }
      
      case 'escalar_agente': return args;
      default: return { error: `Herramienta desconocida: ${name}` };
    }
  }

  async summarize(messages) {
    try {
      const model = genAI.getGenerativeModel({ model: 'gemini-2.5-flash' });
      const conversation = messages.map(m => `${m.role === 'user' ? 'Cliente' : 'Bot'}: ${m.content}`).join('\n');
      const result = await model.generateContent(`Resume brevemente:\n${conversation}\nResumen:`);
      return result.response.text().trim();
    } catch (e) {
      return 'No se pudo generar resumen automático.';
    }
  }
}

module.exports = { GeminiAgent };
