'use strict';
// database.js — Sistema de Persistencia y Métricas (Migrado a PostgreSQL)

const { Pool } = require('pg');

// Configuración de la conexión a tu base de datos Davitel
const pool = new Pool({
  user: 'asterisk_user',
  host: 'localhost',
  database: 'davitel_db',
  password: 'Asterisk2026*',
  port: 5432,
});

// Inicialización de tablas de forma asíncrona
function initDatabase() {
  return new Promise(async (resolve, reject) => {
    try {
      // 👥 TABLA 1: Directorio de Funcionarios
      await pool.query(`
        CREATE TABLE IF NOT EXISTS usuarios (
          id SERIAL PRIMARY KEY,
          numero_telefono VARCHAR(20) UNIQUE NOT NULL,
          nombre VARCHAR(100),
          area VARCHAR(80),
          peoplesoft VARCHAR(30) UNIQUE,
          jefe VARCHAR(100),
          correo VARCHAR(100),
          fecha_registro TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // 📊 TABLA 2: Métricas End-to-End
      await pool.query(`
        CREATE TABLE IF NOT EXISTS metricas_llamadas (
          call_id TEXT PRIMARY KEY,
          peoplesoft_id TEXT,
          telefono TEXT,
          intencion_detectada TEXT,
          ticket_creado_id TEXT,
          sofia_evaluacion TEXT,
          transferida_a_agente INTEGER DEFAULT 0,
          tiempo_sofia_seg INTEGER DEFAULT 0,
          tiempo_espera_cola_seg INTEGER DEFAULT 0,
          tiempo_atencion_agente_seg INTEGER DEFAULT 0,
          fecha_hora TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // 🆕 NUEVO: TABLA 3: Control de Directrices en Vivo (Prompt Ops)
      await pool.query(`
        CREATE TABLE IF NOT EXISTS configuracion_sistema (
          clave VARCHAR(50) PRIMARY KEY,
          valor TEXT NOT NULL,
          actualizado_el TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
        )
      `);

      // 🆕 NUEVO: Semilla inicial para que el sistema tenga directrices desde el día uno
      await pool.query(`
        INSERT INTO configuracion_sistema (clave, valor)
        VALUES ('sofia_system_prompt', 'Eres Sofía, la asistente virtual inteligente de Davivienda. Tu objetivo es saludar cordialmente, entender la solicitud del usuario de forma ágil y registrar los datos. CRÍTICO: Al finalizar la llamada, resume el motivo o intención de la llamada en un formato ultra-corto de máximo 3 o 4 palabras (Ej: Consulta de Saldo, Soporte Técnico, Reclamo de Tarjeta). No uses oraciones largas.')
        ON CONFLICT (clave) DO NOTHING
      `);

      console.log(`[Database] Tablas de negocio e infraestructura listas en PostgreSQL (davitel_db)`);
      resolve();
    } catch (err) {
      console.error('[Database] Error inicializando tablas:', err.message);
      reject(err);
    }
  });
}

// Funciones de ayuda con Promesas para el Orquestador
const DB = {
  init: initDatabase,

  buscarPorTelefono: async (telefono) => {
    try {
      const sql = `SELECT peoplesoft AS peoplesoft_id, numero_telefono AS telefono, nombre, correo, area, jefe
                   FROM usuarios WHERE numero_telefono = $1`;
      const res = await pool.query(sql, [telefono]);
      return res.rows[0] || null;
    } catch (err) {
      console.error('[DB] Error buscando teléfono:', err.message);
      return null;
    }
  },

  guardarFuncionario: async (peoplesoft, telefono, nombre, correo, area, jefe) => {
    try {
      const sql = `
        INSERT INTO usuarios (peoplesoft, numero_telefono, nombre, correo, area, jefe)
        VALUES ($1, $2, $3, $4, $5, $6)
        ON CONFLICT (numero_telefono)
        DO UPDATE SET
          peoplesoft = EXCLUDED.peoplesoft,
          nombre = EXCLUDED.nombre,
          correo = EXCLUDED.correo,
          area = EXCLUDED.area,
          jefe = EXCLUDED.jefe
      `;
      await pool.query(sql, [peoplesoft, telefono, nombre, correo, area, jefe]);
      return true;
    } catch (err) {
      console.error('[DB] Error guardando funcionario:', err.message);
      return false;
    }
  },

  registrarLlamada: async (data) => {
    try {
      const sql = `
        INSERT INTO metricas_llamadas
        (call_id, peoplesoft_id, telefono, intencion_detectada, ticket_creado_id, sofia_evaluacion, transferida_a_agente, tiempo_sofia_seg)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT (call_id) DO UPDATE SET
          peoplesoft_id = EXCLUDED.peoplesoft_id,
          intencion_detectada = EXCLUDED.intencion_detectada,
          ticket_creado_id = EXCLUDED.ticket_creado_id,
          sofia_evaluacion = EXCLUDED.sofia_evaluacion,
          transferida_a_agente = EXCLUDED.transferida_a_agente,
          tiempo_sofia_seg = EXCLUDED.tiempo_sofia_seg
      `;
      await pool.query(sql, [
        data.callId, data.peoplesoftId, data.telefono, data.intencion,
        data.ticketId, data.evaluacion, data.transferida, data.tiempoSofia
      ]);
    } catch (err) {
      console.error('[DB] Error guardando métricas:', err.message);
    }
  },

  // 🚀 VÍA RÁPIDA: Wallboard en Vivo (Exclusivo para el día de HOY)
  obtenerResumenMetricas: async () => {
    try {
      const resTotalHist = await pool.query("SELECT COUNT(DISTINCT uniqueid) AS count FROM cdr");
      const totalHistorico = parseInt(resTotalHist.rows[0].count || 0);

      // 🚀 CLASIFICACIÓN DE DESTINO FINAL CON DETECTOR DE SALTOS
      const queryHoy = `
        WITH DestinoLlamadas AS (
          SELECT
            uniqueid,
            -- ¿Un humano contestó en algún momento de la llamada?
            MAX(CASE WHEN disposition = 'ANSWERED' AND (dstchannel LIKE '%PJSIP%' OR dstchannel LIKE '%SIP%') THEN 1 ELSE 0 END) as atendida_por_humano,
            -- ¿La llamada tocó la cola de espera?
            MAX(CASE WHEN lastapp IN ('Queue', 'AppQueue') OR dst = '9000' THEN 1 ELSE 0 END) as toco_cola,
            -- ¿La llamada hizo timbrar el teléfono físico de algún agente?
            MAX(CASE WHEN dstchannel LIKE '%PJSIP%' OR dstchannel LIKE '%SIP%' THEN 1 ELSE 0 END) as timbro_agente,
            -- 🔍 CONTADOR DE SALTOS: Cuenta cuántos intentos fallidos acumuló esa misma llamada
            SUM(CASE WHEN disposition IN ('NO ANSWER', 'BUSY', 'FAILED') AND (dstchannel LIKE '%PJSIP%' OR dstchannel LIKE '%SIP%') THEN 1 ELSE 0 END) as intentos_fallidos_agentes,
            MAX(duration) as duracion_llamada
          FROM cdr
          WHERE start::date = CURRENT_DATE
          GROUP BY uniqueid
        )
        SELECT
          COUNT(*) as llamadas_hoy,
          COALESCE(SUM(atendida_por_humano), 0) as atendidas_humanos,
          COALESCE(SUM(CASE WHEN atendida_por_humano = 0 AND toco_cola = 1 THEN 1 ELSE 0 END), 0) as abandonos_cola,
          COALESCE(SUM(CASE WHEN atendida_por_humano = 0 AND toco_cola = 0 AND timbro_agente = 1 THEN 1 ELSE 0 END), 0) as perdidas_agentes,
          COALESCE(SUM(CASE WHEN atendida_por_humano = 0 AND toco_cola = 0 AND timbro_agente = 0 THEN 1 ELSE 0 END), 0) as resueltas_ia,
          -- 🔍 Si una llamada acumuló al menos 1 intento fallido pero AL FINAL un humano la atendió, significa que SALTÓ
          COALESCE(SUM(CASE WHEN atendida_por_humano = 1 AND intentos_fallidos_agentes > 0 THEN 1 ELSE 0 END), 0) as total_saltos,
          COALESCE(AVG(duracion_llamada), 0) as tiempo_promedio
        FROM DestinoLlamadas;
      `;

      const resHoy = await pool.query(queryHoy);
      const metricsHoy = resHoy.rows[0];

      const total_entrantes = parseInt(metricsHoy.llamadas_hoy || 0);
      const atendidas_humanos = parseInt(metricsHoy.atendidas_humanos || 0);
      const abandonos_cola = parseInt(metricsHoy.abandonos_cola || 0);
      const perdidas_agentes = parseInt(metricsHoy.perdidas_agentes || 0);
      const resueltas_ia = parseInt(metricsHoy.resueltas_ia || 0);
      const total_saltos = parseInt(metricsHoy.total_saltos || 0);

      const tasa_resolucion = total_entrantes > 0 ? Math.round((resueltas_ia / total_entrantes) * 100) : 0;

      // 👥 Estadísticas individuales de los Agentes (Para ver a quién se le saltó)
      const queryStatsAgentes = `
        SELECT
          SPLIT_PART(SPLIT_PART(dstchannel, '-', 1), '/', 2) as extension,
          COUNT(DISTINCT uniqueid) as recibidas,
          COUNT(DISTINCT CASE WHEN disposition = 'ANSWERED' THEN uniqueid END) as contestadas,
          -- ¡Métrica quirúrgica! Aquí se acumula la llamada perdida individual de cada agente flojo que no contestó
          COUNT(DISTINCT CASE WHEN disposition IN ('NO ANSWER', 'BUSY', 'FAILED') THEN uniqueid END) as perdidas
        FROM cdr
        WHERE start::date = CURRENT_DATE
          AND dstchannel IS NOT NULL
          AND dstchannel != ''
        GROUP BY extension;
      `;
      const resStatsAgentes = await pool.query(queryStatsAgentes);

      return {
        kpis: {
          total: total_entrantes,
          total_historico: totalHistorico,
          llamadas_hoy: total_entrantes,
          resueltas_ia: resueltas_ia,
          atendidas_humanos: atendidas_humanos,
          perdidas_agentes: perdidas_agentes,
          tiempo_promedio: Math.round(parseFloat(metricsHoy.tiempo_promedio || 0)),
          tasa_resolucion: tasa_resolucion,
          tasaResolucionIA: tasa_resolucion,
          abandonos_cola: abandonos_cola,
          abandonadas: abandonos_cola,
          total_saltos: total_saltos
        },
        statsAgentes: resStatsAgentes.rows
      };
    } catch (err) {
      console.error('[DB] Error en obtenerResumenMetricas:', err);
      throw err;
    }
  },

  // 📚 VÍA PESADA: Módulo Histórico Completo (Filtro por Fechas para Todo el Panel)
  obtenerMetricasHistoricas: async (startDate, endDate) => {
    try {
      const filtroFecha = `start >= '${startDate} 00:00:00' AND start <= '${endDate} 23:59:59'`;
      const resTotalHist = await pool.query("SELECT COUNT(DISTINCT uniqueid) AS count FROM cdr");
      const totalHistorico = parseInt(resTotalHist.rows[0].count || 0);

      // 1. Consulta de KPIs del Período
      const queryHist = `
        WITH DestinoLlamadas AS (
          SELECT
            uniqueid,
            MAX(CASE WHEN disposition = 'ANSWERED' AND (dstchannel LIKE '%PJSIP%' OR dstchannel LIKE '%SIP%') THEN 1 ELSE 0 END) as atendida_por_humano,
            MAX(CASE WHEN lastapp IN ('Queue', 'AppQueue') OR dst = '9000' THEN 1 ELSE 0 END) as toco_cola,
            MAX(CASE WHEN dstchannel LIKE '%PJSIP%' OR dstchannel LIKE '%SIP%' THEN 1 ELSE 0 END) as timbro_agente,
            MAX(duration) as duracion_llamada
          FROM cdr
          WHERE ${filtroFecha}
          GROUP BY uniqueid
        )
        SELECT
          COUNT(*) as llamadas_hoy,
          COALESCE(SUM(atendida_por_humano), 0) as atendidas_humanos,
          COALESCE(SUM(CASE WHEN atendida_por_humano = 0 AND toco_cola = 1 THEN 1 ELSE 0 END), 0) as abandonos_cola,
          COALESCE(SUM(CASE WHEN atendida_por_humano = 0 AND toco_cola = 0 AND timbro_agente = 1 THEN 1 ELSE 0 END), 0) as perdidas_agentes,
          COALESCE(SUM(CASE WHEN atendida_por_humano = 0 AND toco_cola = 0 AND timbro_agente = 0 THEN 1 ELSE 0 END), 0) as resueltas_ia,
          COALESCE(AVG(duracion_llamada), 0) as tiempo_promedio
        FROM DestinoLlamadas;
      `;
      const resHoy = await pool.query(queryHist);
      const metricsHoy = resHoy.rows[0];

      const total_entrantes = parseInt(metricsHoy.llamadas_hoy || 0);
      const atendidas_humanos = parseInt(metricsHoy.atendidas_humanos || 0);
      const abandonos_cola = parseInt(metricsHoy.abandonos_cola || 0);
      const resueltas_ia = parseInt(metricsHoy.resueltas_ia || 0);
      const tasa_resolucion = total_entrantes > 0 ? Math.round((resueltas_ia / total_entrantes) * 100) : 0;

      // 2. Gráfico de Volumen de Llamadas por Usuario/Extensión (Histórico)
      const resIntenciones = await pool.query(`
        SELECT
          COALESCE(u.nombre, 'Ext. ' || c.src) AS intencion,
          COUNT(DISTINCT c.uniqueid) AS total
        FROM cdr c
        LEFT JOIN usuarios u ON u.numero_telefono = c.src
        WHERE c.start >= '${startDate} 00:00:00' AND c.start <= '${endDate} 23:59:59'
          AND c.src IS NOT NULL AND c.src <> ''
        GROUP BY u.nombre, c.src
        ORDER BY total DESC
        LIMIT 7
      `);
      const intencionesData = resIntenciones.rows.map(row => ({
        intencion: row.intencion,
        total: parseInt(row.total)
      }));

      // 3. Evaluaciones y Sentimiento (Veredicto IA)
      const resEvaluacion = await pool.query(`
        SELECT COALESCE(sofia_evaluacion, 'Atención Estándar') AS evaluacion, COUNT(*) AS total
        FROM metricas_llamadas
        WHERE fecha_hora >= '${startDate} 00:00:00' AND fecha_hora <= '${endDate} 23:59:59'
        GROUP BY sofia_evaluacion ORDER BY total DESC LIMIT 5
      `);
      const evaluacionData = resEvaluacion.rows.map(row => ({ evaluacion: row.evaluacion, total: parseInt(row.total) }));

// 3. Tabla de CDR Histórico Detallado
      const resCdr = await pool.query(`
        SELECT c.uniqueid, c.start as fecha, c.src as origen, c.dst as destino, c.duration as duracion_segundos, c.disposition as estado,
               COALESCE(u.nombre, SPLIT_PART(SPLIT_PART(c.dstchannel, '-', 1), '/', 2)) as agente_humano
        FROM cdr c LEFT JOIN usuarios u ON u.numero_telefono = SPLIT_PART(SPLIT_PART(c.dstchannel, '-', 1), '/', 2)
        WHERE ${filtroFecha} ORDER BY c.start DESC LIMIT 500
      `);
      return {
        kpis: {
          total: total_entrantes, total_historico: totalHistorico, llamadas_hoy: total_entrantes,
          resueltas_ia: resueltas_ia, atendidas_humanos: atendidas_humanos,
          tiempo_promedio: Math.round(parseFloat(metricsHoy.tiempo_promedio || 0)),
          tasa_resolucion: tasa_resolucion, abandonos_cola: abandonos_cola
        },
        intenciones: intencionesData,
        evaluacion: evaluacionData,
        cdr: resCdr.rows
      };
    } catch (err) {
      console.error('[DB] Error en obtenerMetricasHistoricas:', err);
      throw err;
    }
  },

// 2. Historial CDR restaurado
  obtenerHistorialCDR: async () => {
    try {
      const sql = `
        SELECT
          c.uniqueid,
          c.start as fecha,
          c.src as origen,
          c.dst as destino,
          c.duration as duracion_segundos,
          c.disposition as estado,
          c.userfield as atencion_ia,
          COALESCE(u.nombre, SPLIT_PART(SPLIT_PART(c.dstchannel, '-', 1), '/', 2)) as agente_humano
        FROM cdr c
        LEFT JOIN usuarios u ON u.numero_telefono = SPLIT_PART(SPLIT_PART(c.dstchannel, '-', 1), '/', 2)
        WHERE c.start::date = CURRENT_DATE
        ORDER BY c.start DESC
        LIMIT 20;
      `;
      const res = await pool.query(sql);
      return res.rows;
    } catch (err) {
      console.error('[DB] Error obteniendo historial CDR:', err.message);
      return [];
    }
  },
  // 3. Top Callers (Reemplazo de Intenciones)
  obtenerIntenciones: async () => {
    try {
      const res = await pool.query(`
        SELECT
          COALESCE(u.nombre, 'Ext. ' || c.src) AS intencion,
          COUNT(*) AS total
        FROM cdr c
        LEFT JOIN usuarios u ON u.numero_telefono = c.src
        WHERE c.start::date = CURRENT_DATE
          AND c.src IS NOT NULL
        GROUP BY u.nombre, c.src
        ORDER BY total DESC
        LIMIT 7
      `);
      return res.rows.map(row => ({
        intencion: row.intencion,
        total: parseInt(row.total)
      }));
    } catch (err) {
      console.error('[DB] Error en top callers:', err);
      return [];
    }
  },

  // 4. Actividad por horas restaurada
  obtenerActividadHoras: async () => {
    try {
      const res = await pool.query(`
        SELECT TO_CHAR(start, 'HH24:00') AS hora, COUNT(*) AS total
        FROM cdr
        WHERE start::date = CURRENT_DATE
        GROUP BY TO_CHAR(start, 'HH24:00')
        ORDER BY hora ASC
      `);
      return res.rows;
    } catch (err) {
      console.error('[DB] Error en actividad horas:', err.message);
      return [];
    }
  },

  // 5. Sesiones IA (Ajustado a fecha_hora y tiempo_sofia_seg)
  obtenerSesionesIA: async () => {
    try {
      const res = await pool.query(`
        SELECT
          m.fecha_hora AS "startedAt",
          COALESCE(m.intencion_detectada, 'Consulta') AS intencion_detectada,
          CASE WHEN m.transferida_a_agente::text IN ('1', 'true', 't') THEN 'escalated' ELSE 'resolved' END AS "status",
          m.tiempo_sofia_seg AS duracion_ia
        FROM metricas_llamadas m
        WHERE m.fecha_hora::date = CURRENT_DATE
        ORDER BY m.fecha_hora DESC
        LIMIT 15
      `);
      return res.rows;
    } catch (err) {
      console.error('[DB] Error en sesiones:', err);
      return [];
    }
  },

  // 🆕 NUEVO: MÓDULO GESTIÓN DE PROMPTS EN VIVO
  obtenerPromptIA: async () => {
    try {
      const res = await pool.query("SELECT valor FROM configuracion_sistema WHERE clave = 'sofia_system_prompt'");
      if (res.rows.length > 0) return res.rows[0].valor;
      return "Eres Sofía, la asistente virtual inteligente de Davivienda.";
    } catch (err) {
      console.error('[DB] Error obteniendo prompt IA desde la tabla:', err.message);
      return "Eres Sofía, la asistente virtual inteligente de Davivienda.";
    }
  },

  actualizarPromptIA: async (nuevoPrompt) => {
    try {
      await pool.query(`
        INSERT INTO configuracion_sistema (clave, valor, actualizado_el)
        VALUES ('sofia_system_prompt', $1, CURRENT_TIMESTAMP)
        ON CONFLICT (clave) DO UPDATE SET valor = $1, actualizado_el = CURRENT_TIMESTAMP
      `, [nuevoPrompt]);
      return true;
    } catch (err) {
      console.error('[DB] Error actualizando prompt IA en la tabla:', err.message);
      return false;
    }
  },
}; // <-- Esto cierra tu código original que ya estaba ahí

// ============================================================================
// MÓDULO DE HORARIOS Y CONTINGENCIA (Adjuntos directo al objeto DB)
// ============================================================================

DB.verificarDisponibilidadAgentes = async function() {
  try {
    const timeZone = 'America/El_Salvador';
    
    const formatterFecha = new Intl.DateTimeFormat('en-CA', { timeZone, year: 'numeric', month: '2-digit', day: '2-digit' });
    const formatterHora = new Intl.DateTimeFormat('en-GB', { timeZone, hour: '2-digit', minute: '2-digit', second: '2-digit' });
    
    const fechaSV = formatterFecha.format(new Date()); 
    const horaSV = formatterHora.format(new Date());
    const diaSemanaSV = new Date(new Date().toLocaleString('en-US', { timeZone })).getDay();

    const resAsueto = await pool.query('SELECT * FROM dias_asueto WHERE fecha = $1', [fechaSV]);
    if (resAsueto.rows.length > 0) {
      const asueto = resAsueto.rows[0];
      if (asueto.todo_el_dia) return { disponible: false, motivo: 'asueto', detalle: asueto.descripcion };
      if (asueto.hora_cierre_temprano && horaSV > asueto.hora_cierre_temprano) {
         return { disponible: false, motivo: 'cerrado_temprano', detalle: asueto.descripcion };
      }
    }

    const resHorario = await pool.query('SELECT * FROM config_horarios WHERE dia_semana = $1 AND activo = true', [diaSemanaSV]);
    if (resHorario.rows.length === 0) return { disponible: false, motivo: 'dia_inactivo' };

    const horario = resHorario.rows[0];
    if (horaSV >= horario.hora_apertura && horaSV < horario.hora_cierre) {
      return { disponible: true };
    } else {
      return { disponible: false, motivo: 'fuera_de_horario' };
    }
  } catch (error) {
    console.error('[Error Horarios]', error);
    return { disponible: false, motivo: 'error_sistema' }; 
  }
};

DB.crearRequerimiento = async function(telefono, detalle) {
  try {
    const query = `INSERT INTO requerimientos_cau (telefono_funcionario, detalle_falla) VALUES ($1, $2) RETURNING id`;
    const res = await pool.query(query, [telefono, detalle]);
    return res.rows[0].id;
  } catch (error) {
    console.error('[Error Ticket]', error);
    return null;
  }
};

// Exportamos el objeto actualizado
// ============================================================================
// FUNCIONES PARA EL PANEL WEB (API NEXT.JS)
// ============================================================================

DB.obtenerAsuetos = async function() {
  try {
    const res = await pool.query("SELECT * FROM dias_asueto ORDER BY fecha ASC");
    return res.rows;
  } catch (error) {
    console.error('[Error GET Asuetos]', error);
    return [];
  }
};

DB.agregarAsueto = async function(fecha, descripcion) {
  try {
    const query = "INSERT INTO dias_asueto (fecha, descripcion, todo_el_dia) VALUES ($1, $2, true) RETURNING *";
    const res = await pool.query(query, [fecha, descripcion]);
    return res.rows[0];
  } catch (error) {
    console.error('[Error POST Asueto]', error);
    return null;
  }
};

DB.eliminarAsueto = async function(id) {
  try {
    await pool.query("DELETE FROM dias_asueto WHERE id = $1", [id]);
    return true;
  } catch (error) {
    console.error('[Error DELETE Asueto]', error);
    return false;
  }
};

DB.obtenerHorarios = async function() {
  try {
    const res = await pool.query("SELECT * FROM config_horarios ORDER BY dia_semana ASC");
    return res.rows;
  } catch (error) {
    console.error('[Error GET Horarios]', error);
    return [];
  }
};

DB.actualizarHorario = async function(dia_semana, hora_apertura, hora_cierre, activo) {
  try {
    const query = `
      UPDATE config_horarios 
      SET hora_apertura = $1, hora_cierre = $2, activo = $3 
      WHERE dia_semana = $4 RETURNING *
    `;
    const res = await pool.query(query, [hora_apertura, hora_cierre, activo, dia_semana]);
    return res.rows[0];
  } catch (error) {
    console.error('[Error PUT Horario]', error);
    return null;
  }
};
module.exports = { DB };



