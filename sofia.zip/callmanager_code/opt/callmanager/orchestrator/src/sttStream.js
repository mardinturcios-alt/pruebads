'use strict';
const speech = require('@google-cloud/speech');
const { EventEmitter } = require('events');

const sttClient = new speech.SpeechClient();

class STTStream extends EventEmitter {
  constructor({ lang }) {
    super();
    this.stream = null;
    this.active = false;
    this.restarting = false;
    this.audioQueue = [];
  }

  start() {
    this.active = true;
    this._createStream();
  }

  _createStream() {
    if (!this.active) return;

    const stream = sttClient.streamingRecognize({
      config: {
        encoding: 'LINEAR16',
        sampleRateHertz: 8000,
        languageCode: 'es-US',
        model: 'latest_long',
        useEnhanced: true,
        enableAutomaticPunctuation: true,
        singleUtterance: false,
      },
      interimResults: true,
    });

    this.stream = stream;
    this.restarting = false;

    while (this.audioQueue.length > 0) {
      const chunk = this.audioQueue.shift();
      if (stream.writable) stream.write(chunk);
    }

    stream.on('data', (data) => {
      const transcript = data.results?.[0]?.alternatives?.[0]?.transcript || '';
      const isFinal = data.results?.[0]?.isFinal || false;
      if (transcript) {
        console.log(`[STT] "${transcript}"`);
        this.emit('transcript', transcript, isFinal);
      }
    });

    stream.on('error', (err) => {
      console.error(`[STT] Error: ${err.message}`);
      this.stream = null;
      if (!this.restarting && this.active) {
        this.restarting = true;
        setTimeout(() => this._createStream(), 300);
      }
    });

    stream.on('end', () => {
      this.stream = null;
      if (!this.restarting && this.active) {
        this.restarting = true;
        setTimeout(() => this._createStream(), 300);
      }
    });
  }

  sendAudio(chunk) {
    if (!this.active || !chunk) return;
    const buf = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    if (buf.length < 50) return;
    if (buf[0] === 123 || buf[0] === 91) return;

    if (this.stream && this.stream.writable) {
      this.stream.write(buf);
    } else {
      if (this.audioQueue.length < 10) this.audioQueue.push(buf);
    }
  }

  onTranscript(cb) { this.on('transcript', cb); }

  stop() {
    this.active = false;
    this.restarting = true;
    this.audioQueue = [];
    try { if (this.stream) this.stream.destroy(); } catch (_) {}
    this.stream = null;
  }
}

module.exports = { STTStream };
