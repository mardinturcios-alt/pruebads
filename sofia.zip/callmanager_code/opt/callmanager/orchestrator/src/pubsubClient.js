'use strict';
// pubsubClient.js — Notificar escalamientos al Agent Desktop
const { PubSub } = require('@google-cloud/pubsub');
const pubsub = new PubSub({ projectId: process.env.GCP_PROJECT_ID });
const TOPIC  = process.env.PUBSUB_ESCALATION_TOPIC || 'call-escalations';

const PubSubClient = {
  async publish(event) {
    try {
      const topic = pubsub.topic(TOPIC);
      await topic.publishMessage({
        data:       Buffer.from(JSON.stringify(event)),
        attributes: { type: 'escalation', callId: event.callId },
      });
      console.log(`[PubSub] Escalamiento publicado: ${event.callId}`);
    } catch (e) {
      console.error('[PubSub] Error:', e.message);
    }
  }
};

module.exports = { PubSubClient };
