'use strict';

const { PubSub } = require('@google-cloud/pubsub');
const pubsub = new PubSub({ projectId: process.env.GCP_PROJECT_ID });

async function publicarSolicitudAutogestion(datosFuncionario) {
  try {
    const topicName = 'solicitudes-autogestion';
    const dataBuffer = Buffer.from(JSON.stringify(datosFuncionario));
    
    const messageId = await pubsub.topic(topicName).publishMessage({ data: dataBuffer });
    
    console.log(`[GCP Pub/Sub] ¡Éxito! Mensaje ${messageId} enviado al tópico ${topicName}`);
    return true;
  } catch (error) {
    console.error('[GCP Pub/Sub] Error disparando evento a la nube:', error.message);
    return false;
  }
}

module.exports = { publicarSolicitudAutogestion };
