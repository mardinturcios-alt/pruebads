'use strict';
// helpdeskClient.js — Conector REST al helpdesk interno de Davivienda
const fetch = require('node-fetch');

class HelpdeskClient {
  constructor() {
    // URL del endpoint principal provista en la documentación
    this.baseUrl = 'https://helpdesk-backend-558109230839.us-central1.run.app/api/v1';
    // Firma criptográfica obligatoria
    this.apiKey  = 'dv_live_f593eb69d51a7214eae334a18f978b28915192ef5bfe40dd';
  }

  get headers() {
    return {
      // Obligatorio para enviar parámetros como Form Data
      'Content-Type': 'application/x-www-form-urlencoded',
      'X-API-Key':    this.apiKey,
    };
  }

// --- Método de creación adaptado a tu API ---
  async createCase({ asunto, descripcion, nombre, area, jefe, callId }) {
    try {
      console.log(`[Helpdesk] Solicitando creación de ticket: "${asunto}"`);

      // Formateamos los datos adicionales si la IA los logró conseguir
      const datoNombre = nombre ? nombre : 'No indicado por el usuario';
      const datoArea   = area ? area : 'No indicada por el usuario';
      const datoJefe   = jefe ? jefe : 'No indicado por el usuario';
      
      const descripcionFinal = `${descripcion}\n\n--- Datos de Seguimiento ---\nNombre: ${datoNombre}\nÁrea/Agencia: ${datoArea}\nJefe Inmediato: ${datoJefe}\n[Reportado vía Call Manager AI — CallID: ${callId}]`;

      // Construcción del cuerpo de la petición (Form Data)
      const params = new URLSearchParams();
      params.append('title', asunto);
      params.append('description', descripcionFinal);
// ... (el resto queda igual) ...
      params.append('customer_id', '3'); // Identificador fijo asignado (Mardin)
      params.append('queue_id', '1');    // Enrutamiento al CAU

// ... (el resto del código de la petición fetch se queda exactamente igual) ...

      const res = await fetch(`${this.baseUrl}/tickets/`, {
        method:  'POST',
        headers: this.headers,
        body:    params.toString(),
        signal:  AbortSignal.timeout(8000),
      });

      if (!res.ok) {
        const errorMsg = await res.text();
        console.error(`[Helpdesk] Error en API al crear caso: HTTP ${res.status} - ${errorMsg}`);
        return this._mockCreateCase(asunto, 'Fallo en la API real');
      }

      const data = await res.json();
      
      // Capturamos el ID del ticket generado (Ajustamos por si la API devuelve 'id' o 'ticket_id')
      const ticketId = data.id || data.ticket_id || data.numero || 'Generado';
      console.log(`[Helpdesk] ¡Éxito! Ticket creado en backend con ID: ${ticketId}`);
      
      return { 
        caseId: ticketId, 
        message: `Caso creado exitosamente. El número de ticket asignado es el ${ticketId}` 
      };

    } catch (e) {
      console.error(`[Helpdesk] Excepción de conexión:`, e.message);
      // Mantenemos el salvavidas por si el backend se cae, para no dejar a la IA sin respuesta
      return this._mockCreateCase(asunto, 'timeout');
    }
  }

  async getCase(caseNumber, clientId) {
    // Este método se mantiene estructurado para futuras implementaciones 
    // cuando el backend de Davivienda tenga un endpoint GET configurado.
    return { error: 'Consulta de casos en desarrollo' };
  }

  _mockCreateCase(asunto, categoria) {
    const num = `TK${Date.now().toString().slice(-6)}`;
    console.log(`[Helpdesk MOCK] Activando salvavidas. Ticket simulado: ${num}`);
    return {
      caseId:  num,
      message: `El sistema principal no respondió, pero registré el caso de contingencia con el número ${num}`,
      mock:    true
    };
  }
}

module.exports = { HelpdeskClient };
