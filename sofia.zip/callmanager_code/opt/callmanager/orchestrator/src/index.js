'use strict';
require('dotenv').config();

const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const http    = require('http');
const net     = require('net');
const { CallSession } = require('./callSession');
const { DB } = require('./database'); 

// 👇 Agrega esta nueva línea aquí:
const { iniciarMonitorAMI } = require('./ariClient');

const HTTP_PORT        = process.env.PORT || 8080;
const AUDIOSOCKET_PORT = process.env.AUDIOSOCKET_PORT || 9092;

const app = express();
app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'callmanager-orchestrator',
    audiosocket_port: AUDIOSOCKET_PORT,
    active_sessions: activeSessions.size,
    ts: new Date().toISOString()
  });
});

// ==========================================
// 📊 API DASHBOARD (Consumido por React)
// ==========================================

// Endpoint 1: Resumen de KPIs y Métricas de Sofía
app.get('/api/dashboard/resumen', async (req, res) => {
  try {
    const datos = await DB.obtenerResumenMetricas();

    // 1. Clientes hablando con Sofía
    const en_cola_entrada = activeSessions.size;

    // 2. Clientes esperando en la cola humana (VÍA AMI TUNNEL)
    const getQueueViaAMI = () => new Promise((resolve) => {
      const net = require('net');
      const client = new net.Socket();
      let buffer = '';
      
      // Si Asterisk no responde en 2 segundos, abortamos para no trabar el Wallboard
      client.setTimeout(2000);

      client.connect(5038, '127.0.0.1', () => {
        client.write("Action: Login\r\nUsername: orchestrator\r\nSecret: OrchestratorAMI2025!\r\nEvents: off\r\n\r\n");
        client.write("Action: Command\r\nCommand: queue show\r\n\r\n");
        client.write("Action: Logoff\r\n\r\n");
      });

      client.on('data', (d) => { buffer += d.toString(); });
      
      client.on('timeout', () => { client.destroy(); resolve(0); });
      client.on('error', (err) => { 
        console.error('[AMI Dashboard] Error:', err.message); 
        resolve(0); 
      });
      
      client.on('close', () => {
        let count = 0;
        const lineas = buffer.split('\n');
        for (const linea of lineas) {
          if (linea.includes(' strategy ')) {
            const match = linea.match(/has (\d+) calls/);
            if (match && match[1]) {
              count += parseInt(match[1], 10);
            }
          }
        }
        resolve(count);
      });
    });

    const en_cola_agentes = await getQueueViaAMI();

    // Inyectamos las métricas
    if (!datos.kpis) datos.kpis = {};
    datos.kpis.en_cola_entrada = en_cola_entrada;
    datos.kpis.en_cola_agentes = en_cola_agentes;

    res.json(datos);
  } catch (err) {
    console.error('Error en /resumen:', err);
    res.status(500).json({ error: 'Error interno obteniendo métricas' });
  }
});
// 🛣️ VÍA PESADA: Módulo Histórico de Métricas IA
app.get('/api/dashboard/historico', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    
    // Si no mandan fechas, les pedimos amablemente que lo hagan
    if (!startDate || !endDate) {
      return res.status(400).json({ error: 'Se requieren startDate y endDate' });
    }

    const data = await DB.obtenerMetricasHistoricas(startDate, endDate);
    res.json(data);
  } catch (error) {
    console.error('[API] Error en /api/dashboard/historico:', error);
    res.status(500).json({ error: 'Error interno obteniendo métricas históricas' });
  }
});
// Endpoint 2: Historial en vivo del CDR de Asterisk
app.get('/api/dashboard/cdr', async (req, res) => {
  try {
    const historial = await DB.obtenerHistorialCDR();
    res.json(historial);
  } catch (err) {
    res.status(500).json({ error: 'Error interno obteniendo CDR' });
  }
});

app.get('/api/dashboard/intenciones', async (req, res) => {
  try {
    const datos = await DB.obtenerIntenciones();
    res.json(datos);
  } catch (err) {
    console.error('Error en /intenciones:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/dashboard/actividad-horas', async (req, res) => {
  try {
    const datos = await DB.obtenerActividadHoras();
    res.json(datos);
  } catch (err) {
    console.error('Error en /actividad-horas:', err);
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/dashboard/sesiones', async (req, res) => {
  try {
    const datos = await DB.obtenerSesionesIA();
    res.json(datos);
  } catch (err) {
    console.error('Error en /sesiones:', err);
    res.status(500).json({ error: err.message });
  }
});
// Endpoint NUEVO: Actualizar datos del Funcionario desde el Screen Pop
app.post('/api/usuarios/actualizar', async (req, res) => {
  try {
    const { peoplesoft_id, telefono, nombre, correo, area, jefe } = req.body;
    // Utilizamos la misma función que usa la IA para guardar
    const exito = await DB.guardarFuncionario(peoplesoft_id, telefono, nombre, correo, area, jefe);
    if (exito) {
      res.json({ ok: true, mensaje: 'Usuario actualizado correctamente' });
    } else {
      res.status(500).json({ error: 'Error al actualizar en la base de datos' });
    }
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

app.get('/session/:callId', async (req, res) => {
  try {
    const { SessionStore } = require('./sessionStore');
    const session = await SessionStore.get(req.params.callId);
    if (!session) return res.status(404).json({ error: 'Sesión no encontrada' });
    res.json(session);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
// --- RUTAS DE PROMPT OPS (CONTROL DE IA) ---
app.get('/api/admin/prompt', async (req, res) => {
  try {
    const prompt = await DB.obtenerPromptIA();
    res.json({ prompt });
  } catch (err) {
    console.error("Error obteniendo prompt:", err);
    res.status(500).json({ error: 'Error interno' });
  }
});

app.post('/api/admin/prompt', async (req, res) => {
  try {
    const { prompt } = req.body;
    if (!prompt) return res.status(400).json({ error: 'El prompt no puede estar vacío' });
    
    await DB.actualizarPromptIA(prompt);
    res.json({ success: true, message: 'Directrices actualizadas en vivo' });
  } catch (err) {
    console.error("Error guardando prompt:", err);
    res.status(500).json({ error: 'Error interno' });
  }
});
app.post('/session/:callId/accept', async (req, res) => {
  try {
    const { agentExtension } = req.body;
    const session = activeSessions.get(req.params.callId);
    if (!session) return res.status(404).json({ error: 'Sesión no activa' });
    await session.transferToAgent(agentExtension);
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 📊 --- INICIO DEL DASHBOARD WEB ---
app.get('/dashboard', (req, res) => {
  res.send(`
    <!DOCTYPE html>
    <html lang="es">
    <head>
        <meta charset="UTF-8">
        <title>Dashboard | Sofía IA</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <style>body { background-color: #f4f6f9; }</style>
    </head>
    <body>
        <nav class="navbar navbar-dark" style="background-color: #ed1c24;">
            <div class="container-fluid">
                <span class="navbar-brand mb-0 h1">Davivienda | Monitoreo de Sofía IA</span>
            </div>
        </nav>
        <div class="container mt-4">
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card text-white bg-primary mb-3 shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title">Total Llamadas</h6>
                            <h2 id="kpi-total">0</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-success mb-3 shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title">Resueltas por IA</h6>
                            <h2 id="kpi-ia">0</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-warning mb-3 shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title">Transferidas a Cola</h6>
                            <h2 id="kpi-human">0</h2>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card text-white bg-info mb-3 shadow-sm">
                        <div class="card-body">
                            <h6 class="card-title">Ahorro Promedio IA</h6>
                            <h2 id="kpi-time">0s</h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-5">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title text-center">Resolución de Llamadas</h5>
                            <canvas id="chartResolucion"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-7">
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">Últimas Interacciones</h5>
                            <table class="table table-sm table-striped" id="tabla-llamadas">
                                <thead><tr><th>Ext/Teléfono</th><th>Intención detectada</th><th>Resultado</th></tr></thead>
                                <tbody></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script>
            fetch('/api/metricas').then(r => r.json()).then(data => {
                document.getElementById('kpi-total').innerText = data.kpis.total;
                document.getElementById('kpi-ia').innerText = data.kpis.resueltas_ia;
                document.getElementById('kpi-human').innerText = data.kpis.transferidas;
                document.getElementById('kpi-time').innerText = Math.round(data.kpis.tiempo_promedio) + 's';

                new Chart(document.getElementById('chartResolucion'), {
                    type: 'doughnut',
                    data: {
                        labels: ['Resueltas por Sofía', 'Transferidas a Humano'],
                        datasets: [{ 
                            data: [data.kpis.resueltas_ia, data.kpis.transferidas], 
                            backgroundColor: ['#198754', '#ffc107'] 
                        }]
                    }
                });

                const tbody = document.querySelector('#tabla-llamadas tbody');
                data.ultimas.forEach(ll => {
                    tbody.innerHTML += \`<tr><td>\${ll.telefono}</td><td>\${ll.intencion.substring(0,40)}...</td><td>\${ll.evaluacion}</td></tr>\`;
                });
            }).catch(e => console.error('Error cargando métricas:', e));
        </script>
    </body>
    </html>
  `);
});

app.get('/api/metricas', async (req, res) => {
  try {
    const metricas = await DB.obtenerResumenMetricas();
    res.json(metricas);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
// 📊 --- FIN DEL DASHBOARD WEB ---

const httpServer = http.createServer(app);

// --- INICIO WEBSOCKET (Agent Desktop) ---
const { Server } = require('socket.io');
const io = new Server(httpServer, {
  cors: { 
    origin: '*', // Permite que tu futuro React se conecte desde cualquier IP
    methods: ['GET', 'POST']
  }
});

io.on('connection', (socket) => {
  console.log(`[WebSocket] 🟢 Nuevo Agent Desktop conectado: ${socket.id}`);
  socket.on('disconnect', () => console.log(`[WebSocket] 🔴 Agent Desktop desconectado: ${socket.id}`));
});

// Exponemos la variable 'io' globalmente para que Sofía pueda usarla desde otro archivo
global.io = io; 
// --- FIN WEBSOCKET ---
const activeSessions = new Map();

const tcpServer = net.createServer((socket) => {
  const remoteAddr = `${socket.remoteAddress}:${socket.remotePort}`;
  console.log(`[AudioSocket] Nueva conexión desde ${remoteAddr}`);

  socket.setNoDelay(true);
  socket.setKeepAlive(true, 5000);

  let session = null;
  let buffer  = Buffer.alloc(0);

  socket.on('data', (chunk) => {
    buffer = Buffer.concat([buffer, chunk]);

    while (buffer.length >= 3) {
      const type   = buffer[0];
      const length = buffer.readUInt16BE(1);
      const total  = 3 + length;

      if (buffer.length < total) break;

      const payload = buffer.slice(3, total);
      buffer = buffer.slice(total);

      handleFrame(type, payload, socket);
    }
  });

  socket.on('close', () => {
    console.log(`[AudioSocket] Conexión cerrada ${remoteAddr}`);
    if (session) {
      session.end().catch(() => {});
      activeSessions.delete(session.callId);
    }
  });

  socket.on('error', (err) => {
    console.error(`[AudioSocket] Error en ${remoteAddr}:`, err.message);
    if (session) {
      session.end().catch(() => {});
      activeSessions.delete(session.callId);
    }
  });

  function handleFrame(type, payload, sock) {
    switch (type) {
      case 0x00:
        sock.end();
        break;
      case 0x01:
        const uuid = payload.toString('hex').match(/.{1,8}/g);
        const callId = `${uuid[0]}-${uuid[1].substring(0, 4)}-${uuid[1].substring(4, 8)}-${uuid[2].substring(0, 4)}-${uuid[2].substring(4, 8)}${uuid[3]}`;
        
        session = new CallSession({ callId, caller: 'unknown', lang: 'es-SV', socket: sock });
        activeSessions.set(callId, session);
        session.start().catch(e => console.error('Error iniciando sesión:', e.message));
        break;
      case 0x03:
        const dtmf = payload.toString('ascii');
        if (session) session.onDtmf(dtmf);
        break;
      case 0x10:
        if (session) session.onAudioFrame(payload);
        break;
      case 0xff:
        console.error(`[AudioSocket] Error frame:`, payload);
        break;
    }
  }
});
// ============================================================================
// API PARA GESTIÓN DE ASUETOS (PANEL NEXT.JS)
// ============================================================================

app.get('/api/asuetos', async (req, res) => {
  try {
    const asuetos = await DB.obtenerAsuetos();
    res.json(asuetos);
  } catch (e) { 
    res.status(500).json({ error: e.message }); 
  }
});

app.post('/api/asuetos', async (req, res) => {
  try {
    const { fecha, descripcion } = req.body;
    if (!fecha || !descripcion) return res.status(400).json({ error: 'Faltan datos' });
    const nuevo = await DB.agregarAsueto(fecha, descripcion);
    res.json(nuevo || { error: 'No se pudo crear' });
  } catch (e) { 
    res.status(500).json({ error: e.message }); 
  }
});

app.delete('/api/asuetos/:id', async (req, res) => {
  try {
    const exito = await DB.eliminarAsueto(req.params.id);
    res.json({ success: exito });
  } catch (e) { 
    res.status(500).json({ error: e.message }); 
  }
});
// ============================================================================
// API PARA GESTIÓN DE HORARIOS REGULARES (PANEL NEXT.JS)
// ============================================================================

app.get('/api/horarios', async (req, res) => {
  try {
    const horarios = await DB.obtenerHorarios();
    res.json(horarios);
  } catch (e) { 
    res.status(500).json({ error: e.message }); 
  }
});

app.put('/api/horarios/:dia', async (req, res) => {
  try {
    const { hora_apertura, hora_cierre, activo } = req.body;
    const dia_semana = parseInt(req.params.dia);
    
    if (isNaN(dia_semana)) return res.status(400).json({ error: 'Día inválido' });
    
    const actualizado = await DB.actualizarHorario(dia_semana, hora_apertura, hora_cierre, activo);
    res.json(actualizado || { error: 'No se pudo actualizar' });
  } catch (e) { 
    res.status(500).json({ error: e.message }); 
  }
});

process.on('SIGTERM', () => {
  tcpServer.close();
  httpServer.close();
  process.exit(0);
});
// ============================================================================
// API PARA REPRODUCCIÓN DE GRABACIONES (PANEL NEXT.JS)
// ============================================================================

app.get('/api/grabaciones/:callId', (req, res) => {
  const callId = req.params.callId;
  const recordingsDir = '/var/spool/asterisk/recordings';

  // 1. Escaneamos la carpeta local
  fs.readdir(recordingsDir, (err, files) => {
    if (err) {
      console.error('[API Grabaciones] Error leyendo el directorio:', err);
      return res.status(500).json({ error: 'Error interno del servidor' });
    }

    // 2. Buscamos el archivo que contenga el ID único de la llamada
    const match = files.find(f => f.includes(callId));

    if (match) {
      // 3. Si lo encontramos (WAV o MP3), se lo enviamos al navegador
      const filePath = path.join(recordingsDir, match);
      res.sendFile(filePath);
    } else {
      // 4. Si no está, significa que el Cronjob de las 2:00 AM ya lo subió a GCP
      // (Más adelante podemos agregar la lógica para traerlo desde el bucket)
      res.status(404).json({ error: 'Grabación enviada a Google Cloud o no encontrada' });
    }
  });
});

async function arrancarServicio() {
  try {
    await DB.init();
    httpServer.listen(HTTP_PORT, () => {
      console.log(`[HTTP] Puerto ${HTTP_PORT} — Dashboard: http://TU_IP:8080/dashboard`);
    });
    tcpServer.listen(AUDIOSOCKET_PORT, () => {
      console.log(`[AudioSocket] Escuchando en TCP puerto ${AUDIOSOCKET_PORT}`);
    });
  } catch (error) {
    console.error('[Orquestador] Error al iniciar:', error);
    process.exit(1);
  }
}

arrancarServicio();
// 👇 Agrega esta línea para que el monitor encienda junto con el servidor:
iniciarMonitorAMI();

module.exports = { activeSessions };
