'use strict';
const { GoogleAuth } = require('google-auth-library');

const PROJECT_ID  = process.env.GCP_PROJECT_ID;
const ENGINE_ID   = 'callmanager-search-v2';
const SEARCH_URL  = `https://discoveryengine.googleapis.com/v1/projects/${PROJECT_ID}/locations/global/collections/default_collection/engines/${ENGINE_ID}/servingConfigs/default_serving_config:search`;

const auth = new GoogleAuth({
  scopes: ['https://www.googleapis.com/auth/cloud-platform']
});

class KnowledgeBase {
  async search(query) {
    try {
      console.log(`[KB] Buscando en Vertex AI: "${query}"`);
      const client = await auth.getClient();
      const token  = await client.getAccessToken();

      const res = await fetch(SEARCH_URL, {
        method:  'POST',
        headers: {
          'Authorization':       `Bearer ${token.token}`,
          'Content-Type':        'application/json',
          'x-goog-user-project': PROJECT_ID,
        },
        // Limitamos a 2 resultados para que Gemini no se sature de texto y responda rápido
        body: JSON.stringify({ query, pageSize: 2 }), 
      });

      if (!res.ok) {
        console.error(`[KB] Error HTTP de Vertex: ${res.status}`);
        return { found: false, summary: null };
      }

      const data = await res.json();
      const results = data.results || [];
      console.log(`[KB] ${results.length} resultado(s) encontrado(s) en la nube.`);

      if (!results.length) {
        return { found: false, summary: null };
      }

      // Procesamiento a prueba de fallos para extraer el texto
      const articles = results
        .map(r => {
            const doc = r.document || {};
            // Vertex usa structData para JSONs y derivedStructData/snippets para PDFs
            return doc.structData || doc.derivedStructData || { title: doc.name, snippet: doc.snippet };
        })
        .filter(d => d.title || d.content || d.snippet)
        .map((d, index) => {
          const title   = d.title || 'Documento de Soporte';
          const content = d.content || d.snippet || 'Sin detalles extra';
          
          // Formateo Markdown para que la IA lo entienda a la perfección
          return `--- MANUAL ${index + 1}: ${title} ---\nContenido: ${content}\n`;
        });

      const summary = articles.join('\n');

      return { found: true, summary };

    } catch (e) {
      console.error('[KB] Excepción al buscar:', e.message);
      return { found: false, summary: null };
    }
  }
}

module.exports = { KnowledgeBase };
