'use strict';
const fetch = require('node-fetch');
const net = require('net');
const { Firestore } = require('@google-cloud/firestore');

const ARI_BASE_URL = process.env.ASTERISK_ARI_URL || 'https://asterisk-api.davivienda.com/ari';
const ARI_USER     = process.env.ASTERISK_ARI_USER || 'orchestrator';
const ARI_PASS     = process.env.ASTERISK_ARI_PASSWORD || '';

// Credenciales AMI
const AMI_HOST = '127.0.0.1';
const AMI_PORT = 5038;
const AMI_USER = 'orchestrator';
const AMI_PASS = 'OrchestratorAMI2025!';

// Conexión a Firestore
const db = new Firestore({ projectId: process.env.GCP_PROJECT_ID });

class AriClient {
  get headers() {
    const auth = Buffer.from(`${ARI_USER}:${ARI_PASS}`).toString('base64');
    return { 'Authorization': `Basic ${auth}`, 'Content-Type': 'application/json' };
  }

  async getCallerNumber(callId) {
    try {
      const res = await fetch(`${ARI_BASE_URL}/channels`, { headers: this.headers });
      const channels = await res.json();

      const channel = channels.find(c =>
        c.state === 'Up' && (
          c.id === callId ||
          c.name.includes(callId.substring(0,8)) ||
          c.name.includes('PJSIP/') ||
          c.name.includes('SIP/')
        )
      );

      if (channel && channel.caller && channel.caller.number) {
        console.log(`[ARI] Match encontrado. Canal: ${channel.name} | Extensión: ${channel.caller.number}`);
        return channel.caller.number;
      }

      console.log('[ARI] No se encontró match exacto. Canales activos en Asterisk:', channels.map(c => c.name));
      return 'unknown';
    } catch (e) {
      console.error('[ARI] Error obteniendo CallerID:', e.message);
      return 'unknown';
    }
  }

  async transferCall(callId, agentExtension, summary) {
    try {
      const channelsRes = await fetch(`${ARI_BASE_URL}/channels`, { headers: this.headers });
      const channels = await channelsRes.json();

      const clientChannel = channels.find(c =>
        c.state === 'Up' && (c.id === callId || c.name.includes(callId.substring(0,8)) || c.name.includes('PJSIP/') || c.name.includes('SIP/'))
      );

      if (!clientChannel) throw new Error('Canal de cliente no encontrado');

      console.log(`[AMI] Redirigiendo canal ${clientChannel.name} a ext ${agentExtension}...`);
      await this.redirectViaAMI(clientChannel.name, agentExtension);
      return { success: true };
    } catch (e) {
      console.error('[AMI] Error en transfer:', e.message);
      throw e;
    }
  }

  redirectViaAMI(channelName, targetExten) {
    return new Promise((resolve, reject) => {
      const client = new net.Socket();
      client.connect(AMI_PORT, AMI_HOST, () => {
        client.write(`Action: Login\r\nUsername: ${AMI_USER}\r\nSecret: ${AMI_PASS}\r\nEvents: off\r\n\r\n`);
        client.write(`Action: Redirect\r\nChannel: ${channelName}\r\nExten: ${targetExten}\r\nContext: from-internal\r\nPriority: 1\r\n\r\n`);
        client.write(`Action: Logoff\r\n\r\n`);
      });
      client.on('close', () => resolve(true));
      client.on('error', (err) => reject(err));
    });
  }
}

// 🚀 NUEVO: Monitor en tiempo real para pausas de Asterisk
function iniciarMonitorAMI() {
  const amiClient = new net.Socket();

  amiClient.connect(AMI_PORT, AMI_HOST, () => {
    console.log('📡 [AMI Monitor] Escuchando eventos de Asterisk para auto-pausas...');
    amiClient.write(`Action: Login\r\nUsername: ${AMI_USER}\r\nSecret: ${AMI_PASS}\r\nEvents: on\r\n\r\n`);
  });

  let bufferDatos = '';

  amiClient.on('data', async (data) => {
    bufferDatos += data.toString();
    const eventos = bufferDatos.split('\r\n\r\n');
    bufferDatos = eventos.pop(); 

    for (const eventoTexto of eventos) {
      if (eventoTexto.includes('Event: QueueMemberPause')) {
        const matchExtension = eventoTexto.match(/Interface: (?:PJSIP|SIP)\/(\d+)/);
        const matchPausado = eventoTexto.match(/Paused: (\d)/);
        // Filtramos para asegurar que es la pausa automática de Asterisk
        const matchReason = eventoTexto.match(/Reason: Auto-Pause/i);

        if (matchExtension && matchPausado && matchReason) {
          const extension = matchExtension[1];
          const estaPausado = matchPausado[1] === '1';

          if (estaPausado) {
            console.log(`🚨 Asterisk auto-pausó al agente ${extension}. Actualizando Firestore...`);
            
            try {
              const agentsRef = db.collection('agents');
              const snapshot = await agentsRef.where('extension', '==', extension).limit(1).get();

              if (!snapshot.empty) {
                const docId = snapshot.docs[0].id;
                await agentsRef.doc(docId).update({
                  status: 'paused',
                  statusUpdatedAt: new Date().toISOString()
                });
                console.log(`✅ [Firestore] Estado de ext ${extension} actualizado a "paused"`);
              }
            } catch (error) {
              console.error('[Firestore Error] Fallo al sincronizar auto-pausa:', error);
            }
          }
        }
      }
    }
  });

  amiClient.on('error', (err) => console.error('[AMI Monitor] Error:', err.message));
  amiClient.on('close', () => setTimeout(iniciarMonitorAMI, 5000));
}

module.exports = { AriClient, iniciarMonitorAMI };
