'use strict';
const tts = require('@google-cloud/text-to-speech');
const client = new tts.TextToSpeechClient();

class TTSClient {
  constructor({ lang }) {
    this.lang = lang || 'es-SV';
  }

  async synthesize(text) {
    const [response] = await client.synthesizeSpeech({
      input: { text },
      voice: {
        languageCode: 'es-US',
        name:         'es-US-Journey-F',
        ssmlGender:   'FEMALE',
      },
      audioConfig: {
        audioEncoding:   'LINEAR16',
        sampleRateHertz: 8000,
      },
    });
    let audioBuffer = Buffer.from(response.audioContent);
    if (audioBuffer.length > 44 &&
        audioBuffer.slice(0, 4).toString() === 'RIFF') {
      audioBuffer = audioBuffer.slice(44);
    }
    return audioBuffer;
  }
}

module.exports = { TTSClient };
