'use strict';
// sessionStore.js — Persistencia en Firestore
const { Firestore, FieldValue } = require('@google-cloud/firestore');

const db = new Firestore({ projectId: process.env.GCP_PROJECT_ID });
const COL = 'call_sessions';

const SessionStore = {
  async save(session) {
    await db.collection(COL).doc(session.callId).set(session);
  },
  async get(callId) {
    const doc = await db.collection(COL).doc(callId).get();
    return doc.exists ? doc.data() : null;
  },
  async update(callId, data) {
    await db.collection(COL).doc(callId).update(data);
  },
  async addMessage(callId, role, content) {
    await db.collection(COL).doc(callId).update({
      messages: FieldValue.arrayUnion({
        role,
        content,
        ts: new Date().toISOString()
      })
    });
  }
};

module.exports = { SessionStore };
