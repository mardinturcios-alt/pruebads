import { redirect } from 'next/navigation';
import { getCurrentSession } from '@/lib/auth';
import { DashboardClient } from '@/components/DashboardClient';

export default async function DashboardPage() {
  // 1. El servidor verifica el token de seguridad
  const session = await getCurrentSession();
  
  // 2. Si no hay sesión real, lo patea al login original
  if (!session) {
    redirect('/login');
  }

  // 3. Si es seguro, inyecta tu hermoso diseño
  return <DashboardClient session={session} />;
}
