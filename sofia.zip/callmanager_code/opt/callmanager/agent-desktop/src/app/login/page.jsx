// app/login/page.jsx — Login del agente
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Phone, Lock, User, AlertCircle, Loader2 } from 'lucide-react';

export default function LoginPage() {
  const router = useRouter();
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState('');

  async function handleLogin(e) {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch('/api/auth/login', {
        method:  'POST',
        headers: { 'Content-Type': 'application/json' },
        body:    JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        setError(data.error || 'Error al iniciar sesión');
        return;
      }

      router.push('/dashboard');
      router.refresh();
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-davivienda-gray-50 to-davivienda-gray-100">
      <div className="w-full max-w-md p-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-davivienda-red mb-4 shadow-lg">
            <Phone className="text-white w-8 h-8" />
          </div>
          <h1 className="text-2xl font-bold text-davivienda-gray-900">
            Call Manager
          </h1>
          <p className="text-davivienda-gray-500 mt-1">
            Panel de Agentes — Davivienda
          </p>
        </div>

        <form
          onSubmit={handleLogin}
          className="bg-white rounded-2xl shadow-sm border border-davivienda-gray-200 p-6 space-y-4"
        >
          {error && (
            <div className="flex items-start gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
              <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-sm font-medium text-davivienda-gray-700 mb-1.5">
              Usuario
            </label>
            <div className="relative">
              <User className="absolute left-3 top-3 w-4 h-4 text-davivienda-gray-400" />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
                disabled={loading}
                className="w-full pl-9 pr-3 py-2.5 border border-davivienda-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-davivienda-red focus:border-transparent disabled:bg-davivienda-gray-50"
                placeholder="agente001"
                autoFocus
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-davivienda-gray-700 mb-1.5">
              Contraseña
            </label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 w-4 h-4 text-davivienda-gray-400" />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
                disabled={loading}
                className="w-full pl-9 pr-3 py-2.5 border border-davivienda-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-davivienda-red focus:border-transparent disabled:bg-davivienda-gray-50"
                placeholder="••••••••"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-2.5 bg-davivienda-red hover:bg-davivienda-dark disabled:bg-davivienda-gray-400 text-white font-medium rounded-lg transition flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Ingresando...
              </>
            ) : (
              'Ingresar'
            )}
          </button>
        </form>

        <p className="text-center text-xs text-davivienda-gray-400 mt-6">
          ¿Problemas para ingresar? Contactá al área de TI
        </p>
      </div>
    </div>
  );
}
