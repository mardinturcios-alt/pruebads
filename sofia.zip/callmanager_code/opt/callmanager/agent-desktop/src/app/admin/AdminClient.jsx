'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Users, Shield, Plus, X, Phone, UserCheck, Loader2 } from 'lucide-react';

export function AdminClient({ session }) {
  const router = useRouter();
  const [agents, setAgents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);

  // Formulario
  const [formData, setFormData] = useState({
    username: '', password: '', fullName: '', extension: '', sipPassword: '', role: 'agent', maxLines: 1
  });

  // Cargar Agentes
  const fetchAgents = async () => {
    const res = await fetch('/api/admin/agents');
    if (res.ok) {
      const data = await res.json();
      setAgents(data.agents);
    }
    setLoading(false);
  };

  useEffect(() => { fetchAgents(); }, []);

  // Crear Agente
  const handleCreate = async (e) => {
    e.preventDefault();
    setLoading(true);
    const res = await fetch('/api/admin/agents', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    
    if (res.ok) {
      setShowModal(false);
      setFormData({ username: '', password: '', fullName: '', extension: '', sipPassword: '', role: 'agent', maxLines: 1 });
      await fetchAgents();
    } else {
      const err = await res.json();
      alert('Error: ' + err.error);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800 font-sans">
      
      {/* HEADER ADMIN */}
      <header className="bg-gray-900 text-white h-20 flex items-center justify-between px-8 shadow-md">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-red-600 rounded-lg flex items-center justify-center">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">Backoffice Administrador</h1>
            <p className="text-xs text-gray-400">Gestión de Agentes y Líneas SIP</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <p className="font-medium text-sm border-r border-gray-700 pr-4">{session.fullName} (Admin)</p>
          <button onClick={() => router.push('/dashboard')} className="text-sm bg-gray-800 hover:bg-gray-700 px-4 py-2 rounded-lg transition">
            Volver al Teléfono
          </button>
        </div>
      </header>

      {/* CONTENIDO PRINCIPAL */}
      <main className="max-w-7xl mx-auto p-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Directorio de Agentes</h2>
            <p className="text-gray-500">Administra accesos web y credenciales telefónicas.</p>
          </div>
          <button 
            onClick={() => setShowModal(true)}
            className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg transition-transform hover:scale-105"
          >
            <Plus className="w-5 h-5" /> Nuevo Agente
          </button>
        </div>

        {/* TABLA DE AGENTES */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden">
          {loading && agents.length === 0 ? (
            <div className="p-12 text-center text-gray-500"><Loader2 className="w-8 h-8 animate-spin mx-auto mb-4" /> Cargando directorio...</div>
          ) : (
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-50 border-b border-gray-200 text-sm font-bold text-gray-500 uppercase tracking-wider">
                  <th className="p-4">Agente</th>
                  <th className="p-4">Usuario Web</th>
                  <th className="p-4">Extensión SIP</th>
                  <th className="p-4">Líneas Concurrentes</th>
                  <th className="p-4">Estado</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {agents.map(ag => (
                  <tr key={ag.id} className="hover:bg-gray-50 transition">
                    <td className="p-4">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center">
                          <UserCheck className="w-5 h-5 text-blue-600" />
                        </div>
                        <div>
                          <p className="font-bold text-gray-900">{ag.fullName}</p>
                          <p className="text-xs text-gray-500">{ag.role === 'admin' ? 'Administrador' : 'Agente Nivel 1'}</p>
                        </div>
                      </div>
                    </td>
                    <td className="p-4 text-sm font-mono text-gray-600">{ag.username}</td>
                    <td className="p-4">
                      <div className="flex items-center gap-2 text-sm font-bold text-gray-700">
                        <Phone className="w-4 h-4 text-gray-400" /> {ag.extension}
                      </div>
                    </td>
                    <td className="p-4">
                      <span className="px-3 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-bold">
                        {ag.maxLines} {ag.maxLines > 1 ? 'Líneas' : 'Línea'}
                      </span>
                    </td>
                    <td className="p-4">
                      <span className={`px-3 py-1 rounded-full text-xs font-bold ${ag.status === 'offline' ? 'bg-gray-100 text-gray-500' : 'bg-green-100 text-green-700'}`}>
                        {ag.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </main>

      {/* MODAL CREAR AGENTE */}
      {showModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full overflow-hidden">
            <div className="bg-gray-50 px-6 py-4 border-b border-gray-200 flex justify-between items-center">
              <h3 className="text-xl font-bold text-gray-800">Alta de Nuevo Agente</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-red-500 transition"><X className="w-6 h-6" /></button>
            </div>
            
            <form onSubmit={handleCreate} className="p-6">
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Nombre Completo</label>
                  <input required type="text" value={formData.fullName} onChange={e => setFormData({...formData, fullName: e.target.value})} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none" placeholder="Ej. Juan Pérez" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Usuario Web (Login)</label>
                  <input required type="text" value={formData.username} onChange={e => setFormData({...formData, username: e.target.value})} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none" placeholder="Ej. agente002" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Contraseña Web</label>
                  <input required type="text" value={formData.password} onChange={e => setFormData({...formData, password: e.target.value})} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none" placeholder="Mínimo 6 caracteres" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-2">Rol del Sistema</label>
                  <select value={formData.role} onChange={e => setFormData({...formData, role: e.target.value})} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none">
                    <option value="agent">Agente Normal</option>
                    <option value="admin">Administrador</option>
                  </select>
                </div>
              </div>

              <div className="bg-red-50 p-6 rounded-xl border border-red-100 grid grid-cols-3 gap-4">
                <div className="col-span-3 mb-2">
                  <h4 className="font-bold text-red-800 flex items-center gap-2"><Phone className="w-4 h-4"/> Configuración Telefónica (Asterisk / SIP)</h4>
                </div>
                <div>
                  <label className="block text-sm font-bold text-red-900 mb-2">Extensión</label>
                  <input required type="text" value={formData.extension} onChange={e => setFormData({...formData, extension: e.target.value})} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none" placeholder="Ej. 8002" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-red-900 mb-2">Contraseña SIP</label>
                  <input required type="text" value={formData.sipPassword} onChange={e => setFormData({...formData, sipPassword: e.target.value})} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-red-500 outline-none" placeholder="Secret de pjsip.conf" />
                </div>
                <div>
                  <label className="block text-sm font-bold text-purple-900 mb-2">Líneas Simultáneas</label>
                  <select value={formData.maxLines} onChange={e => setFormData({...formData, maxLines: e.target.value})} className="w-full p-3 border rounded-lg focus:ring-2 focus:ring-purple-500 outline-none font-bold text-purple-700 bg-purple-50">
                    <option value="1">1 Línea (Estricto)</option>
                    <option value="2">2 Líneas (Multilínea)</option>
                    <option value="3">3 Líneas (Avanzado)</option>
                  </select>
                </div>
              </div>

              <div className="mt-8 flex justify-end gap-4">
                <button type="button" onClick={() => setShowModal(false)} className="px-6 py-3 font-bold text-gray-500 hover:bg-gray-100 rounded-lg transition">Cancelar</button>
                <button type="submit" disabled={loading} className="px-6 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg shadow-lg flex items-center gap-2 transition disabled:opacity-50">
                  {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : 'Guardar Agente'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
