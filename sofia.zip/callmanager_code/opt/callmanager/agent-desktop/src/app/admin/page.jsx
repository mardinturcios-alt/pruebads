import { redirect } from 'next/navigation';
import { getCurrentSession } from '@/lib/auth';
import { AdminClient } from './AdminClient';

export default async function AdminPage() {
  const session = await getCurrentSession();

  // Si no hay sesión, al login. Si no es admin, de regreso a su teléfono.
  if (!session) redirect('/login');
  if (session.role !== 'admin') redirect('/dashboard');

  return <AdminClient session={session} />;
}
