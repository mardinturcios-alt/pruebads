import { NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { SearchServiceClient } from '@google-cloud/discoveryengine';

const PROJECT_ID = process.env.GCP_PROJECT_ID; 
const LOCATION = 'global';

function getDataStoreId(baseType) {
  if (baseType === 'tech') {
    return process.env.GCP_DATA_STORE_TECH || 'callmanager-kb-tech';
  }
  return process.env.GCP_DATA_STORE_BASIC || 'callmanager-kb-v2';
}

export async function POST(req) {
  const session = await getCurrentSession();
  if (!session) {
    return NextResponse.json({ error: 'Acceso denegado' }, { status: 403 });
  }

  try {
    const { query, base } = await req.json();

    if (!query) {
      return NextResponse.json({ error: 'La búsqueda no puede estar vacía' }, { status: 400 });
    }

    if (!PROJECT_ID) throw new Error('GCP_PROJECT_ID no configurado');

    const dataStoreId = getDataStoreId(base);
    const client = new SearchServiceClient();

    const servingConfig = client.projectLocationCollectionDataStoreServingConfigPath(
      PROJECT_ID,
      LOCATION,
      'default_collection',
      dataStoreId,
      'default_search'
    );

    const request = {
      servingConfig,
      query: query,
      pageSize: 3,
    };

    console.log(`Buscando query en el almacén: ${dataStoreId}`);
    const iterable = await client.searchAsync(request);
    let results = [];

    for await (const response of iterable) {
      const doc = response.document;
      if (doc && doc.structData && doc.structData.fields) {
        results.push({
          id: doc.id,
          title: doc.structData.fields.title?.stringValue || 'Documento sin título',
          content: doc.structData.fields.content?.stringValue || ''
        });
      }
    }

    return NextResponse.json({ ok: true, results });

  } catch (error) {
    console.error("☁️ [Vertex AI Search] Error buscando conocimiento:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
