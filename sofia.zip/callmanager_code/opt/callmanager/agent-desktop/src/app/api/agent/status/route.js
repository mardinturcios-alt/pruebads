// app/api/agent/status/route.js — Cambiar estado del agente
import { NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { getDb, AGENTS_COL } from '@/lib/firestore';
import { pauseAgentInQueue } from '@/lib/ami'; // 🔥 Importamos el puente de Asterisk

const VALID_STATUSES = ['available', 'busy', 'oncall', 'paused', 'offline', 'bathroom', 'lunch'];

export async function POST(req) {
  const session = await getCurrentSession();
  if (!session) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

  const { status } = await req.json();
  if (!VALID_STATUSES.includes(status)) {
    return NextResponse.json({ error: 'Estado inválido' }, { status: 400 });
  }

  const db = getDb();
  const agentRef = db.collection(AGENTS_COL).doc(session.agentId);

  // 1️⃣ Guardamos el estado en Firestore (para la UI y reportes)
  await agentRef.update({
    status,
    statusUpdatedAt: new Date().toISOString(),
  });

  // 2️⃣ Buscamos la extensión del agente
  const agentDoc = await agentRef.get();
  const extension = agentDoc.data()?.extension;

  // 3️⃣ Le avisamos a Asterisk en tiempo real
  if (extension) {
    // Si el estado es "available", lo despausamos (false). Para todo lo demás, lo pausamos (true).
    const isPaused = status !== 'available';
    
    try {
      await pauseAgentInQueue(extension, isPaused, status);
    } catch (error) {
      console.error('⚠️ [API] No se pudo comunicar con Asterisk:', error);
      // Retornamos ok porque sí se guardó en BD, pero enviamos un warning
      return NextResponse.json({ 
        ok: true, 
        status, 
        warning: 'Estado en BD actualizado, pero falló la conexión con Asterisk' 
      });
    }
  }

  return NextResponse.json({ ok: true, status });
}
