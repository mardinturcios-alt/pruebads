import { NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { DocumentServiceClient } from '@google-cloud/discoveryengine';

const PROJECT_ID = process.env.GCP_PROJECT_ID; 
const LOCATION = 'global';

// Función auxiliar para obtener el Data Store ID correcto
function getDataStoreId(baseType) {
  if (baseType === 'tech') {
    return process.env.GCP_DATA_STORE_TECH || 'callmanager-kb-tech';
  }
  return process.env.GCP_DATA_STORE_BASIC || 'callmanager-kb-v2';
}

// 🔍 1. LEER DOCUMENTOS (Soporta ?base=basic o ?base=tech)
export async function GET(req) {
  const session = await getCurrentSession();
  if (!session || !['admin', 'admin-agent'].includes(session.role)) {
    return NextResponse.json({ error: 'Acceso denegado' }, { status: 403 });
  }

  try {
    if (!PROJECT_ID) throw new Error('GCP_PROJECT_ID no configurado');

    // Leemos el parámetro de la URL (?base=tech o ?base=basic)
    const { searchParams } = new URL(req.url);
    const baseType = searchParams.get('base') || 'basic';
    const dataStoreId = getDataStoreId(baseType);

    const client = new DocumentServiceClient();
    const parent = `projects/${PROJECT_ID}/locations/${LOCATION}/collections/default_collection/dataStores/${dataStoreId}/branches/default_branch`;

    const [documents] = await client.listDocuments({ parent });

    const formattedDocs = documents.map(doc => {
      const id = doc.name.split('/').pop();
      const fields = doc.structData?.fields || {};
const title = fields.title?.stringValue || 'Documento sin título';
      const content = fields.content?.stringValue || 'Contenido no disponible.';

      return { id, title, content, date: 'Indexado en GCP' };
    });

    return NextResponse.json({ ok: true, documents: formattedDocs });

  } catch (error) {
    console.error("☁️ [Vertex AI] Error listando conocimiento:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// 🚀 2. INYECTAR CONOCIMIENTO (Recibe "base" en el cuerpo del JSON)
export async function POST(req) {
  const session = await getCurrentSession();
  if (!session || !['admin', 'admin-agent'].includes(session.role)) {
    return NextResponse.json({ error: 'Acceso denegado' }, { status: 403 });
  }

  try {
    const { title, content, base } = await req.json();

    if (!title || !content) {
      return NextResponse.json({ error: 'Título y contenido son obligatorios' }, { status: 400 });
    }

    if (!PROJECT_ID) {
      return NextResponse.json({ error: 'Error de servidor: GCP_PROJECT_ID no configurado' }, { status: 500 });
    }

    const dataStoreId = getDataStoreId(base);
    const client = new DocumentServiceClient();
    const documentId = `doc-${Date.now()}`;
    const parent = `projects/${PROJECT_ID}/locations/${LOCATION}/collections/default_collection/dataStores/${dataStoreId}/branches/default_branch`;

    const document = {
      id: documentId,
      structData: { fields: { title: { stringValue: title }, content: { stringValue: content } } }
    };

    const request = { parent, document, documentId };
    
    console.log(`Inyectando en Vertex AI. Destino: ${dataStoreId}`);
    const [response] = await client.createDocument(request);

    return NextResponse.json({ ok: true, message: 'Documento inyectado con éxito', documentId: response.id });

  } catch (error) {
    console.error("☁️ [Vertex AI] Error inyectando conocimiento:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// 🗑️ 3. ELIMINAR CONOCIMIENTO
export async function DELETE(req) {
  const session = await getCurrentSession();
  if (!session || !['admin', 'admin-agent'].includes(session.role)) {
    return NextResponse.json({ error: 'Acceso denegado' }, { status: 403 });
  }

  try {
    const { searchParams } = new URL(req.url);
    const base = searchParams.get('base') || 'basic';
    const docId = searchParams.get('id');

    if (!docId) return NextResponse.json({ error: 'ID requerido' }, { status: 400 });
    
    const client = new DocumentServiceClient();
    const dataStoreId = getDataStoreId(base);
    const name = `projects/${PROJECT_ID}/locations/${LOCATION}/collections/default_collection/dataStores/${dataStoreId}/branches/default_branch/documents/${docId}`;

    await client.deleteDocument({ name });
    return NextResponse.json({ ok: true, message: 'Eliminado con éxito' });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// ✏️ 4. EDITAR CONOCIMIENTO (Upsert)
export async function PUT(req) {
  const session = await getCurrentSession();
  if (!session || !['admin', 'admin-agent'].includes(session.role)) {
    return NextResponse.json({ error: 'Acceso denegado' }, { status: 403 });
  }

  try {
    const { id, title, content, base } = await req.json();
    if (!id || !title || !content) return NextResponse.json({ error: 'Faltan datos' }, { status: 400 });

    const client = new DocumentServiceClient();
    const dataStoreId = getDataStoreId(base);
    
    // Eliminamos la versión vieja primero (si existe)
    const name = `projects/${PROJECT_ID}/locations/${LOCATION}/collections/default_collection/dataStores/${dataStoreId}/branches/default_branch/documents/${id}`;
    try { await client.deleteDocument({ name }); } catch(e) { /* Si no existe, lo ignoramos */ }

    // Creamos la versión nueva con el mismo ID y el nuevo contenido
    const document = {
      id: id,
      structData: { fields: { title: { stringValue: title }, content: { stringValue: content } } }
    };
    
    const parent = `projects/${PROJECT_ID}/locations/${LOCATION}/collections/default_collection/dataStores/${dataStoreId}/branches/default_branch`;
    await client.createDocument({ parent, document, documentId: id });

    return NextResponse.json({ ok: true, message: 'Documento actualizado' });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
