
import { NextResponse } from 'next/server';
import { getDb } from '@/lib/firestore'; 

// Intentamos importar bcrypt. (Si usas bcryptjs en tu proyecto, cámbialo a 'bcryptjs')
import bcrypt from 'bcryptjs';

export async function GET() {
  try {
    const db = getDb();
    
    // Encriptamos la contraseña "123456" para el inicio de sesión web
    const passwordHash = await bcrypt.hash('123456', 10);
    
    // Creamos el documento en Firebase
    await db.collection('agents').doc('agente8001').set({
      username: 'agente001',
      passwordHash: passwordHash,
      extension: '8001',
      sipPassword: 'SMNSRtcVSi', // 👈 ¡Exactamente la que tienes en pjsip.conf!
      fullName: 'Mardin Turcios',
      email: 'agente001@davivienda.com',
      role: 'agent',
      status: 'available',
      createdAt: new Date().toISOString()
    });
    
    return NextResponse.json({ 
      exito: true, 
      mensaje: '¡Usuario creado perfectamente! Ve a /login y usa agente001 / 123456' 
    });

  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
