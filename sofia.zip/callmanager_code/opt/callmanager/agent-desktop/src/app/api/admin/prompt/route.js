import { NextResponse } from 'next/server';

// Buscamos la URL de tu Orquestador en las variables de entorno, o usamos el puerto local por defecto
const BACKEND_URL = process.env.API_URL || process.env.BACKEND_URL || 'http://127.0.0.1:8080';

export async function GET() {
  try {
    const res = await fetch(`${BACKEND_URL}/api/admin/prompt`);
    if (!res.ok) throw new Error('Error conectando al Orquestador');
    
    const data = await res.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error("[Next.js] Error en puente GET Prompt:", error);
    // Texto de respaldo temporal por si el Orquestador tarda en responder
    return NextResponse.json({ prompt: "Eres Sofía, asistente virtual de Davivienda." });
  }
}

export async function POST(req) {
  try {
    const body = await req.json();
    const res = await fetch(`${BACKEND_URL}/api/admin/prompt`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body)
    });
    
    const data = await res.json();
    return NextResponse.json(data);
  } catch (error) {
    console.error("[Next.js] Error en puente POST Prompt:", error);
    return NextResponse.json({ error: 'Error guardando en el servidor' }, { status: 500 });
  }
}
