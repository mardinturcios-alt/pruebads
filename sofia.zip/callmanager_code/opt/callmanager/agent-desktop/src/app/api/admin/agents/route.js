import { NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { getDb } from '@/lib/firestore';
import bcrypt from 'bcryptjs';
import { Pool } from 'pg';

// Configuración de conexión a PostgreSQL (Asterisk Realtime)
const pgPool = new Pool({
  user: 'asterisk_user',
  host: 'localhost',
  database: 'davitel_db',
  password: 'Asterisk2026*',
  port: 5432,
});
// Función auxiliar para registrar/actualizar la extensión en Asterisk PJSIP
async function syncPjsipRealtime(extension, sipPassword, maxLines = 1) {
  if (!extension || !sipPassword) return;

  const authId = `${extension}-auth`;
  const lines = parseInt(maxLines) || 1;

  // 1. Guardar o actualizar AOR (Líneas simultáneas)
  await pgPool.query(
    `INSERT INTO ps_aors (id, max_contacts, remove_existing)
     VALUES ($1, $2, 'yes')
     ON CONFLICT (id) DO UPDATE SET max_contacts = EXCLUDED.max_contacts`,
    [extension, lines]
  );

  // 2. Guardar o actualizar Autenticación SIP
  await pgPool.query(
    `INSERT INTO ps_auths (id, auth_type, username, password)
     VALUES ($1, 'userpass', $2, $3)
     ON CONFLICT (id) DO UPDATE SET password = EXCLUDED.password`,
    [authId, extension, sipPassword]
  );

  // 3. Guardar Endpoint WebRTC
  await pgPool.query(
    `INSERT INTO ps_endpoints (
        id, transport, aors, auth, context, disallow, allow,
        webrtc, dtls_auto_generate_cert, rtp_symmetric, force_rport,
        rewrite_contact, direct_media, rtp_timeout, rtp_timeout_hold, rtp_keepalive
    ) VALUES (
        $1, 'transport-ws', $1, $2, 'from-internal', 'all', 'ulaw',
        'yes', 'yes', 'yes', 'yes',
        'yes', 'no', 30, 120, 10
    ) ON CONFLICT (id) DO NOTHING`,
    [extension, authId]
  );

  console.log(`[PJSIP Realtime] Extensión ${extension} sincronizada correctamente.`);
}

// Habilitamos roles administrativos
const ALLOWED_ROLES = ['admin', 'admin-agent'];

// 🔍 1. LEER TODOS LOS AGENTES
export async function GET() {
  const session = await getCurrentSession();
  if (!session || !ALLOWED_ROLES.includes(session.role)) {
    return NextResponse.json({ error: 'Acceso denegado. Se requiere rol administrativo.' }, { status: 403 });
  }

  try {
    const db = getDb();
    const snap = await db.collection('agents').get();
    const agents = snap.docs.map(doc => {
      const data = doc.data();
      return { id: doc.id, ...data, passwordHash: undefined };
    });
    return NextResponse.json({ agents });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// 🚀 2. CREAR NUEVO AGENTE
export async function POST(req) {
  const session = await getCurrentSession();
  if (!session || !ALLOWED_ROLES.includes(session.role)) {
    return NextResponse.json({ error: 'Acceso denegado.' }, { status: 403 });
  }

  try {
    const data = await req.json();
    const db = getDb();

    const password = data.webPassword || data.password;
    const role = data.role || 'agent';
    const isPhoneUser = ['agent', 'admin-agent'].includes(role);

    if (!data.username || !password) {
      return NextResponse.json({ error: 'Faltan datos requeridos (Usuario y Contraseña Web)' }, { status: 400 });
    }

    if (isPhoneUser && (!data.extension || !data.sipPassword)) {
      return NextResponse.json({ error: 'Para este rol se requiere Extensión y SIP Password' }, { status: 400 });
    }

    const passwordHash = await bcrypt.hash(password, 10);
    const docId = data.extension ? `agente${data.extension}` : data.username;

    const newAgent = {
      username: data.username,
      passwordHash: passwordHash,
      extension: data.extension || '',
      sipPassword: data.sipPassword || '',
      fullName: data.fullName || 'Usuario Nuevo',
      email: data.email || `${data.username}@davivienda.com`,
      role: role,
      status: 'offline',
      maxLines: parseInt(data.maxLines) || 1,
      createdAt: new Date().toISOString()
    };

    // 1. Guardar en Firestore (Usuario Web / Panel Admin)
    await db.collection('agents').doc(docId).set(newAgent);

    // 2. Sincronizar en PostgreSQL (Asterisk Realtime PJSIP)
    if (isPhoneUser && data.extension && data.sipPassword) {
      await syncPjsipRealtime(data.extension, data.sipPassword, data.maxLines);
    }

    return NextResponse.json({ ok: true, agent: { ...newAgent, passwordHash: undefined } });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// 📝 3. ACTUALIZAR AGENTE EXISTENTE
export async function PUT(req) {
  const session = await getCurrentSession();
  if (!session || !ALLOWED_ROLES.includes(session.role)) {
    return NextResponse.json({ error: 'Acceso denegado.' }, { status: 403 });
  }

  try {
    const data = await req.json();
    const db = getDb();
    const { id, fullName, email, webPassword, role, maxLines, sipPassword } = data;

    if (!id) {
      return NextResponse.json({ error: 'Falta el ID del documento para actualizar' }, { status: 400 });
    }

    const agentRef = db.collection('agents').doc(id);
    const snap = await agentRef.get();

    if (!snap.exists) {
      return NextResponse.json({ error: 'El usuario no existe en la base de datos' }, { status: 404 });
    }

    const agentData = snap.data();
    const updateData = {
      fullName: fullName || agentData.fullName,
      email: email || '',
      role: role || 'agent',
      maxLines: parseInt(maxLines) || agentData.maxLines || 1,
      sipPassword: sipPassword || agentData.sipPassword || '',
      statusUpdatedAt: new Date().toISOString()
    };

    if (webPassword && webPassword.trim() !== '') {
      updateData.passwordHash = await bcrypt.hash(webPassword, 10);
    }

    // 1. Actualizar en Firestore
    await agentRef.update(updateData);

    // 2. Actualizar o sincronizar en PostgreSQL PJSIP
    const targetExtension = agentData.extension;
    const targetSipPassword = sipPassword || agentData.sipPassword;
    const targetMaxLines = maxLines || agentData.maxLines;

    if (targetExtension && targetSipPassword) {
      await syncPjsipRealtime(targetExtension, targetSipPassword, targetMaxLines);
    }

    return NextResponse.json({ ok: true, message: 'Usuario actualizado correctamente' });
  } catch (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
