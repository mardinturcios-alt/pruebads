// app/api/auth/me/route.js — Datos del agente logueado (con sipPassword)
import { NextResponse } from 'next/server';
import { getCurrentAgent } from '@/lib/auth';

export async function GET() {
  const agent = await getCurrentAgent();
  if (!agent) {
    return NextResponse.json({ error: 'No autenticado' }, { status: 401 });
  }

  return NextResponse.json({
    id:          agent.id,
    username:    agent.username,
    fullName:    agent.fullName,
    email:       agent.email,
    extension:   agent.extension,
    sipPassword: agent.sipPassword,
    role:        agent.role,
    maxLines:    agent.maxLines || 1, // 🔥 ¡NUEVA LÍNEA AGREGADA!
  });
}
