// app/api/calls/queue/route.js — Lista de llamadas escaladas
import { NextResponse } from 'next/server';
import { getCurrentSession } from '@/lib/auth';
import { getDb, SESSIONS_COL } from '@/lib/firestore';

export async function GET() {
  const session = await getCurrentSession();
  if (!session) return NextResponse.json({ error: 'No autenticado' }, { status: 401 });

  const db   = getDb();
  const snap = await db.collection(SESSIONS_COL)
    .where('status', '==', 'escalated')
    .orderBy('startedAt', 'asc')
    .limit(50)
    .get();

  const calls = snap.docs.map(doc => ({
    callId: doc.id,
    ...doc.data(),
  }));

  return NextResponse.json({ calls });
}
