'use client';

import { useEffect, useRef, useCallback } from 'react';
import { useAgentStore } from '@/store/agentStore';

let JsSIP = null;
if (typeof window !== 'undefined') {
  JsSIP = require('jssip');
}

export function useSoftphone(creds) {
  const uaRef    = useRef(null);
  const audioRef = useRef(null);
  
  // 🚀 EL SECRETO: Almacén de sesiones nativas intactas (Previene bugs de Zustand)
  const sessionsMapRef = useRef({});

  const setSipStatus    = useAgentStore((s) => s.setSipStatus);
  const setIncomingCall = useAgentStore((s) => s.setIncomingCall);

  useEffect(() => {
    if (!creds || !JsSIP) return;

    if (!audioRef.current) {
      const audio = document.createElement('audio');
      audio.id = 'sip-remote-audio';
      audio.autoplay = true;
      audio.controls = true;
      audio.style.display = 'none';
      document.body.appendChild(audio);
      audioRef.current = audio;
    }

    const socket = new JsSIP.WebSocketInterface(creds.wssUrl);
    const config = {
      sockets:        [socket],
      uri:            `sip:${creds.extension}@${creds.domain}`,
      password:       creds.password,
      register:       true,
      session_timers: false,
      user_agent:     'CallManagerAgent/Multilínea'
    };

    const ua = new JsSIP.UA(config);

    ua.on('connecting',         () => setSipStatus('connecting'));
    ua.on('connected',          () => setSipStatus('connecting'));
    ua.on('registered',         () => setSipStatus('registered'));
    ua.on('unregistered',       () => setSipStatus('unregistered'));
    ua.on('registrationFailed', (e) => { setSipStatus('error'); });
    ua.on('disconnected',       () => setSipStatus('disconnected'));

    ua.on('newRTCSession', (data) => {
      const session = data.session;
      const request = data.request;

      if (session.direction !== 'incoming') return;

      const currentState = useAgentStore.getState();
      const currentCallsCount = currentState.calls.length;
      const maxAllowed = Number(currentState.maxLines) || Number(creds.maxLines) || 1;

      console.log(`🛡️ [ESCUDO INBOUND] Activas: ${currentCallsCount} | Permitidas: ${maxAllowed}`);

      if (currentCallsCount >= maxAllowed) {
        console.log(`🛑 [RECHAZADO] Límite de ${maxAllowed} alcanzado. Enviando 486 Busy.`);
        session.terminate({ status_code: 486, reason_phrase: 'Busy Here' });
        return;
      }

      const fromNumber = session.remote_identity.uri.user;
      const callId     = request?.getHeader?.('X-Session-Id') || 'inbound-' + Date.now();

      // Guardamos en el almacén nativo seguro
      sessionsMapRef.current[callId] = session;

      setIncomingCall({ session, fromNumber, callId });

      session.on('peerconnection', (e) => {
        const pc = e.peerconnection;
        pc.addEventListener('track', (ev) => {
          if (audioRef.current) {
            const remoteStream = (ev.streams && ev.streams[0]) ? ev.streams[0] : new MediaStream([ev.track]);
            audioRef.current.srcObject = remoteStream;
            audioRef.current.play().catch(() => {});
          }
        });
      });

      const handleCallEnd = () => {
        // Limpiamos almacén nativo
        delete sessionsMapRef.current[callId];
        useAgentStore.getState().removeCall(callId);
        if (useAgentStore.getState().incomingCall?.callId === callId) {
            setIncomingCall(null);
        }
      };

      session.on('ended',      handleCallEnd);
      session.on('failed',     handleCallEnd);
      session.on('terminated', handleCallEnd);
    });

    ua.start();
    uaRef.current = ua;

    return () => {
      ua.stop();
      uaRef.current = null;
    };
  }, [creds, setSipStatus, setIncomingCall]);

  const answerCall = useCallback(() => {
    const state = useAgentStore.getState();
    const incoming = state.incomingCall;
    if (!incoming) return;

    state.calls.forEach(c => {
       if (c.status === 'connected') {
           const s = sessionsMapRef.current[c.id];
           if (s) s.hold();
           state.updateCallStatus(c.id, 'onhold');
       }
    });

    incoming.session.answer({ mediaConstraints: { audio: true, video: false } });
    const now = new Date().toISOString();

    state.addCall({
      id: incoming.callId,
      direction: 'inbound',
      callerNumber: incoming.fromNumber,
      status: 'connected',
      startedAt: now,
      isMuted: false
    });

    setIncomingCall(null);
  }, [setIncomingCall]);

  const hangupCall = useCallback((specificCallId = null) => {
    const state = useAgentStore.getState();

    if (state.incomingCall?.session) {
      state.incomingCall.session.terminate();
      setIncomingCall(null);
      return;
    }

    const targetId = specificCallId || state.activeLineId || state.activeCall?.id;
    let sessionToTerminate = sessionsMapRef.current[targetId];

    if (!sessionToTerminate && uaRef.current) {
        const sessions = Object.values(uaRef.current._sessions);
        if (sessions.length > 0) sessionToTerminate = sessions[0];
    }

    if (sessionToTerminate) {
      const pc = sessionToTerminate.connection;
      if (pc) {
        pc.getSenders().forEach((s) => { if (s.track) s.track.stop(); });
        pc.getReceivers().forEach((r) => { if (r.track) r.track.stop(); });
      }
      sessionToTerminate.terminate();
    }

    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.srcObject = null;
    }

    if (targetId) {
      delete sessionsMapRef.current[targetId];
      state.removeCall(targetId);
    }
  }, [setIncomingCall]);

  const makeCall = useCallback((targetExt) => {
    const state = useAgentStore.getState();
    if (!uaRef.current || !targetExt) return;

    const maxAllowed = Number(state.maxLines) || Number(creds?.maxLines) || 1;
    if (state.calls.length >= maxAllowed) {
        console.warn(`🛑 Límite de ${maxAllowed} líneas alcanzado.`);
        return;
    }

    state.calls.forEach(c => {
       if (c.status === 'connected') {
           const s = sessionsMapRef.current[c.id];
           if (s) s.hold();
           state.updateCallStatus(c.id, 'onhold');
       }
    });

    const targetUri = `sip:${targetExt}@${creds.domain}`;
    const options = { mediaConstraints: { audio: true, video: false } };
    const session = uaRef.current.call(targetUri, options);
    const callId = 'outbound-' + Date.now();

    if (session) {
      // Guardamos de inmediato en el almacén seguro nativo
      sessionsMapRef.current[callId] = session;

      session.on('peerconnection', (e) => {
        const pc = e.peerconnection;
        pc.addEventListener('track', (ev) => {
          if (audioRef.current) {
            const remoteStream = (ev.streams && ev.streams[0]) ? ev.streams[0] : new MediaStream([ev.track]);
            audioRef.current.srcObject = remoteStream;
            audioRef.current.play().catch(() => {});
          }
        });
      });

      const handleCallEnd = () => { 
        delete sessionsMapRef.current[callId];
        useAgentStore.getState().removeCall(callId); 
      };
      
      session.on('ended',      handleCallEnd);
      session.on('failed',     handleCallEnd);
      session.on('terminated', handleCallEnd);

      session.on('accepted', () => {
        const pc = session.connection;
        if (pc) {
          const remoteStream = new MediaStream();
          pc.getReceivers().forEach((r) => {
            if (r.track && r.track.kind === 'audio') remoteStream.addTrack(r.track);
          });
          if (audioRef.current && remoteStream.getTracks().length > 0) {
            audioRef.current.srcObject = remoteStream;
            audioRef.current.play().catch(() => {});
          }
        }

        const now = new Date().toISOString();
        useAgentStore.setState(s => ({
            calls: s.calls.map(c => c.id === callId ? { ...c, status: 'connected', startedAt: now } : c),
            activeCall: s.activeCall?.id === callId ? { ...s.activeCall, status: 'connected', startedAt: now } : s.activeCall
        }));
      });

      state.addCall({ id: callId, direction: 'outbound', callerNumber: targetExt, status: 'calling', startedAt: null, isMuted: false });
    }
  }, [creds]);

  const toggleMute = useCallback((specificCallId = null) => {
    const state = useAgentStore.getState();
    const targetId = specificCallId || state.activeLineId || state.activeCall?.id;
    let isCurrentlyMuted = false;

    useAgentStore.setState(s => ({
      calls: s.calls.map(c => {
        if (c.id === targetId) {
          isCurrentlyMuted = !c.isMuted;
          const sCall = sessionsMapRef.current[targetId];
          if (sCall?.connection) {
            sCall.connection.getSenders().forEach(sender => {
              if (sender.track && sender.track.kind === 'audio') {
                sender.track.enabled = !isCurrentlyMuted;
              }
            });
          }
          return { ...c, isMuted: isCurrentlyMuted };
        }
        return c;
      })
    }));

    return isCurrentlyMuted;
  }, []);

  // 🔀 TRANSFERENCIA CIEGA MEJORADA
  const transferCall = useCallback((targetExt, callId) => {
    const state = useAgentStore.getState();
    const nativeSession = sessionsMapRef.current[callId];

    if (nativeSession) {
      console.log(`[TRANSFER] Enviando cliente a ${targetExt} de forma segura...`);
      const domain = creds.domain;
      nativeSession.refer(`sip:${targetExt}@${domain}`);

      setTimeout(() => {
        nativeSession.terminate();
        delete sessionsMapRef.current[callId];
        state.removeCall(callId);
      }, 500);
    }
  }, [creds]);

// 🔀 TRANSFERENCIA ASISTIDA NATIVA DE ALTA PRECISIÓN (FIX CON STRINGS PUROS)
  const attendedTransfer = useCallback((sourceCallId, targetCallId) => {
    const state = useAgentStore.getState();
    
    // Extraemos las sesiones nativas
    const sourceSession = sessionsMapRef.current[sourceCallId];
    const targetSession = sessionsMapRef.current[targetCallId];

    if (sourceSession && targetSession) {
      console.log(`🔄 [TRANSFER ASISTIDO NATIVO] Puenteando llamadas vía Header Replaces...`);
      
      try {
        // Accedemos de forma segura al diálogo e identificadores internos de la llamada B (técnico)
        const dialog = targetSession.dialog || targetSession._dialog;
        
        if (dialog && dialog.id) {
          const callId    = dialog.id.call_id;
          const remoteTag = dialog.id.remote_tag;
          const localTag  = dialog.id.local_tag;

          // Construimos el "ticket" de reemplazo idéntico a como lo exige el protocolo SIP
          const replacesStr = `${callId};to-tag=${remoteTag};from-tag=${localTag}`;
          
          const domain = targetSession.remote_identity.uri.host;
          const user   = targetSession.remote_identity.uri.user;
          
          // Creamos la URI mágica que Asterisk procesará de inmediato
          const targetUri = `sip:${user}@${domain}?Replaces=${encodeURIComponent(replacesStr)}`;
          
          console.log(`🚀 [AMI/SIP] Transfiriendo sesión original a: ${targetUri}`);
          sourceSession.refer(targetUri);
        } else {
          // Si por alguna razón el diálogo interno no está expuesto, usamos el plan B por ID de sesión
          console.warn(`⚠️ Diálogo de JsSIP no expuesto completamente, usando fallback de sesión.`);
          sourceSession.refer(targetSession);
        }

// Nos retiramos del medio de la llamada para que hablen entre ellos (silenciando errores si Asterisk fue más rápido)
        setTimeout(() => {
          try {
            if (!sourceSession.isEnded()) sourceSession.terminate();
          } catch (e) {} // Ignoramos si ya estaba colgada
          
          try {
            if (!targetSession.isEnded()) targetSession.terminate();
          } catch (e) {} // Ignoramos si ya estaba colgada

          delete sessionsMapRef.current[sourceCallId];
          delete sessionsMapRef.current[targetCallId];
          state.removeCall(sourceCallId);
          state.removeCall(targetCallId);
          
          if (useAgentStore.getState().calls.length === 0) {
            state.setStatus('available');
          }
        }, 1000);
      } catch (e) {
        console.error("❌ Error en puente asistido nativo:", e);
      }
    } else {
      console.error("❌ Error catastrófico: Las sesiones nativas ya no existen en el mapa.");
    }
  }, []);

  const holdCall = useCallback((specificCallId = null) => {
    const state = useAgentStore.getState();
    const targetId = specificCallId || state.activeLineId || state.activeCall?.id;
    const nativeSess = sessionsMapRef.current[targetId];
    if (nativeSess) {
        nativeSess.hold();
        state.updateCallStatus(targetId, 'onhold');
    }
  }, []);

  const unholdCall = useCallback((specificCallId = null) => {
    const state = useAgentStore.getState();
    const targetId = specificCallId || state.activeLineId || state.activeCall?.id;

    state.calls.forEach(c => {
       if (c.id !== targetId && c.status === 'connected') {
           const s = sessionsMapRef.current[c.id];
           if (s) s.hold();
           state.updateCallStatus(c.id, 'onhold');
       }
    });

    const nativeSess = sessionsMapRef.current[targetId];
    if (nativeSess) {
        nativeSess.unhold();
        state.updateCallStatus(targetId, 'connected');

        setTimeout(() => {
          const checkCall = state.calls.find(c => c.id === targetId);
          if (checkCall?.isMuted && nativeSess.connection) {
             nativeSess.connection.getSenders().forEach(sender => {
                if (sender.track && sender.track.kind === 'audio') {
                   sender.track.enabled = false;
                }
             });
          }
        }, 150);
    }
  }, []);

  return { answerCall, hangupCall, makeCall, toggleMute, transferCall, holdCall, unholdCall, attendedTransfer };
}
