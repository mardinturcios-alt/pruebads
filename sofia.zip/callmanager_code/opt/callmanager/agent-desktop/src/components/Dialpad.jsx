'use client';
import { useState } from 'react';

export function Dialpad({ makeCall, transferCall, isOnCall }) {
  const [dialNumber, setDialNumber] = useState('');

  const handleNumpad = (num) => setDialNumber((prev) => prev + num.toString());

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <h3 className="font-bold flex items-center gap-2 mb-4">📞 Teclado Telefónico</h3>
      <input
        type="text"
        value={dialNumber}
        onChange={(e) => setDialNumber(e.target.value)}
        placeholder="Extensión..."
        className="w-full text-center p-3 border rounded-lg mb-4 text-xl font-mono focus:ring-2 focus:ring-red-500 focus:outline-none"
      />
      <div className="grid grid-cols-3 gap-3">
        {[1, 2, 3, 4, 5, 6, 7, 8, 9, '*', 0, '#'].map((num) => (
          <button
            key={num}
            onClick={() => handleNumpad(num)}
            className="p-4 bg-gray-50 hover:bg-gray-100 border rounded-lg text-xl font-semibold text-gray-700 transition-colors"
          >
            {num}
          </button>
        ))}
      </div>

      <button
        onClick={() => {
          if (dialNumber) {
            if (isOnCall) {
              transferCall(dialNumber);
              setDialNumber('');
            } else {
              makeCall(dialNumber);
            }
          }
        }}
        className={`w-full mt-4 font-bold py-3 rounded-lg shadow-sm flex justify-center items-center gap-2 transition-all ${
          dialNumber
            ? (isOnCall ? 'bg-blue-500 hover:bg-blue-600' : 'bg-green-500 hover:bg-green-600') + ' text-white cursor-pointer'
            : 'bg-gray-300 text-gray-500 cursor-not-allowed'
        }`}
      >
        <span>
          {dialNumber ? (isOnCall ? `Transferir a ${dialNumber}` : `Llamar a ${dialNumber}`) : 'Ingresa Extensión'}
        </span>
      </button>
    </div>
  );
}
