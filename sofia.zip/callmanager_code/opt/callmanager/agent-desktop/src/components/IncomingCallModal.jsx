// components/IncomingCallModal.jsx
'use client';

import { Phone, PhoneOff } from 'lucide-react';
import { useAgentStore } from '@/store/agentStore';

export function IncomingCallModal({ onAnswer, onReject }) {
  const incoming = useAgentStore((s) => s.incomingCall);

  if (!incoming) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-sm w-full mx-4 text-center">
        <div className="inline-flex items-center justify-center w-20 h-20 rounded-full bg-green-500 mb-4 animate-ringing shadow-lg shadow-green-500/30">
          <Phone className="w-10 h-10 text-white" />
        </div>

        <p className="text-sm text-davivienda-gray-500 mb-1 font-bold uppercase tracking-wider">Llamada Entrante</p>
        <p className="text-3xl font-black text-davivienda-gray-900 mb-6">
          {incoming.fromNumber}
        </p>

        <div className="flex items-center justify-center gap-6">
          <button
            onClick={onReject}
            className="w-16 h-16 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center transition hover:scale-110 shadow-md"
            title="Rechazar"
          >
            <PhoneOff className="w-7 h-7" />
          </button>

          <button
            onClick={onAnswer}
            className="w-16 h-16 rounded-full bg-green-500 hover:bg-green-600 text-white flex items-center justify-center transition hover:scale-110 shadow-md"
            title="Atender"
          >
            <Phone className="w-7 h-7" />
          </button>
        </div>
      </div>
    </div>
  );
}
