'use client';

import { useState, useRef, useEffect } from 'react';
import { Search, Bot, User, Loader2, FileText, Sparkles, ShieldAlert, Layers } from 'lucide-react';

export function KnowledgeBase() {
  const [query, setQuery] = useState('');
  const [searchTarget, setSearchTarget] = useState('basic'); // 'basic' o 'tech'
  const [isSearching, setIsSearching] = useState(false);
  const [chatHistory, setChatHistory] = useState([
    {
      role: 'ai',
      content: 'Hola. Soy Sofía, tu asistente de soporte. ¿Qué información o procedimiento necesitas validar hoy?',
      sources: []
    }
  ]);

  const messagesEndRef = useRef(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const handleSearch = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;

    const userMsg = query;
    const targetedBase = searchTarget; // Se usa para la llamada a la API
    setQuery('');
    
    setChatHistory(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsSearching(true);

    try {
      const res = await fetch('/api/agent/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: userMsg, base: targetedBase })
      });
      const data = await res.json();

      if (!res.ok) throw new Error(data.error);

      if (data.results && data.results.length > 0) {
        const topResult = data.results[0];
        
        const prefix = targetedBase === 'tech' 
          ? `🚨 **[MANUAL TÉCNICO AVANZADO]** Detectado en la base de Ingeniería para **"${topResult.title}"**:\n\n`
          : `📚 Según el manual base **"${topResult.title}"**, aquí está la información:\n\n`;

        const aiResponse = `${prefix}${topResult.content}`;
        
        setChatHistory(prev => [...prev, { 
          role: 'ai', 
          content: aiResponse,
          sources: data.results
        }]);
      } else {
        setChatHistory(prev => [...prev, { 
          role: 'ai', 
          content: `No encontré coincidencias en la Base ${targetedBase === 'basic' ? 'Básica' : 'Técnica'}. Intenta alternar el tipo de búsqueda o escribir palabras clave alternativas.`,
          sources: []
        }]);
      }

    } catch (error) {
      setChatHistory(prev => [...prev, { role: 'ai', content: 'Error al conectar con la base de conocimiento de GCP.', sources: [] }]);
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="max-w-5xl mx-auto flex flex-col h-[85vh] animate-fadeIn">
      
      {/* Cabecera */}
      <div className="flex items-center justify-between bg-white p-5 rounded-t-2xl border border-gray-200 shadow-sm z-10">
        <div className="flex items-center gap-4">
          <div className="w-11 h-11 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-xl flex items-center justify-center text-white shadow-md">
            <Layers className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-gray-900">Asistencia Inteligente al Agente</h2>
            <p className="text-xs text-gray-500">Consulta procedimientos e instrucciones segmentadas por criticidad.</p>
          </div>
        </div>

        {/* Switch de Búsqueda rápido */}
        <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200">
          <button 
            onClick={() => setSearchTarget('basic')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${searchTarget === 'basic' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-500 hover:text-gray-800'}`}
          >
            <Sparkles className="w-3.5 h-3.5" /> General
          </button>
          <button 
            onClick={() => setSearchTarget('tech')}
            className={`px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${searchTarget === 'tech' ? 'bg-white text-purple-600 shadow-sm' : 'text-gray-500 hover:text-gray-800'}`}
          >
            <ShieldAlert className="w-3.5 h-3.5" /> Técnico (Root)
          </button>
        </div>
      </div>

      {/* Historial de Chat */}
      <div className="flex-1 bg-gray-50 border-x border-gray-200 overflow-y-auto p-6 flex flex-col gap-6">
        {chatHistory.map((msg, idx) => (
          <div key={idx} className={`flex gap-4 max-w-[85%] ${msg.role === 'user' ? 'ml-auto flex-row-reverse' : ''}`}>
            
            {/* CORRECCIÓN: Usamos searchTarget en lugar de targetedBase */}
            <div className={`w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0 shadow-sm ${msg.role === 'user' ? 'bg-red-600 text-white' : searchTarget === 'tech' ? 'bg-purple-600 text-white' : 'bg-indigo-600 text-white'}`}>
              {msg.role === 'user' ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
            </div>
            
            <div className={`flex flex-col gap-2 ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
              <div className={`p-4 rounded-2xl text-sm shadow-sm whitespace-pre-wrap leading-relaxed ${msg.role === 'user' ? 'bg-red-600 text-white rounded-tr-none' : 'bg-white border border-gray-200 text-gray-800 rounded-tl-none'}`}>
                {msg.content}
              </div>
              {msg.sources && msg.sources.length > 0 && (
                <div className="flex flex-col gap-1.5 w-full mt-1">
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider ml-1">Origen:</span>
                  <div className="flex flex-wrap gap-2">
                    {msg.sources.map((src, sIdx) => (
                      <div key={sIdx} className="flex items-center gap-1.5 bg-gray-100 border border-gray-200 text-gray-600 px-2.5 py-1.5 rounded-lg text-xs font-medium shadow-xs">
                        <FileText className="w-3.5 h-3.5 text-gray-400" /> {src.title}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}

        {isSearching && (
          <div className="flex gap-4 max-w-[85%] animate-pulse">
            <div className="w-9 h-9 rounded-full bg-gray-200 flex items-center justify-center flex-shrink-0">
              <Bot className="w-4 h-4 text-gray-400" />
            </div>
            <div className="p-4 rounded-2xl bg-white border border-gray-200 rounded-tl-none flex items-center gap-3 text-sm text-gray-400 font-medium">
              <Loader2 className="w-4 h-4 animate-spin text-gray-400" /> Consultado repositorio de conocimiento...
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input de Búsqueda */}
      <div className="bg-white p-4 rounded-b-2xl border border-gray-200 shadow-sm z-10">
        <form onSubmit={handleSearch} className="relative flex items-center">
          <div className="absolute left-4 text-gray-400"><Search className="w-5 h-5" /></div>
          <input 
            type="text" 
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            disabled={isSearching}
            placeholder={`Escribe tu duda para buscar en la Base ${searchTarget === 'basic' ? 'General' : 'Técnica Avanzada'}...`} 
            className={`w-full pl-12 pr-24 py-4 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:outline-none transition-all font-medium text-gray-800 ${searchTarget === 'basic' ? 'focus:ring-blue-500 focus:border-blue-500' : 'focus:ring-purple-500 focus:border-purple-500'}`}
          />
          <button type="submit" disabled={isSearching || !query.trim()} className={`absolute right-2 text-white px-5 py-2.5 rounded-lg font-bold transition-all shadow-sm ${searchTarget === 'basic' ? 'bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300' : 'bg-purple-600 hover:bg-purple-700 disabled:bg-purple-300'}`}>
            Buscar
          </button>
        </form>
      </div>

    </div>
  );
}
