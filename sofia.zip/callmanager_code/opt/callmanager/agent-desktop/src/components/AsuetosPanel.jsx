import React, { useState, useEffect } from 'react';

export default function AsuetosPanel() {
  const [horarios, setHorarios] = useState([]);
  const [asuetos, setAsuetos] = useState([]);
  const [fecha, setFecha] = useState('');
  const [descripcion, setDescripcion] = useState('');
  const [cargandoAsueto, setCargandoAsueto] = useState(false);
  const [editandoDia, setEditandoDia] = useState(null);

  // Estados temporales para edición de horarios
  const [tempApertura, setTempApertura] = useState('');
  const [tempCierre, setTempCierre] = useState('');
  const [tempActivo, setTempActivo] = useState(true);

  // Mapeo de días de la semana de PostgreSQL (0=Domingo, 1=Lunes...)
  const diasNombre = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

  // 🌍 TRUCO NINJA: Detecta automáticamente la IP o Dominio del servidor Davitel
  const getApiUrl = (endpoint) => {
    const host = typeof window !== 'undefined' ? window.location.hostname : 'localhost';
    return `http://${host}:8080/api/${endpoint}`;
  };

  useEffect(() => {
    fetchHorarios();
    fetchAsuetos();
  }, []);

  // --- API HORARIOS ---
  const fetchHorarios = async () => {
    try {
      const res = await fetch(getApiUrl('horarios'));
      const data = await res.json();
      setHorarios(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error al cargar horarios:', error);
    }
  };

  const iniciarEdicionHorario = (h) => {
    setEditandoDia(h.dia_semana);
    setTempApertura(h.hora_apertura);
    setTempCierre(h.hora_cierre);
    setTempActivo(h.activo);
  };

  const guardarHorario = async (diaSemana) => {
    try {
      const res = await fetch(getApiUrl(`horarios/${diaSemana}`), {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          hora_apertura: tempApertura,
          hora_cierre: tempCierre,
          activo: tempActivo
        })
      });
      if (res.ok) {
        setEditandoDia(null);
        fetchHorarios();
      }
    } catch (error) {
      console.error('Error al actualizar horario:', error);
    }
  };

  // --- API ASUETOS ---
  const fetchAsuetos = async () => {
    try {
      const res = await fetch(getApiUrl('asuetos'));
      const data = await res.json();
      setAsuetos(Array.isArray(data) ? data : []);
    } catch (error) {
      console.error('Error al cargar asuetos:', error);
    }
  };

  const agregarAsueto = async (e) => {
    e.preventDefault();
    setCargandoAsueto(true);
    try {
      const res = await fetch(getApiUrl('asuetos'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ fecha, descripcion })
      });
      if (res.ok) {
        setFecha('');
        setDescripcion('');
        fetchAsuetos();
      }
    } catch (error) {
      console.error('Error al guardar asueto:', error);
    }
    setCargandoAsueto(false);
  };

  const eliminarAsueto = async (id) => {
    if (!confirm('¿Seguro que deseas eliminar este día de asueto?')) return;
    try {
      const res = await fetch(getApiUrl(`asuetos/${id}`), { method: 'DELETE' });
      if (res.ok) fetchAsuetos();
    } catch (error) {
      console.error('Error al eliminar asueto:', error);
    }
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <div>
        <h2 className="text-2xl font-bold text-gray-800">⚙️ Configuración de Horarios y Contingencia</h2>
        <p className="text-sm text-gray-500 mt-1">Controla los horarios de atención y días feriados para la gestión de tickets automatizados de Sofía.</p>
      </div>

      {/* 🗓️ SECCIÓN 1: HORARIOS REGULARES DE LA SEMANA */}
      <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200">
        <h3 className="text-lg font-semibold mb-4 text-gray-700 flex items-center gap-2">
          <span>🕒</span> Horarios Regulares de Atención (Semanal)
        </h3>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Día</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hora Apertura</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Hora Cierre</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado del Canal</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200 text-sm text-gray-700">
              {horarios.map((h) => {
                const esEditando = editandoDia === h.dia_semana;
                return (
                  <tr key={h.dia_semana} className="hover:bg-gray-50">
                    <td className="px-6 py-4 font-medium text-gray-900">{diasNombre[h.dia_semana]}</td>
                    <td className="px-6 py-4">
                      {esEditando ? (
                        <input 
                          type="text" 
                          className="border border-gray-300 rounded p-1 text-black w-24" 
                          value={tempApertura} 
                          onChange={(e) => setTempApertura(e.target.value)}
                        />
                      ) : (
                        h.hora_apertura
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {esEditando ? (
                        <input 
                          type="text" 
                          className="border border-gray-300 rounded p-1 text-black w-24" 
                          value={tempCierre} 
                          onChange={(e) => setTempCierre(e.target.value)}
                        />
                      ) : (
                        h.hora_cierre
                      )}
                    </td>
                    <td className="px-6 py-4">
                      {esEditando ? (
                        <select 
                          className="border border-gray-300 rounded p-1 text-black"
                          value={tempActivo ? 'true' : 'false'}
                          onChange={(e) => setTempActivo(e.target.value === 'true')}
                        >
                          <option value="true">Activo / Atendiendo</option>
                          <option value="false">Inactivo / Cerrado</option>
                        </select>
                      ) : (
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${h.activo ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}`}>
                          {h.activo ? 'Activo' : 'Cerrado todo el día'}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 font-medium">
                      {esEditando ? (
                        <div className="flex gap-2">
                          <button onClick={() => guardarHorario(h.dia_semana)} className="text-green-600 hover:text-green-900">Guardar</button>
                          <button onClick={() => setEditandoDia(null)} className="text-gray-500 hover:text-gray-700">Cancelar</button>
                        </div>
                      ) : (
                        <button onClick={() => iniciarEdicionHorario(h)} className="text-blue-600 hover:text-blue-900">Editar Horario</button>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* 📅 SECCIÓN 2: GESTIÓN DE ASUETOS EXCEPCIONALES */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Formulario */}
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 h-fit">
          <h3 className="text-lg font-semibold mb-4 text-gray-700 flex items-center gap-2">
            <span>➕</span> Registrar Asueto
          </h3>
          <form onSubmit={agregarAsueto} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Fecha Especial</label>
              <input 
                type="date" 
                className="w-full border border-gray-300 rounded-md p-2 text-black focus:ring-blue-500 focus:border-blue-500"
                value={fecha}
                onChange={(e) => setFecha(e.target.value)}
                required 
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Motivo / Descripción</label>
              <input 
                type="text" 
                className="w-full border border-gray-300 rounded-md p-2 text-black focus:ring-blue-500 focus:border-blue-500"
                placeholder="Ej. Día de la Madre"
                value={descripcion}
                onChange={(e) => setDescripcion(e.target.value)}
                required 
              />
            </div>
            <button 
              type="submit" 
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 rounded-md transition-colors"
              disabled={cargandoAsueto}
            >
              {cargandoAsueto ? 'Guardando...' : 'Bloquear Día Completo'}
            </button>
          </form>
        </div>

        {/* Tabla Asuetos */}
        <div className="bg-white p-6 rounded-lg shadow-md border border-gray-200 md:col-span-2">
          <h3 className="text-lg font-semibold mb-4 text-gray-700 flex items-center gap-2">
            <span>📋</span> Días de Asueto Activos
          </h3>
          {asuetos.length === 0 ? (
            <p className="text-gray-500 text-sm">No hay asuetos o días feriados bloqueados en el sistema.</p>
          ) : (
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Motivo Bloqueo</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acción</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200 text-sm text-gray-700">
                  {asuetos.map((asueto) => (
                    <tr key={asueto.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4 font-medium text-gray-900">
                        {new Date(asueto.fecha).toLocaleDateString('es-SV', { timeZone: 'UTC' })}
                      </td>
                      <td className="px-6 py-4 text-gray-500">{asueto.descripcion}</td>
                      <td className="px-6 py-4 font-medium">
                        <button 
                          onClick={() => eliminarAsueto(asueto.id)}
                          className="text-red-600 hover:text-red-900"
                        >
                          Eliminar
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
