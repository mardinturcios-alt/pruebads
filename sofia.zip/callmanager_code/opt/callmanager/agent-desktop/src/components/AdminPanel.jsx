'use client';

import { useState, useEffect } from 'react';
import { collection, onSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase-client';
import { Users, Shield, Phone, Plus, Edit2, Mail, Hash, X, Save, Loader2 } from 'lucide-react';

export function AdminPanel() {
  const [agents, setAgents] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isEditMode, setIsEditMode] = useState(false); // 👈 Modo de formulario
  const [selectedId, setSelectedId] = useState(null);   // 👈 ID en edición
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Estado del formulario
  const [formData, setFormData] = useState({
    fullName: '', username: '', email: '', webPassword: '',
    role: 'agent', extension: '', sipPassword: '', maxLines: 1
  });

  // Escuchar a Firebase en tiempo real
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'agents'), (snap) => {
      const data = [];
      snap.forEach(doc => data.push({ id: doc.id, ...doc.data() }));
      setAgents(data);
    });
    return () => unsub();
  }, []);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Cargar datos en el formulario al darle Editar
  const handleEditClick = (agent) => {
    setIsEditMode(true);
    setSelectedId(agent.id);
    setFormData({
      fullName: agent.fullName || '',
      username: agent.username || '',
      email: agent.email || '',
      webPassword: '', // Se deja en blanco, solo se llena si se desea cambiar
      role: agent.role || 'agent',
      extension: agent.extension || '',
      sipPassword: agent.sipPassword || '',
      maxLines: agent.maxLines || 1
    });
    setErrorMsg('');
    setIsModalOpen(true);
  };

  // Abrir modal en modo creación limpia
  const handleNewClick = () => {
    setIsEditMode(false);
    setSelectedId(null);
    setFormData({ fullName: '', username: '', email: '', webPassword: '', role: 'agent', extension: '', sipPassword: '', maxLines: 1 });
    setErrorMsg('');
    setIsModalOpen(true);
  };

  const handleSave = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg('');

    // Si estamos editando, usamos PUT y pasamos el ID; si no, POST
    const url = '/api/admin/agents';
    const method = isEditMode ? 'PUT' : 'POST';
    const bodyData = isEditMode ? { id: selectedId, ...formData } : formData;

    try {
      const res = await fetch(url, {
        method: method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(bodyData)
      });
      const result = await res.json();

      if (!res.ok) throw new Error(result.error || 'Error al procesar la solicitud');
      
      setIsModalOpen(false);
    } catch (err) {
      setErrorMsg(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  const requiresPhone = ['agent', 'admin-agent'].includes(formData.role);

  return (
    <div className="max-w-7xl mx-auto flex flex-col gap-6 animate-fadeIn">
      
      {/* Cabecera del Panel */}
      <div className="flex items-center justify-between bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center text-red-600">
            <Users className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">Gestión de Agentes</h2>
            <p className="text-sm text-gray-500">Administra accesos, roles y capacidades del Contact Center.</p>
          </div>
        </div>
        <button onClick={handleNewClick} className="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-xl font-semibold flex items-center gap-2 transition-colors shadow-sm">
          <Plus className="w-5 h-5" /> Nuevo Usuario
        </button>
      </div>

      {/* Tabla de Agentes */}
      <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200 text-xs uppercase tracking-wider text-gray-500 font-bold">
                <th className="p-4 pl-6">Usuario</th>
                <th className="p-4">Extensión SIP</th>
                <th className="p-4">Rol</th>
                <th className="p-4">Líneas Max</th>
                <th className="p-4">Estado Actual</th>
                <th className="p-4 text-right pr-6">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {agents.map((agent) => (
                <tr key={agent.id} className="hover:bg-gray-50 transition-colors">
                  <td className="p-4 pl-6">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-red-500 to-red-700 flex items-center justify-center text-white font-bold shadow-sm">
                        {agent.fullName ? agent.fullName.charAt(0).toUpperCase() : 'U'}
                      </div>
                      <div>
                        <p className="font-bold text-gray-900">{agent.fullName || agent.username}</p>
                        <p className="text-xs text-gray-500 flex items-center gap-1"><Mail className="w-3 h-3" /> {agent.email || 'Sin correo'}</p>
                      </div>
                    </div>
                  </td>
                  <td className="p-4">
                    {agent.extension ? (
                      <div className="flex items-center gap-1.5 text-gray-700 font-medium"><Phone className="w-4 h-4 text-gray-400" /> {agent.extension}</div>
                    ) : <span className="text-gray-400 text-sm">N/A</span>}
                  </td>
                  <td className="p-4">
                    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold border border-capitalize ${
                      agent.role === 'admin' ? 'bg-purple-100 text-purple-700 border-purple-200' :
                      agent.role === 'supervisor' ? 'bg-orange-100 text-orange-700 border-orange-200' :
                      agent.role === 'admin-agent' ? 'bg-green-100 text-green-700 border-green-200' :
                      'bg-blue-100 text-blue-700 border-blue-200'
                    }`}>
                      <Shield className="w-3 h-3" />
                      {agent.role}
                    </span>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-1.5 text-gray-700 font-medium"><Hash className="w-4 h-4 text-gray-400" /> {agent.maxLines || '1'}</div>
                  </td>
                  <td className="p-4">
                    <div className="flex items-center gap-2">
                      <span className={`w-2.5 h-2.5 rounded-full ${agent.status === 'offline' ? 'bg-gray-400' : agent.status === 'oncall' ? 'bg-red-500 animate-pulse' : agent.status === 'available' ? 'bg-green-500' : 'bg-yellow-500'}`}></span>
                      <span className="text-sm font-semibold text-gray-700 capitalize">{agent.status || 'offline'}</span>
                    </div>
                  </td>
                  <td className="p-4 text-right pr-6">
                    <button onClick={() => handleEditClick(agent)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Editar Usuario">
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL DE CREACIÓN / EDICIÓN */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm animate-fadeIn">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            
            <div className="px-6 py-4 border-b border-gray-200 flex items-center justify-between bg-gray-50">
              <h3 className="text-lg font-bold text-gray-800 flex items-center gap-2">
                <Users className="w-5 h-5 text-red-600"/> 
                {isEditMode ? 'Editar Usuario' : 'Nuevo Usuario'}
              </h3>
              <button onClick={() => setIsModalOpen(false)} className="text-gray-400 hover:text-red-600 transition-colors"><X className="w-6 h-6"/></button>
            </div>

            <div className="p-6 overflow-y-auto flex-1">
              {errorMsg && <div className="mb-4 p-3 bg-red-100 text-red-700 rounded-lg text-sm font-semibold border border-red-200">{errorMsg}</div>}
              
              <form id="agentForm" onSubmit={handleSave} className="grid grid-cols-2 gap-6">
                
                <div className="col-span-2 text-sm font-bold text-gray-500 border-b pb-2 uppercase tracking-wider">Datos de Acceso Web</div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nombre Completo *</label>
                  <input required name="fullName" value={formData.fullName} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:outline-none" placeholder="Ej: Mardin Turcios" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Correo Electrónico</label>
                  <input name="email" type="email" value={formData.email} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:outline-none" placeholder="mardin@davitel.com" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Usuario (Login) *</label>
                  <input required disabled={isEditMode} name="username" value={formData.username} onChange={handleChange} className={`w-full px-4 py-2 border rounded-lg focus:outline-none ${isEditMode ? 'bg-gray-200 text-gray-500 cursor-not-allowed border-gray-300' : 'bg-gray-50 border-gray-300 focus:ring-2 focus:ring-red-500'}`} placeholder="agente8005" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Contraseña Web {isEditMode ? '(Dejar en blanco para mantener)' : '*'}
                  </label>
                  <input required={!isEditMode} name="webPassword" type="password" value={formData.webPassword} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:outline-none" placeholder={isEditMode ? "••••••••" : "Escribe una clave"} />
                </div>

                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Rol en el Sistema *</label>
                  <select name="role" value={formData.role} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:outline-none font-medium">
                    <option value="agent">Agente (Solo Consola)</option>
                    <option value="admin-agent">Súper Agente (Consola + Configuración)</option>
                    <option value="admin">Administrador (Solo Configuración)</option>
                    <option value="supervisor">Supervisor (Solo Métricas IA)</option>
                  </select>
                </div>

                {/* Datos de Telefonía condicionales */}
                {requiresPhone && (
                  <>
                    <div className="col-span-2 text-sm font-bold text-gray-500 border-b pb-2 uppercase tracking-wider mt-2">Configuración Asterisk (Telefonía)</div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Extensión SIP *</label>
                      <input required={requiresPhone} disabled={isEditMode} name="extension" value={formData.extension} onChange={handleChange} className={`w-full px-4 py-2 border rounded-lg focus:outline-none ${isEditMode ? 'bg-gray-200 text-gray-500 cursor-not-allowed border-gray-300' : 'bg-gray-50 border-gray-300 focus:ring-2 focus:ring-red-500'}`} placeholder="8005" />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Contraseña SIP (Asterisk) *</label>
                      <input required={requiresPhone} name="sipPassword" type="text" value={formData.sipPassword} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:outline-none" placeholder="Secret123" />
                    </div>
                    <div className="col-span-2">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Capacidad: Líneas Simultáneas *</label>
                      <input required={requiresPhone} type="number" min="1" max="10" name="maxLines" value={formData.maxLines} onChange={handleChange} className="w-full px-4 py-2 bg-gray-50 border border-gray-300 rounded-lg focus:ring-2 focus:ring-red-500 focus:outline-none" />
                    </div>
                  </>
                )}
              </form>
            </div>

            <div className="px-6 py-4 border-t border-gray-200 bg-gray-50 flex justify-end gap-3">
              <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2 text-gray-600 font-semibold hover:bg-gray-200 rounded-lg transition-colors">Cancelar</button>
              <button form="agentForm" type="submit" disabled={isLoading} className="bg-red-600 hover:bg-red-700 disabled:bg-red-400 text-white px-6 py-2 rounded-lg font-semibold flex items-center gap-2 transition-colors">
                {isLoading ? <Loader2 className="w-5 h-5 animate-spin"/> : <Save className="w-5 h-5" />}
                {isLoading ? 'Procesando...' : isEditMode ? 'Guardar Cambios' : 'Crear Usuario'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
