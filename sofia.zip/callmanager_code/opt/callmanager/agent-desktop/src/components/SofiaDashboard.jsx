"use client";

import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import {
  PhoneCall, Bot, UserCheck, Clock, TrendingUp, AlertCircle,
  CheckCircle, Activity, Users, PhoneOff, RefreshCw, Headset, Target, Calendar, Download
} from 'lucide-react';

// ── IMPORTACIONES PARA FIREBASE (Wallboard en vivo) ──
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase-client';

// ─── Paleta Davivienda ───────────────────────────────────────────────────────
const C = {
  red:       '#E3001B',
  redLight:  '#FEE2E5',
  redDark:   '#A8001A',
  gray50:    '#F9FAFB',
  gray100:   '#F3F4F6',
  gray200:   '#E5E7EB',
  gray400:   '#9CA3AF',
  gray600:   '#4B5563',
  gray800:   '#1F2937',
  green:     '#10B981',
  greenBg:   '#D1FAE5',
  amber:     '#F59E0B',
  amberBg:   '#FEF3C7',
  blue:      '#3B82F6',
  blueBg:    '#DBEAFE',
  purple:    '#8B5CF6',
  purpleBg:  '#EDE9FE',
  indigo:    '#4F46E5',
  indigoBg:  '#E0E7FF'
};

const PIE_COLORS = [C.green, C.amber, C.red];

// ─── Helpers ────────────────────────────────────────────────────────────────
function fmtDuration(s) {
  if (!s && s !== 0) return '—';
  const m = Math.floor(s / 60);
  const sec = Math.floor(s % 60);
  return m > 0 ? `${m}m ${sec}s` : `${sec}s`;
}

function fmtTime(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleTimeString('es-SV', { hour: '2-digit', minute: '2-digit' });
}

function fmtDate(ts) {
  if (!ts) return '—';
  return new Date(ts).toLocaleDateString('es-SV', { day: '2-digit', month: 'short' });
}

function dispositionLabel(d) {
  const map = { ANSWERED: 'Contestada', 'NO ANSWER': 'Sin respuesta', BUSY: 'Ocupado', FAILED: 'Fallida' };
  return map[d] || d || '—';
}

function dispositionColor(d) {
  const map = { ANSWERED: C.green, 'NO ANSWER': C.amber, BUSY: C.red, FAILED: C.gray400 };
  return map[d] || C.gray400;
}

// ─── Subcomponentes ──────────────────────────────────────────────────────────

function KpiCard({ titulo, valor, subtitulo, icono, color, bgColor, isHistorico }) {
  return (
    <div style={{
      background: isHistorico ? '#F4FCE3' : 'white',
      borderRadius: 12, padding: '18px 20px',
      display: 'flex', flexDirection: 'column', gap: 8,
      boxShadow: '0 1px 3px rgba(0,0,0,0.08)', borderLeft: `4px solid ${color}`, minWidth: 0,
      transition: 'all 0.3s ease'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <span style={{ fontSize: 12, color: C.gray600, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{titulo}</span>
        <div style={{ background: bgColor, borderRadius: 8, padding: 6, display: 'flex' }}>{icono}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 8 }}>
        <span style={{ fontSize: 28, fontWeight: 700, color: C.gray800, lineHeight: 1 }}>{valor}</span>
      </div>
      {subtitulo && <span style={{ fontSize: 12, color: isHistorico ? '#65A30D' : C.gray400, fontWeight: isHistorico ? 600 : 400 }}>{subtitulo}</span>}
    </div>
  );
}

function Badge({ label, color }) {
  return (
    <span style={{ display: 'inline-block', padding: '2px 8px', borderRadius: 999, fontSize: 11, fontWeight: 600, background: color + '22', color: color }}>
      {label}
    </span>
  );
}

function SectionBox({ title, children, isHistorico, extraHeader }) {
  return (
    <div style={{ background: 'white', borderRadius: 12, padding: 20, boxShadow: '0 1px 3px rgba(0,0,0,0.08)', borderTop: isHistorico ? `3px solid #84CC16` : 'none' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <h4 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: C.gray800 }}>{title}</h4>
        {extraHeader}
      </div>
      {children}
    </div>
  );
}

function EmptyState({ mensaje }) {
  return (
    <div style={{ textAlign: 'center', padding: '32px 0', color: C.gray400 }}>
      <Activity size={32} style={{ marginBottom: 8, opacity: 0.4 }} />
      <p style={{ margin: 0, fontSize: 13 }}>{mensaje}</p>
    </div>
  );
}

// ─── Dashboard Principal ─────────────────────────────────────────────────────

export function SofiaDashboard() {
  // ── ESTADOS EN VIVO (HOY) ──
  const [kpis, setKpis] = useState({ total: 0, resueltas_ia: 0, atendidas_humanos: 0, tiempo_promedio: 0, tasa_resolucion: 0, abandonos_cola: 0 });
  const [historialCdr, setHistorialCdr]         = useState([]);
  const [historialSesiones, setHistorialSesiones] = useState([]);
  const [intencionesData, setIntencionesData]   = useState([]);
  const [actividadHoras, setActividadHoras]     = useState([]);
  
  // ── ESTADOS HISTÓRICOS ──
  const [fechas, setFechas] = useState({ desde: '', hasta: '' });
  const [kpisHistorico, setKpisHistorico] = useState(null);
  const [cdrHistorico, setCdrHistorico] = useState([]);
  const [intencionesHistorico, setIntencionesHistorico] = useState([]);
  const [cargandoHist, setCargandoHist] = useState(false);
  const [evaluacionHistorico, setEvaluacionHistorico] = useState([]);
  // ── ESTADOS GLOBALES & FIREBASE ──
  const [loading, setLoading]                   = useState(true);
  const [ultimaActualizacion, setUltimaActualizacion] = useState(null);
  const [error, setError]                       = useState(null);
  const [agentesEnVivo, setAgentesEnVivo]       = useState([]);
  const [statsPorAgente, setStatsPorAgente]     = useState([]);
  const [promptIA, setPromptIA] = useState("");

  // 1. Cargar datos estadísticos de Hoy (VÍA RÁPIDA)
  const cargarDatos = useCallback(async () => {
    try {
      const API  = `/api/dashboard`;
      const [resResumen, resCdr, resSesiones, resIntenciones, resActividad] = await Promise.allSettled([
        axios.get(`${API}/resumen`),
        axios.get(`${API}/cdr`),
        axios.get(`${API}/sesiones`),
        axios.get(`${API}/intenciones`),
        axios.get(`${API}/actividad-horas`),
      ]);

      if (resResumen.status === 'fulfilled') {
        setKpis(resResumen.value.data.kpis || resResumen.value.data);
        setStatsPorAgente(resResumen.value.data.statsAgentes || []);
      }
      if (resCdr.status === 'fulfilled')       setHistorialCdr(resCdr.value.data?.slice(0, 20) || []);
      if (resSesiones.status === 'fulfilled')  setHistorialSesiones(resSesiones.value.data?.slice(0, 15) || []);
      if (resIntenciones.status === 'fulfilled') setIntencionesData(resIntenciones.value.data || []);
      if (resActividad.status === 'fulfilled') setActividadHoras(resActividad.value.data || []);

      setUltimaActualizacion(new Date());
      setError(null);
    } catch (e) {
      setError('No se pudo conectar con el servidor de métricas.');
    } finally {
      setLoading(false);
    }
  }, []);

  // 1.5 Cargar datos Históricos (VÍA PESADA MULTI-GRAFICO)
  const buscarHistorico = async () => {
    if (!fechas.desde || !fechas.hasta) return;
    setCargandoHist(true);
    try {
      const res = await axios.get(`/api/dashboard/historico?startDate=${fechas.desde}&endDate=${fechas.hasta}`);
      setKpisHistorico(res.data.kpis);
      setCdrHistorico(res.data.cdr || []);
      setIntencionesHistorico(res.data.intenciones || []);
      setEvaluacionHistorico(res.data.evaluacion || []);
      setError(null);
    } catch (e) {
      setError('Error al consultar el rango histórico.');
    } finally {
      setCargandoHist(false);
    }
  };

  const limpiarHistorico = () => {
    setFechas({ desde: '', hasta: '' });
    setKpisHistorico(null);
    setCdrHistorico([]);
    setIntencionesHistorico([]);
    setEvaluacionHistorico([]);
  };

  // ── MOTOR DE DESCARGA DE REPORTES DETALLADOS (CSV) ──
  const descargarReporteCSV = () => {
    const dataReporte = isHistMode ? cdrHistorico : historialCdr;
    if (dataReporte.length === 0) return;

    let csvContent = "\uFEFF"; // UTF-8 BOM para soporte de tildes en Excel
    csvContent += "Fecha,Origen,Destino,Agente/Canal,Estado,Duracion(segundos)\n";

    dataReporte.forEach(r => {
      const fecha = r.fecha || r.start || '—';
      const origen = r.origen || r.src || '—';
      const destino = r.destino || r.dst || '—';
      const agente = r.agente_humano || r.dstchannel || 'Sofía IA';
      const estado = dispositionLabel(r.estado || r.disposition);
      const duracion = r.duracion_segundos || r.duration || 0;
      csvContent += `"${fecha}","${origen}","${destino}","${agente}","${estado}",${duracion}\n`;
    });

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.setAttribute("href", url);
    link.setAttribute("download", `Reporte_Detallado_Llamadas_${isHistMode ? 'Historico' : 'Hoy'}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // 2. Efecto para API y Firestore (CON FILTRO DE ROLES)
  useEffect(() => {
    // 🆕 NUEVO: Cargar directrices de la IA al abrir el panel
    fetch('/api/admin/prompt')
      .then(res => res.json())
      .then(data => { if (data.prompt) setPromptIA(data.prompt); })
      .catch(err => console.error("Error cargando prompt de IA", err));

    cargarDatos();
    const iv = setInterval(cargarDatos, 15000);

    const q = query(collection(db, 'agents'), orderBy('extension'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      // 🛡️ CRÍTICO: Expulsamos de la lista a Supervisores y Administradores
      const agentesFiltrados = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() }))
        .filter(agente => agente.role !== 'admin' && agente.role !== 'supervisor');
      
      setAgentesEnVivo(agentesFiltrados);
    }, (error) => console.error("Error leyendo Firestore:", error));

    return () => { clearInterval(iv); unsubscribe(); };
  }, [cargarDatos]);

  // ── SELECTORES DINÁMICOS (HOY vs HISTÓRICO) ──
  const isHistMode = kpisHistorico !== null;
  const dataKpis = isHistMode ? kpisHistorico : kpis;
  const dataIntenciones = isHistMode ? intencionesHistorico : intencionesData;
  const dataTablaCdr = isHistMode ? cdrHistorico.slice(0, 50) : historialCdr; // Muestra top 50 en pantalla

  const pieData = [
    { name: 'Resueltas IA',    value: dataKpis.resueltas_ia  || 0 },
    { name: 'Atendidas Humano', value: dataKpis.atendidas_humanos || 0 },
    { name: 'Abandonos Cola',   value: dataKpis.abandonos_cola || 0 },
  ].filter(d => d.value > 0);

  const tasaResolucion = dataKpis.tasa_resolucion || 0;

  // Estadísticas del Personal (SIEMPRE EN VIVO)
  const totalLlamadasAgentes = statsPorAgente.reduce((acc, curr) => acc + (parseInt(curr.contestadas) || 0), 0);
  const agentesDisponibles = agentesEnVivo.filter(a => a.status === 'available').length;
  const agentesConectados = agentesEnVivo.length;
  const agentesEnLlamada = agentesEnVivo.filter(a => a.status === 'oncall').length;
  
  // 🌍 Función para obtener la URL del audio dinámicamente
  const getAudioUrl = (uniqueId) => {
    const host = typeof window !== 'undefined' ? window.location.hostname : 'localhost';
    return `http://${host}:8080/api/grabaciones/${uniqueId}`;
  };

  return (
    <div style={{ padding: 20, background: C.gray100, minHeight: '100vh', fontFamily: 'Inter, system-ui, sans-serif' }}>

      {/* ── Header & Selector de Fechas ── */}
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginBottom: 20, flexWrap: 'wrap', gap: 16 }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: C.gray800 }}>Centro de Mando & Analítica</h2>
          <p style={{ margin: '4px 0 0', fontSize: 13, color: C.gray400 }}>
            {ultimaActualizacion ? `Sincronizado a las ${ultimaActualizacion.toLocaleTimeString('es-SV')}` : 'Cargando datos...'}
          </p>
        </div>

        <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, background: 'white', padding: '6px 12px', borderRadius: 8, border: `1px solid ${C.gray200}`, boxShadow: '0 1px 2px rgba(0,0,0,0.05)' }}>
            <Calendar size={18} color={isHistMode ? '#65A30D' : C.gray400} />
            <input type="date" value={fechas.desde} onChange={e => setFechas({...fechas, desde: e.target.value})} style={{ border: 'none', outline: 'none', color: C.gray600, fontSize: 13 }} />
            <span style={{color: C.gray400, fontSize: 13}}>a</span>
            <input type="date" value={fechas.hasta} onChange={e => setFechas({...fechas, hasta: e.target.value})} style={{ border: 'none', outline: 'none', color: C.gray600, fontSize: 13 }} />
            
            <button onClick={buscarHistorico} disabled={!fechas.desde || !fechas.hasta || cargandoHist} style={{ padding: '6px 12px', borderRadius: 6, border: 'none', background: C.gray800, color: 'white', cursor: 'pointer', fontSize: 12, fontWeight: 'bold' }}>
              {cargandoHist ? 'Calculando...' : 'Consultar'}
            </button>
            
            {isHistMode && (
              <button onClick={limpiarHistorico} style={{ padding: '6px 12px', borderRadius: 6, border: `1px solid ${C.gray200}`, background: '#fef2f2', color: C.redDark, cursor: 'pointer', fontSize: 12, fontWeight: 'bold' }}>
                Volver a Hoy
              </button>
            )}
          </div>

          <button onClick={cargarDatos} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '10px 16px', borderRadius: 8, border: `1px solid ${C.gray200}`, background: 'white', cursor: 'pointer', color: C.gray600 }}>
            <RefreshCw size={16} />
          </button>
        </div>
      </div>

      {error && (
        <div style={{ background: C.redLight, border: `1px solid ${C.red}`, borderRadius: 8, padding: '12px 16px', marginBottom: 20, display: 'flex', gap: 8, alignItems: 'center', color: C.redDark, fontSize: 14 }}>
          <AlertCircle size={18} /> {error}
        </div>
      )}

      {/* ==========================================
          SECCIÓN 1: SOFÍA IA (MÓDULO DE MÉTRICAS)
      ============================================= */}
      <h3 style={{ margin: '0 0 16px 0', fontSize: 18, color: isHistMode ? '#4D7C0F' : C.gray800, display: 'flex', alignItems: 'center', gap: 8 }}>
        <Bot size={20} color={isHistMode ? '#65A30D' : C.purple} /> 
        Rendimiento Sofía IA {isHistMode ? `(Datos del ${fmtDate(fechas.desde)} al ${fmtDate(fechas.hasta)})` : '(Métricas de Hoy)'}
      </h3>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14, marginBottom: 20 }}>
        <KpiCard isHistorico={isHistMode} titulo={isHistMode ? "Total Rango" : "Entrantes (Hoy)"} valor={dataKpis.llamadas_hoy ?? '—'} subtitulo={isHistMode ? "Llamadas en fecha" : "Llamadas del día"} icono={<Activity size={16} color={C.purple} />} color={C.purple} bgColor={C.purpleBg} />
        <KpiCard isHistorico={isHistMode} titulo="Atendidas IA" valor={dataKpis.resueltas_ia} subtitulo="Contención exitosa" icono={<Target size={16} color={C.green} />} color={C.green} bgColor={C.greenBg} />
        <KpiCard isHistorico={isHistMode} titulo="Atendidas Humanos" valor={dataKpis.atendidas_humanos} subtitulo="Pasadas a agentes" icono={<UserCheck size={16} color={C.amber} />} color={C.amber} bgColor={C.amberBg} />
        <KpiCard isHistorico={isHistMode} titulo="Abandonos (Cola)" valor={dataKpis.abandonos_cola} subtitulo="Colgaron en espera" icono={<PhoneOff size={16} color={C.red} />} color={C.red} bgColor={C.redLight} />
        <KpiCard isHistorico={isHistMode} titulo="T. promedio IA" valor={fmtDuration(dataKpis.tiempo_promedio)} subtitulo="Tiempo con Sofía" icono={<Clock size={16} color={C.blue} />} color={C.blue} bgColor={C.blueBg} />
        <KpiCard isHistorico={isHistMode} titulo="Contención IA" valor={`${tasaResolucion}%`} subtitulo="Efectividad Global" icono={<TrendingUp size={16} color={C.purple} />} color={C.purple} bgColor={C.purpleBg} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, marginBottom: 24 }}>
        <SectionBox title={`Casos Atendidos por Hora (Global - Solo Hoy)`}>
          {actividadHoras.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={actividadHoras} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.gray200} vertical={false} />
                <XAxis dataKey="hora" tick={{ fontSize: 12, fill: C.gray400 }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: C.gray400 }} axisLine={false} tickLine={false} />
                <Tooltip cursor={{ fill: C.gray50 }} formatter={(v) => [v, 'Llamadas']} />
                <Bar dataKey="total" fill={C.red} radius={[4,4,0,0]} barSize={30} />
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState mensaje="Sin datos de actividad" />}
        </SectionBox>

        <SectionBox isHistorico={isHistMode} title={`Distribución de llamadas ${isHistMode ? '(Histórico)' : '(Hoy)'}`}>
          {pieData.length > 0 ? (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} paddingAngle={3} dataKey="value">
                  {pieData.map((_, i) => <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(v, n) => [v, n]} />
                <Legend iconSize={10} wrapperStyle={{ fontSize: 12, paddingTop: 10 }} />
              </PieChart>
            </ResponsiveContainer>
          ) : <EmptyState mensaje="Sin datos suficientes" />}
        </SectionBox>
      </div>

      {/* ==========================================
          SECCIÓN 2: AGENTES HUMANOS (LIVE DE VERDAD)
      ============================================= */}
      <h3 style={{ margin: '0 0 16px 0', fontSize: 18, color: C.gray800, display: 'flex', alignItems: 'center', gap: 8 }}><Headset size={20} color={C.indigo} /> Productividad Equipo Humano (En Vivo)</h3>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: 14, marginBottom: 20 }}>
        <KpiCard titulo="Agentes Conectados" valor={agentesConectados} subtitulo="Operadores en turno" icono={<Users size={18} color={C.indigo} />} color={C.indigo} bgColor={C.indigoBg} />
        <KpiCard titulo="En Llamada" valor={agentesEnLlamada} subtitulo="Agentes ocupados" icono={<PhoneCall size={18} color={C.red} />} color={C.red} bgColor={C.redLight} />
        <KpiCard titulo="Disponibles" valor={agentesDisponibles} subtitulo="Listos para recibir" icono={<CheckCircle size={18} color={C.green} />} color={C.green} bgColor={C.greenBg} />
        <KpiCard titulo="Interacciones Humanas" valor={totalLlamadasAgentes} subtitulo="Llamadas contestadas hoy" icono={<Activity size={18} color={C.blue} />} color={C.blue} bgColor={C.blueBg} />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 14, marginBottom: 24 }}>
        <SectionBox title="🔴 Wallboard en Vivo (Solo Operadores)">
          {agentesEnVivo.length > 0 ? (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ background: C.gray50 }}>
                    <th style={{ padding: '10px', textAlign: 'left', fontWeight: 600, color: C.gray600, borderBottom: `1px solid ${C.gray200}` }}>Agente</th>
                    <th style={{ padding: '10px', textAlign: 'left', fontWeight: 600, color: C.gray600, borderBottom: `1px solid ${C.gray200}` }}>Estado</th>
                    <th style={{ padding: '10px', textAlign: 'center', fontWeight: 600, color: C.gray600, borderBottom: `1px solid ${C.gray200}` }}>Atendidas</th>
                    <th style={{ padding: '10px', textAlign: 'center', fontWeight: 600, color: C.gray600, borderBottom: `1px solid ${C.gray200}` }}>Perdidas</th>
                  </tr>
                </thead>
                <tbody>
                  {agentesEnVivo.map((agente) => {
                    const stats = statsPorAgente.find(s => s.extension === agente.extension) || { contestadas: 0, perdidas: 0 };
                    return (
                      <tr key={agente.id} style={{ borderBottom: `1px dashed ${C.gray200}` }}>
                        <td style={{ padding: '12px 10px' }}>
                          <div style={{ fontWeight: 700, color: C.gray800 }}>{agente.fullName}</div>
                          <div style={{ fontSize: 11, color: C.gray400 }}>Ext: {agente.extension}</div>
                        </td>
                        <td style={{ padding: '12px 10px' }}>
                          <span style={{
                            padding: '4px 10px', borderRadius: 999, fontSize: 11, fontWeight: 700,
                            backgroundColor: agente.status === 'available' ? C.greenBg : agente.status === 'oncall' ? C.redLight : C.amberBg,
                            color: agente.status === 'available' ? '#065F46' : agente.status === 'oncall' ? C.redDark : '#92400E'
                          }}>
                            {agente.status === 'available' ? '🟢 Disponible' : agente.status === 'oncall' ? '🔴 En Llamada' : '🟡 Ausente'}
                          </span>
                        </td>
                        <td style={{ padding: '12px 10px', textAlign: 'center', fontWeight: 800, color: C.green }}>{stats.contestadas}</td>
                        <td style={{ padding: '12px 10px', textAlign: 'center', fontWeight: 700, color: C.red }}>{stats.perdidas}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          ) : <EmptyState mensaje="No hay operadores conectados al sistema" />}
        </SectionBox>

        <SectionBox title="TMO por Agente (Top 5 - Hoy)">
          {historialCdr.length > 0 ? (
            <ResponsiveContainer width="100%" height={250}>
              <BarChart layout="vertical" data={historialCdr.filter(r => r.agente_humano).slice(0, 5)} margin={{ top: 0, right: 20, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke={C.gray100} horizontal={true} vertical={false} />
                <XAxis type="number" tick={{ fontSize: 11 }} axisLine={false} tickLine={false} />
                <YAxis dataKey="agente_humano" type="category" width={80} tick={{ fontSize: 11, fontWeight: 600, fill: C.gray600 }} axisLine={false} tickLine={false} />
                <Tooltip cursor={{ fill: C.gray50 }} formatter={(v) => [fmtDuration(v), 'Tiempo Operativo']} />
                <Bar dataKey="duracion_segundos" fill={C.indigo} radius={[0, 4, 4, 0]} barSize={20} />
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState mensaje="Sin datos de TMO para humanos" />}
        </SectionBox>
      </div>

      {/* ==========================================
          SECCIÓN 3: REGISTROS DETALLADOS & REPORTES
      ============================================= */}
<div style={{ display: 'grid', gridTemplateColumns: '1fr', gap: 14, marginBottom: 14 }}>
        <SectionBox title={isHistMode ? "Volumen de Llamadas por Usuario (Rango Histórico)" : "Top Motivos de Llamada / Intenciones (Hoy)"}>
          {dataIntenciones.length > 0 ? (
            <ResponsiveContainer width="100%" height={240}>
              <BarChart 
                layout="vertical" 
                data={dataIntenciones.slice(0,7)} 
                margin={{ top: 10, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" stroke={C.gray100} horizontal={false} />
                <XAxis type="number" tick={{ fontSize: 11, fill: C.gray400 }} axisLine={false} tickLine={false} />
                <YAxis 
                  dataKey="intencion" 
                  type="category" 
                  width={150} 
                  tick={{ fontSize: 12, fontWeight: 500, fill: C.gray800 }} 
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip cursor={{ fill: C.gray50 }} formatter={(value) => [value, 'Llamadas']} />
                <Bar dataKey="total" fill={C.purple} radius={[0, 6, 6, 0]} barSize={22} name="Llamadas" />
              </BarChart>
            </ResponsiveContainer>
          ) : <EmptyState mensaje="Sin datos disponibles para graficar" />}
        </SectionBox>
      </div>
      {/* Nuevo Gráfico de Evaluación IA (Solo visible en Histórico) */}
      {isHistMode && (
        <div style={{ marginBottom: 14 }}>
          <SectionBox title="Veredicto de Sofía (Sentimiento y Clasificación IA)">
            {evaluacionHistorico.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={evaluacionHistorico} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={4} dataKey="total" nameKey="evaluacion">
                    {evaluacionHistorico.map((_, i) => <Cell key={i} fill={[C.indigo, C.purple, C.blue, C.amber, C.red][i % 5]} />)}
                  </Pie>
                  <Tooltip formatter={(v, n) => [v, n]} />
                  <Legend iconType="circle" iconSize={10} wrapperStyle={{ fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            ) : <EmptyState mensaje="Sin evaluaciones registradas en este período" />}
          </SectionBox>
        </div>
      )}
      <div style={{ display: 'grid', gridTemplateColumns: isHistMode ? '1fr' : '1fr 1fr', gap: 14, marginBottom: 14 }}>
        
        {/* Tabla CDR — Soporta reportes y cambia con la fecha */}
        <SectionBox 
          isHistorico={isHistMode} 
          title={`CDR — Historial técnico Asterisk ${isHistMode ? `(Mostrando ${dataTablaCdr.length} llamadas del periodo)` : '(Últimas llamadas de hoy)'}`}
          extraHeader={
            <button onClick={descargarReporteCSV} style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '6px 12px', borderRadius: 6, border: 'none', background: C.green, color: 'white', cursor: 'pointer', fontSize: 12, fontWeight: 'bold' }}>
              <Download size={14} /> Descargar Reporte Completo
            </button>
          }
        >
          {dataTablaCdr.length > 0 ? (
            <div style={{ overflowX: 'auto' }}>
              <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                <thead>
                  <tr style={{ background: C.gray50 }}>
                    {['Fecha/Hora','Origen','Destino','Agente/Canal','Estado','Duración','Grabación'].map(h => (
                      <th key={h} style={{ padding: '8px 10px', textAlign: 'left', fontWeight: 600, color: C.gray600, fontSize: 11, borderBottom: `2px solid ${C.gray200}` }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {dataTablaCdr.map((r, i) => (
                    <tr key={i} style={{ borderBottom: `1px solid ${C.gray100}` }}>
                      <td style={{ padding: '7px 10px', color: C.gray600, fontSize: 12 }}>{isHistMode ? new Date(r.fecha).toLocaleString('es-SV') : fmtTime(r.start)}</td>
                      <td style={{ padding: '7px 10px', fontWeight: 600 }}>{r.origen || r.src || '—'}</td>
                      <td style={{ padding: '7px 10px', color: C.gray600 }}>{r.destino || r.dst || '—'}</td>
                      <td style={{ padding: '7px 10px', color: C.blue, fontWeight: 600 }}>{r.agente_humano || 'Sofía IA'}</td>
                      <td style={{ padding: '7px 10px' }}>
                        <Badge label={dispositionLabel(r.estado || r.disposition)} color={dispositionColor(r.estado || r.disposition)} />
                      </td>
                      <td style={{ padding: '7px 10px', color: C.gray600 }}>{fmtDuration(r.duracion_segundos || r.duration)}</td>
                    <td style={{ padding: '7px 10px' }}>
                        {(r.uniqueid || r.callId || r.id) ? (
                          <audio 
                            controls 
                            preload="none" 
                            style={{ height: '32px', width: '220px', borderRadius: '4px' }}
                            src={getAudioUrl(r.uniqueid || r.callId || r.id)}
                          >
                          </audio>
                        ) : (
				<span style={{ color: C.gray400, fontSize: 12 }}>Sin audio</span>
                        )}
                      </td>
			</tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : <EmptyState mensaje="Sin registros de llamadas en este período" />}
        </SectionBox>

        {/* La tabla de Firestore de Sesiones solo se renderiza si estamos en el modo "Hoy" (Live) */}
        {!isHistMode && (
          <SectionBox title="Sesiones IA — Firestore (Monitoreo Hoy)">
            {historialSesiones.length > 0 ? (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
                  <thead>
                    <tr style={{ background: C.gray50 }}>
                      {['Hora','Funcionario','Área','Intención','Estado','T. IA'].map(h => (
                        <th key={h} style={{ padding: '8px 10px', textAlign: 'left', fontWeight: 600, color: C.gray600, fontSize: 11, borderBottom: `2px solid ${C.gray200}` }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {historialSesiones.map((s, i) => (
                      <tr key={i} style={{ borderBottom: `1px solid ${C.gray100}` }}>
                        <td style={{ padding: '7px 10px', color: C.gray400, fontSize: 12 }}>{fmtTime(s.startedAt || s.fecha)}</td>
                        <td style={{ padding: '7px 10px', fontWeight: 600 }}>{s.callerName || s.funcionario || '—'}</td>
                        <td style={{ padding: '7px 10px', color: C.gray600, fontSize: 12 }}>{s.area || '—'}</td>
                        <td style={{ padding: '7px 10px', color: C.gray600, fontSize: 12, maxWidth: 140, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.intencion_detectada || '—'}</td>
                        <td style={{ padding: '7px 10px' }}>
                          <Badge
                            label={s.status === 'escalated' ? 'Escalada' : s.status === 'with_agent' ? 'Con agente' : s.status === 'active_ai' ? 'En curso' : 'Resuelta'}
                            color={s.status === 'escalated' ? C.amber : s.status === 'with_agent' ? C.blue : s.status === 'active_ai' ? C.purple : C.green}
                          />
                        </td>
                        <td style={{ padding: '7px 10px', color: C.gray600 }}>{fmtDuration(s.duracion_ia)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : <EmptyState mensaje="Sin sesiones IA registradas hoy" />}
          </SectionBox>
        )}

      </div>
    </div>
  );
}
