'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useAgentStore } from '@/store/agentStore';
import { useSoftphone } from '@/hooks/useSoftphone';
import { useCallQueue } from '@/hooks/useCallQueue';
import { CallQueue } from './CallQueue';
import { ActiveCall } from './ActiveCall';
import { IncomingCallModal } from './IncomingCallModal';
import { StatusSelector } from './StatusSelector';
import { Dialpad } from './Dialpad';
import { SofiaDashboard } from './SofiaDashboard';
import { AdminPanel } from './AdminPanel';
import { KnowledgePanel } from './KnowledgePanel';
import { KnowledgeBase } from './KnowledgeBase';
import { LiveWallboard } from './LiveWallboard';
import AsuetosPanel from './AsuetosPanel'; // <-- AÑADIR ESTA LÍNEA


import { doc, updateDoc, getDoc, onSnapshot } from 'firebase/firestore';
import { db } from '@/lib/firebase-client';

export function DashboardClient({ session }) {
  const router          = useRouter();
  const setSession      = useAgentStore((s) => s.setSession);
  const activeCall      = useAgentStore((s) => s.activeCall);
  const incomingCall    = useAgentStore((s) => s.incomingCall);
  const status          = useAgentStore((s) => s.status);
  const sipStatus       = useAgentStore((s) => s.sipStatus);
  const calls           = useAgentStore((s) => s.calls || []);
  const setActiveCall   = useAgentStore((s) => s.setActiveCall);
  const setStatus       = useAgentStore((s) => s.setStatus);
  const setIncomingCall = useAgentStore((s) => s.setIncomingCall);

  // 🛡️ MATRIZ DE ACCESOS: Definimos desde el inicio usando la sesión
  const initialRole = session?.role || 'agent';
  
  // Pestaña por defecto según el rol
  const defaultTab = 
    initialRole === 'supervisor' ? 'Métricas' :
    initialRole === 'admin' ? 'Gestión' : 'Consola';

  // ¿Este usuario necesita teléfono?
  const isPhoneUser = initialRole === 'agent' || initialRole === 'admin-agent';

  const [activeTab, setActiveTab] = useState(defaultTab);
  const [userRole, setUserRole]   = useState(initialRole);
  const [sipCreds, setSipCreds]   = useState(null);
  const [isMuted, setIsMuted]     = useState(false);

  // 1. Cargar credenciales SOLO si el usuario es telefonista
  useEffect(() => {
    setSession(session);
    (async () => {
      try {
        const res = await fetch(`/api/auth/me?t=${Date.now()}`);
        if (!res.ok) { router.push('/login'); return; }
        const me = await res.json();

        // Si es un admin puro o supervisor, cortamos aquí, no conectamos a Asterisk
        if (!isPhoneUser) return;

        // Búsqueda profunda original para que la contraseña SIP no se pierda
        const realMaxLines = Number(
          me?.agent?.maxLines || me?.user?.maxLines || me?.maxLines || session?.agent?.maxLines || session?.maxLines || 1
        );
        const ext = me?.agent?.extension || me?.extension || session?.extension;
        const pwd = me?.agent?.sipPassword || me?.sipPassword || session?.sipPassword;

        useAgentStore.setState({ maxLines: realMaxLines });

        if (ext && pwd) {
          setSipCreds({
            extension: ext,
            password:  pwd,
            domain:    process.env.NEXT_PUBLIC_ASTERISK_DOMAIN,
            wssUrl:    process.env.NEXT_PUBLIC_ASTERISK_WSS_URL,
            maxLines:  realMaxLines
          });
        }
      } catch (e) { console.error('Error cargando credenciales:', e); }
    })();
  }, [session, setSession, router, isPhoneUser]);

  // Si no hay credenciales, el hook del softphone simplemente no hace nada
  const softphone = useSoftphone(sipCreds) || {};
  useCallQueue();

// 🔴 2. VIGILANTE DE FIREBASE Y ARRANQUE SEGURO (TIEMPO REAL)
  useEffect(() => {
    if (!session?.agentId) return;

    const agentRef = doc(db, 'agents', session.agentId);

    // onSnapshot es nuestro radar: lee Firestore en el milisegundo que algo cambia
const unsubscribe = onSnapshot(agentRef, async (snap) => {
      if (snap.exists()) {
        const data = snap.data();

        if (data.role) {
          setUserRole(data.role);
        }

        // 🚀 CORRECCIÓN: Respetamos CUALQUIER estado que venga, incluido 'offline'
        if (data.status) {
          setStatus(data.status);
        } else {
          // Solo si el campo 'status' literalmente no existe en Firestore
          setStatus('available');
          try {
            await updateDoc(agentRef, {
              status: 'available',
              statusUpdatedAt: new Date().toISOString()
            });
          } catch (error) {
            console.error('☁️ [Firestore] Error forzando estado inicial:', error);
          }
        }
      }
    }, (error) => {
      console.error('☁️ [Firestore] Error en el radar onSnapshot:', error);
    });
    // Limpiamos el radar si el agente cierra sesión o la pestaña
    return () => unsubscribe();
  }, [session?.agentId, setStatus]);
  // 🚀 PARCHE 2: Inyección de login inicial (Solo se ejecuta una vez al montar el componente)
// 🚀 PARCHE 2: Inyección de login inicial (Solo se ejecuta una vez al montar el componente)
  useEffect(() => {
    if (session?.agentId && isPhoneUser) {
        const forzarTiempoInicial = async () => {
            try {
               // Aquí despertamos al agente mandándolo a available en Firestore al hacer login
               await updateDoc(doc(db, 'agents', session.agentId), {
                  status: 'available',
                  statusUpdatedAt: new Date().toISOString()
               });
            } catch(e) {}
        };
        forzarTiempoInicial();
    }
  }, [session?.agentId, isPhoneUser]);
  // 3. Manejo de llamadas entrantes (solo agentes)
  useEffect(() => {
    if (status === 'oncall' && !activeCall && incomingCall) {
      const newCall = {
        id: 'inbound-' + Date.now(),
        direction: 'inbound',
        callerNumber: incomingCall.fromNumber || 'Desconocido',
        status: 'connected',
        startedAt: new Date().toISOString()
      };
      setActiveCall(newCall);
      if (useAgentStore.getState().addCall) useAgentStore.getState().addCall(newCall);
      setIncomingCall(null);
    }
  }, [status, activeCall, incomingCall, setActiveCall, setIncomingCall]);

  const showConnected = sipStatus === 'registered' || status === 'available' || status === 'oncall' || status === 'calling';

const handleLogout = async () => {
    try {
      // 1. Marcar como offline en Firestore antes de matar la sesión
      if (session?.agentId) {
        await updateDoc(doc(db, 'agents', session.agentId), {
          status: 'offline',
          statusUpdatedAt: new Date().toISOString()
        });
      }
    } catch (e) {
      console.error('[Logout] Error actualizando estado en Firestore:', e);
    }

    try {
      // 2. Destruir sesión en el servidor
      await fetch('/api/auth/logout', { method: 'POST' });
    } catch (e) {
      // Ignoramos errores de red durante el corte de sesión
    }

    // 3. Forzar recarga completa para destruir los hooks de la cola en memoria
    window.location.href = '/login';
  };
  const handleMakeCall = (ext) => { if(softphone.makeCall) { softphone.makeCall(ext); setStatus('oncall'); } };
  const handleHangup = () => {
    if (softphone.hangupCall) softphone.hangupCall(activeCall?.id);
    setIsMuted(false);
    if (calls.length <= 1 && !incomingCall) setStatus('available');
  };
  const handleMute = () => { if(softphone.toggleMute) setIsMuted(softphone.toggleMute(activeCall?.id)); };

  const activeCallsList = calls.length > 0 ? calls : (activeCall ? [activeCall] : []);

  // 🛠️ CONSTRUIR MENÚ DINÁMICO SEGÚN ROL
  const getMenuItems = () => {
    const items = [];
    if (isPhoneUser) {
      items.push({ name: 'Consola Actual', icon: '🎧', key: 'Consola' });
      items.push({ name: 'Mis Tickets', icon: '🎟️', key: 'Mis' });
    }
if (userRole === 'admin' || userRole === 'admin-agent') {
      items.push({ name: 'Gestión Agentes', icon: '👥', key: 'Gestión' });
      items.push({ name: 'Entrenar IA', icon: '🤖', key: 'Entrenar' });
      items.push({ name: 'Base Conocimiento', icon: '📁', key: 'Base' });
      items.push({ name: 'Gestión Asuetos', icon: '📅', key: 'asuetos' });
}
    if (userRole === 'supervisor' || userRole === 'admin' || userRole === 'admin-agent') {
      items.push({ name: 'Métricas IA', icon: '📊', key: 'Métricas' }); 
      items.push({ name: 'Monitoreo en Vivo', icon: '📡', key: 'Monitoreo' }); // <-- NUEVO BOTÓN
    }
    return items;
  };

  return (
    <div className="flex h-screen bg-gray-50 font-sans text-gray-800">
      
      {/* MENÚ LATERAL */}
      <div className="w-64 bg-red-600 text-white flex flex-col shadow-xl z-10">
        <div className="p-6 font-bold text-2xl border-b border-red-500 flex items-center gap-3">
          <span className="bg-white text-red-600 p-2 rounded-lg text-sm">☁️</span> Davitel IT
        </div>
        <nav className="flex-1 mt-4">
          {getMenuItems().map((item) => (
            <button
              key={item.key}
              onClick={() => setActiveTab(item.key)}
              className={`w-full text-left px-6 py-4 hover:bg-red-700 transition-colors flex items-center gap-3 ${activeTab === item.key ? 'bg-red-700 border-l-4 border-white font-semibold' : ''}`}
            >
              <span>{item.icon}</span> {item.name}
            </button>
          ))}
        </nav>
      </div>

      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* ENCABEZADO */}
        <header className="bg-white h-20 shadow-sm flex items-center justify-between px-8 z-0">
          <h1 className="text-2xl font-bold text-red-600">
            {activeTab === 'Consola' ? 'Soporte Nivel 1' : `Módulo ${activeTab}`}
          </h1>
          <div className="flex items-center gap-6">
            {isPhoneUser && <StatusSelector />}
            <span className="px-4 py-2 bg-purple-100 text-purple-700 font-semibold rounded-full text-sm flex items-center gap-2">
              <span className="capitalize">{userRole}</span>
            </span>
            <div className="flex items-center gap-4 border-l pl-6 border-gray-200">
              <div className="text-right">
                <p className="font-bold">{session?.fullName || 'Usuario'} (IT)</p>
                {isPhoneUser && (
                  <p className="text-xs flex items-center justify-end gap-1 font-semibold text-green-600">
                    <span className={`w-2 h-2 rounded-full ${showConnected ? 'bg-green-500 animate-pulse' : 'bg-yellow-500'}`}></span>
                    {showConnected ? 'Conectado' : (sipStatus || status)}
                  </p>
                )}
              </div>
              <button onClick={handleLogout} className="ml-2 p-2 bg-red-50 hover:bg-red-100 text-red-600 font-bold rounded-lg transition-colors flex items-center gap-2">
                🚪 Salir
              </button>
            </div>
          </div>
        </header>

        {/* CONTENEDOR DINÁMICO */}
        <div className="p-8 flex-1 overflow-y-auto">

          {/* PESTAÑA: CONSOLA */}
          {activeTab === 'Consola' && isPhoneUser && (
            <div className="grid grid-cols-12 gap-8 max-w-7xl mx-auto">
              <div className="col-span-8 flex flex-col gap-6">
                {activeCallsList.length > 0 ? (
                  <div className="flex flex-col gap-0 h-full">
                    <div className="flex items-center gap-2 overflow-x-auto pb-0 px-3 pt-3 bg-gray-200/60 rounded-t-2xl border-b border-gray-300">
                      {activeCallsList.map((c, i) => {
                        const isActiveTab = activeCall?.id === c.id;
                        const isHeld = c.status === 'onhold';
                        return (
                          <div key={c.id} onClick={() => setActiveCall(c)} className={`flex items-center gap-3 px-4 py-2 rounded-t-xl border transition-all cursor-pointer select-none ${isActiveTab ? 'bg-white border-gray-300 border-b-white shadow-sm font-bold text-red-600 relative top-[1px] z-10' : 'bg-gray-100/50 text-gray-500 hover:bg-gray-100 border-transparent z-0'}`}>
                            <div className="flex items-center gap-2 text-sm">
                              <span className={`w-2 h-2 rounded-full ${isHeld ? 'bg-yellow-500' : 'bg-green-500 animate-pulse'}`}></span>
                              Línea {i + 1} {isHeld ? '(Espera)' : ''}
                            </div>
                            <button onClick={(e) => { e.stopPropagation(); isHeld ? softphone.unholdCall(c.id) : softphone.holdCall(c.id); }} className={`ml-1 p-1.5 rounded-md transition-colors ${isHeld ? 'bg-yellow-100 hover:bg-yellow-200 text-yellow-700' : 'hover:bg-gray-200 text-gray-500'}`}>
                              {isHeld ? '▶️' : '⏸️'}
                            </button>
                          </div>
                        );
                      })}
                    </div>
                    <div className="bg-white border-l border-r border-b border-gray-300 rounded-b-2xl p-6 shadow-sm">
                      {activeCall && <ActiveCall call={activeCall} otherCalls={activeCallsList.filter(c => c.id !== activeCall.id)} onHangup={handleHangup} onMute={handleMute} isMuted={isMuted} onTransfer={softphone.transferCall} onAttendedTransfer={softphone.attendedTransfer} onMakeCall={handleMakeCall} />}
                    </div>
                  </div>
                ) : <CallQueue />}
              </div>
              <div className="col-span-4 flex flex-col gap-6">
                <Dialpad makeCall={handleMakeCall} transferCall={softphone.transferCall} isOnCall={status === 'oncall' || !!activeCall} />
              </div>
            </div>
          )}

{activeTab === 'Métricas' && <div className="max-w-7xl mx-auto"><SofiaDashboard /></div>}
	{/* 🟢 NUEVA PESTAÑA DE MONITOREO */}
          {activeTab === 'Monitoreo' && <div className="max-w-7xl mx-auto"><LiveWallboard /></div>}          
          {activeTab === 'Gestión' && <AdminPanel />}
          {activeTab === 'asuetos' && <AsuetosPanel />}
          {/* 🟢 NUEVO: DIBUJAMOS EL PANEL DE IA */}
          {activeTab === 'Entrenar' && <KnowledgePanel />}
	  {/* 🟢 NUEVO: DIBUJAMOS LA BASE DE CONOCIMIENTO (Sofía Chat) */}
          {activeTab === 'Base' && <KnowledgeBase />}

          {/* 🟢 ACTUALIZADO: LE DECIMOS QUE "Entrenar" YA NO ESTÁ EN CONSTRUCCIÓN */}
          {!['Consola', 'Métricas', 'Gestión', 'Entrenar'].includes(activeTab) && (
            <div className="max-w-7xl mx-auto bg-white p-12 rounded-2xl shadow-sm text-center border border-gray-200">
              <p className="text-gray-400 text-lg font-medium">Módulo de {activeTab} en construcción.</p>
            </div>
          )}
        </div>
      </div>

      {incomingCall && <IncomingCallModal onAnswer={softphone.answerCall} onReject={handleHangup} />}
    </div>
  );
}
