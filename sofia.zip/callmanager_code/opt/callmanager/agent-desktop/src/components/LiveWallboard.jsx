'use client';

import React, { useState, useEffect, useCallback } from 'react';
import axios from 'axios';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '@/lib/firebase-client';
import { 
  Activity, PhoneCall, Clock, Users, Headset, AlertTriangle, 
  Bot, BarChart2, UserCheck, Target, PhoneIncoming, ArrowRightLeft,
  PhoneMissed, UserMinus
} from 'lucide-react';

// ─── Helpers para el cronómetro en vivo ─────────────────────────────────────
function useLiveTimer() {
  const [now, setNow] = useState(Date.now());
  useEffect(() => {
    const iv = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(iv);
  }, []);
  return now;
}

// 🚀 PARCHE: Cronómetro a prueba de fallos y formatos de Firebase
function formatLiveTime(timestamp, now) {
  if (!timestamp) return '00:00';

  let timeMs;
  if (typeof timestamp.toDate === 'function') {
    timeMs = timestamp.toDate().getTime();
  } else if (timestamp.seconds || timestamp._seconds) {
    timeMs = (timestamp.seconds || timestamp._seconds) * 1000;
  } else {
    timeMs = new Date(timestamp).getTime();
  }

  const diff = Math.floor((now - timeMs) / 1000);
  
  if (diff < 0 || isNaN(diff)) return '00:00';
  
  const h = Math.floor(diff / 3600);
  const m = Math.floor((diff % 3600) / 60).toString().padStart(2, '0');
  const s = (diff % 60).toString().padStart(2, '0');
  
  return h > 0 ? `${h}:${m}:${s}` : `${m}:${s}`;
}

export function LiveWallboard() {
  const [agentesEnVivo, setAgentesEnVivo] = useState([]);
  const [kpisDia, setKpisDia] = useState({ 
    total: 0, resueltas_ia: 0, atendidas_humanos: 0, transferidas: 0,
    en_cola_entrada: 0, en_cola_agentes: 0, abandonadas: 0, perdidas_agentes: 0
  });
  const now = useLiveTimer();

  useEffect(() => {
    const q = query(collection(db, 'agents'), orderBy('extension'));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const agentes = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAgentesEnVivo(agentes);
    });
    return () => unsubscribe();
  }, []);

  const cargarMetricasDelDia = useCallback(async () => {
    try {
      const res = await axios.get('/api/dashboard/resumen');
      if (res.data) {
        const kpis = res.data.kpis || res.data;
        const stats = res.data.statsAgentes || [];
        
        const totalHumanos = stats.reduce((acc, curr) => acc + (parseInt(curr.contestadas) || 0), 0);
        const totalPerdidasHumanos = stats.reduce((acc, curr) => acc + (parseInt(curr.perdidas) || 0), 0);
        
// 🚀 PARCHE: Usamos ?? para respetar el cero absoluto del día
        setKpisDia({
          total: kpis.llamadas_hoy ?? 0,
          resueltas_ia: kpis.resueltas_ia ?? 0,
          transferidas: kpis.transferidas ?? 0,
          atendidas_humanos: totalHumanos ?? 0,
          en_cola_entrada: kpis.en_cola_entrada ?? 0,
          en_cola_agentes: kpis.en_cola_agentes ?? 0,
          abandonadas: kpis.abandonadas ?? 0,
          perdidas_agentes: totalPerdidasHumanos ?? 0,
          tasa_resolucion: kpis.tasa_resolucion ?? 0  // 👈 ¡ESTA ES LA LÍNEA MÁGICA QUE FALTABA!
        });
      }
    } catch (error) {
      console.error("Error al actualizar métricas", error);
    }
  }, []);

  useEffect(() => {
    cargarMetricasDelDia();
    const iv = setInterval(cargarMetricasDelDia, 5000); 
    return () => clearInterval(iv);
  }, [cargarMetricasDelDia]);

  // ─── Lógica de Filtros (ESTRICTA ANTI-FANTASMAS) ──────────────────────────
  const agentesOperativos = agentesEnVivo.filter(a => {
    const rol = (a.role || a.rol || '').toLowerCase();
    return rol !== 'admin' && rol !== 'supervisor' && rol !== 'admin-agent';
  });

  // Exigimos a.statusUpdatedAt para considerar que es un evento legítimo y no un fantasma
  const agentesOnCall = agentesOperativos.filter(a => a.status === 'oncall' && a.statusUpdatedAt);
  const agentesDisponibles = agentesOperativos.filter(a => a.status === 'available' && a.statusUpdatedAt);
  const agentesAusentes = agentesOperativos.filter(a => !['available', 'oncall', 'offline', ''].includes(a.status || '') && a.statusUpdatedAt);
  
  const totalLogueados = agentesDisponibles.length + agentesOnCall.length + agentesAusentes.length;
  
  const agentesActivos = agentesOperativos.filter(a => 
    a.status && 
    a.status !== 'offline' && 
    a.statusUpdatedAt 
  );
  
  const tasaResolucionIA = kpisDia.total > 0 ? Math.round((kpisDia.resueltas_ia / kpisDia.total) * 100) : 0;

  return (
    <div className="min-h-[85vh] bg-gray-50 rounded-2xl p-6 text-gray-800 font-sans shadow-md border border-gray-200 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-1.5 bg-[#ED1C24]"></div>

      {/* CABECERA */}
      <div className="flex justify-between items-center mb-6 border-b border-gray-200 pb-5 mt-2">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-red-50 text-[#ED1C24] rounded-xl animate-pulse ring-1 ring-red-100"><Activity size={28} /></div>
          <div>
            <h1 className="text-3xl font-black tracking-tight text-gray-900 m-0 leading-tight uppercase">Wallboard Operativo</h1>
            <p className="text-gray-500 text-sm m-0 flex items-center gap-2 font-medium mt-1">
              <span className="w-2 h-2 rounded-full bg-[#10B981] animate-pulse"></span> Monitoreo Híbrido en Tiempo Real
            </p>
          </div>
        </div>
        <div className="text-5xl font-mono font-black tracking-widest text-gray-800 drop-shadow-sm">
          {new Date(now).toLocaleTimeString('es-SV', { hour12: false })}
        </div>
      </div>

      {/* MONITOR DE COLAS (ALARMAS) */}
      <div className="grid grid-cols-2 gap-6 mb-8">
        <div className={`rounded-xl p-5 border-2 transition-all duration-300 flex items-center justify-between shadow-sm ${kpisDia.en_cola_entrada > 0 ? 'bg-blue-50 border-blue-400 animate-pulse' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-4">
            <div className={`p-4 rounded-full ${kpisDia.en_cola_entrada > 0 ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-400'}`}><PhoneIncoming size={28} /></div>
            <div>
              <p className={`font-black text-sm tracking-widest uppercase mb-1 ${kpisDia.en_cola_entrada > 0 ? 'text-blue-600' : 'text-gray-400'}`}>Clientes en IVR / Sofía</p>
              <p className={`text-xs font-semibold ${kpisDia.en_cola_entrada > 0 ? 'text-blue-500' : 'text-gray-400'}`}>Llamadas entrantes activas</p>
            </div>
          </div>
          <div className={`text-6xl font-black ${kpisDia.en_cola_entrada > 0 ? 'text-blue-600' : 'text-gray-300'}`}>{kpisDia.en_cola_entrada}</div>
        </div>
        <div className={`rounded-xl p-5 border-2 transition-all duration-300 flex items-center justify-between shadow-sm ${kpisDia.en_cola_agentes > 0 ? 'bg-red-50 border-[#ED1C24] animate-pulse shadow-[0_0_20px_rgba(237,28,36,0.2)]' : 'bg-white border-gray-200'}`}>
          <div className="flex items-center gap-4">
            <div className={`p-4 rounded-full ${kpisDia.en_cola_agentes > 0 ? 'bg-[#ED1C24] text-white' : 'bg-gray-100 text-gray-400'}`}><ArrowRightLeft size={28} /></div>
            <div>
              <p className={`font-black text-sm tracking-widest uppercase mb-1 ${kpisDia.en_cola_agentes > 0 ? 'text-[#ED1C24]' : 'text-gray-400'}`}>En Cola de Espera (Humanos)</p>
              <p className={`text-xs font-semibold ${kpisDia.en_cola_agentes > 0 ? 'text-red-400' : 'text-gray-400'}`}>Requieren asistencia de agente</p>
            </div>
          </div>
          <div className={`text-6xl font-black ${kpisDia.en_cola_agentes > 0 ? 'text-[#ED1C24]' : 'text-gray-300'}`}>{kpisDia.en_cola_agentes}</div>
        </div>
      </div>

      {/* ESTADO DE AGENTES */}
      <div className="grid grid-cols-4 gap-6 mb-8">
        <div className="bg-white border border-gray-100 border-t-4 border-t-gray-500 rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div className="text-gray-500 font-bold text-xs tracking-widest uppercase flex items-center gap-2 mb-2"><Users size={16}/> Conectados Ahora</div>
          <div className="text-4xl font-black text-gray-900">{totalLogueados}</div>
        </div>
        <div className="bg-white border border-gray-100 border-t-4 border-t-[#10B981] rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div className="text-[#10B981] font-bold text-xs tracking-widest uppercase flex items-center gap-2 mb-2"><Headset size={16}/> Listos (Available)</div>
          <div className="text-4xl font-black text-gray-900">{agentesDisponibles.length}</div>
        </div>
        <div className="bg-white border border-gray-100 border-t-4 border-t-[#ED1C24] rounded-xl p-6 shadow-sm flex flex-col justify-between relative overflow-hidden">
          {agentesOnCall.length > 0 && <div className="absolute top-0 left-0 w-full h-full bg-red-50/50 animate-pulse"></div>}
          <div className="text-[#ED1C24] font-bold text-xs tracking-widest uppercase flex items-center gap-2 mb-2 relative z-10"><PhoneCall size={16}/> En Llamada</div>
          <div className="text-4xl font-black text-gray-900 relative z-10">{agentesOnCall.length}</div>
        </div>
        <div className="bg-white border border-gray-100 border-t-4 border-t-[#F59E0B] rounded-xl p-6 shadow-sm flex flex-col justify-between">
          <div className="text-[#F59E0B] font-bold text-xs tracking-widest uppercase flex items-center gap-2 mb-2"><AlertTriangle size={16}/> En Pausa (Break)</div>
          <div className="text-4xl font-black text-gray-900">{agentesAusentes.length}</div>
        </div>
      </div>

      {/* ACUMULADO DEL DÍA */}
      <div className="mb-8">
        <h2 className="text-xs font-bold text-gray-500 mb-3 uppercase tracking-wider flex items-center gap-2">
          <BarChart2 className="w-4 h-4" /> Resumen Operativo (Hoy)
        </h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
          
          <div className="bg-white border border-gray-200 rounded-lg p-3 flex flex-col justify-center shadow-sm">
            <p className="text-gray-400 text-[10px] font-bold uppercase tracking-wider mb-1 flex items-center gap-1"><Activity size={12}/> Entrantes (Hoy)</p>
            <p className="text-xl font-black text-gray-700">{kpisDia.total}</p>
          </div>
          
          <div className="bg-white border border-gray-200 rounded-lg p-3 flex flex-col justify-center shadow-sm">
            <p className="text-[#8B5CF6] text-[10px] font-bold uppercase tracking-wider mb-1 flex items-center gap-1"><Bot size={12}/> Atendidas IA</p>
            <p className="text-xl font-black text-[#8B5CF6]">{kpisDia.resueltas_ia}</p>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-3 flex flex-col justify-center shadow-sm">
            <p className="text-[#3B82F6] text-[10px] font-bold uppercase tracking-wider mb-1 flex items-center gap-1"><UserCheck size={12}/> Atendidas Humanos</p>
            <p className="text-xl font-black text-[#3B82F6]">{kpisDia.atendidas_humanos}</p>
          </div>

          <div className="bg-white border border-gray-200 rounded-lg p-3 flex flex-col justify-center shadow-sm">
            <p className="text-[#10B981] text-[10px] font-bold uppercase tracking-wider mb-1 flex items-center gap-1"><Target size={12}/> Contención IA</p>
	    <p className="text-xl font-black text-[#10B981]">{kpisDia.tasa_resolucion || 0}%</p>
          </div>

          <div className="bg-white border border-red-200 bg-red-50/30 rounded-lg p-3 flex flex-col justify-center shadow-sm">
            <p className="text-red-600 text-[10px] font-bold uppercase tracking-wider mb-1 flex items-center gap-1"><UserMinus size={12}/> Abandonos (Cola)</p>
	    <p className="text-xl font-black text-red-600">{kpisDia.abandonadas}</p>
          </div>

          <div className="bg-white border border-orange-200 bg-orange-50/30 rounded-lg p-3 flex flex-col justify-center shadow-sm">
            <p className="text-orange-600 text-[10px] font-bold uppercase tracking-wider mb-1 flex items-center gap-1"><PhoneMissed size={12}/> Perdidas (Agentes)</p>
            <p className="text-xl font-black text-orange-600">{kpisDia.perdidas_agentes}</p>
          </div>

        </div>
      </div>

      {/* CUADRÍCULA DE AGENTES */}
      <h2 className="text-lg font-bold text-gray-800 mb-5 border-b border-gray-200 pb-2 flex items-center gap-2">
        <Users className="w-5 h-5 text-[#ED1C24]" /> Operadores en Turno
      </h2>
      
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
        {agentesActivos.map(agente => {
          const isCall = agente.status === 'oncall';
          const isAvail = agente.status === 'available';
          const isBreak = !isCall && !isAvail;
          
          let bgColor = "bg-white"; let borderColor = "border-gray-200"; let statusText = "EN PAUSA"; let textColor = "text-[#F59E0B]"; let iconBg = "bg-amber-50 text-[#F59E0B]"; let shadow = "shadow-sm"; let statusBox = "bg-amber-50 border-amber-100";
          if (isAvail) { bgColor = "bg-white"; borderColor = "border-[#10B981]"; statusText = "DISPONIBLE"; textColor = "text-[#10B981]"; iconBg = "bg-emerald-50 text-[#10B981]"; statusBox = "bg-emerald-50 border-emerald-100"; } 
          else if (isCall) { bgColor = "bg-red-50/30"; borderColor = "border-[#ED1C24]"; statusText = "EN LLAMADA"; textColor = "text-[#ED1C24]"; iconBg = "bg-[#ED1C24] text-white"; shadow = "shadow-[0_4px_15px_rgba(237,28,36,0.15)]"; statusBox = "bg-red-50 border-red-100"; }

          return (
            <div key={agente.id} className={`${bgColor} border ${borderColor} ${shadow} rounded-2xl p-5 flex flex-col relative transition-all duration-300`}>
              {isCall && <div className="absolute top-0 left-0 w-full h-1 bg-[#ED1C24] animate-pulse rounded-t-2xl"></div>}
              <div className="flex justify-between items-start mb-4">
                <div className="overflow-hidden">
                  <h3 className="text-gray-900 font-bold text-lg leading-tight truncate pr-2">{agente.fullName}</h3>
                  <p className="text-gray-500 font-mono text-xs mt-1">Ext: <span className="text-gray-800 font-semibold">{agente.extension}</span></p>
                </div>
                <div className={`p-2.5 rounded-xl ${iconBg} shrink-0`}><Headset size={20} /></div>
              </div>
              <div className={`mt-auto rounded-xl p-3 border ${statusBox}`}>
                <div className={`font-black text-[10px] tracking-widest mb-1 ${textColor}`}>{statusText}</div>
                <div className={`flex items-center gap-2 text-2xl font-mono font-bold tracking-wider ${isCall ? 'text-gray-900' : 'text-gray-700'}`}>
                  <Clock size={16} className={textColor} />
                  {formatLiveTime(agente.statusUpdatedAt, now)}
                </div>
              </div>
            </div>
          );
        })}
        {agentesActivos.length === 0 && (
          <div className="col-span-full py-12 text-center bg-white rounded-2xl border border-gray-200 border-dashed">
            <div className="inline-block p-4 rounded-full bg-gray-50 mb-4"><Users size={32} className="text-gray-400" /></div>
            <p className="text-gray-500 font-medium text-lg">No hay agentes conectados en este momento.</p>
          </div>
        )}
      </div>
    </div>
  );
}
