'use client';

import { useState, useEffect } from 'react';
import { Database, Trash2, CheckCircle2, Loader2, Bot, Type, AlignLeft, Save, BookOpen, RefreshCw, ShieldAlert, Sparkles, Eye, X, Edit } from 'lucide-react';

export function KnowledgePanel() {
  const [activeBase, setActiveBase] = useState('basic'); // 'basic' o 'tech'
  const [formData, setFormData] = useState({ title: '', content: '' });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoadingDocs, setIsLoadingDocs] = useState(true);
  const [successMsg, setSuccessMsg] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [documents, setDocuments] = useState([]);

  // 🆕 ESTADOS PARA DIRECTRICES (PROMPT OPS)
  const [promptIA, setPromptIA] = useState("");
  const [guardandoPrompt, setGuardandoPrompt] = useState(false);

  // 🆕 ESTADOS PARA VER, EDITAR Y ELIMINAR
  const [viewingDoc, setViewingDoc] = useState(null);
  const [editingDoc, setEditingDoc] = useState(null);
  const [deletingId, setDeletingId] = useState(null);

  // CARGAR EL PROMPT AL ENTRAR A LA PESTAÑA
  useEffect(() => {
    fetch('/api/admin/prompt')
      .then(res => res.json())
      .then(data => { if (data.prompt) setPromptIA(data.prompt); })
      .catch(err => console.error("Error cargando prompt de IA", err));
  }, []);

  const fetchDocuments = async () => {
    setIsLoadingDocs(true);
    try {
      const res = await fetch(`/api/admin/knowledge?base=${activeBase}`);
      const data = await res.json();
      if (res.ok && data.documents) {
        setDocuments(data.documents);
      } else {
        setDocuments([]);
      }
    } catch (error) {
      console.error("Error cargando documentos:", error);
      setDocuments([]);
    } finally {
      setIsLoadingDocs(false);
    }
  };

  useEffect(() => {
    fetchDocuments();
  }, [activeBase]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // CREAR NUEVO DOCUMENTO
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSuccessMsg(''); setErrorMsg('');
    try {
      const res = await fetch('/api/admin/knowledge', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, base: activeBase })
      });
      const result = await res.json();
      if (!res.ok) throw new Error(result.error || 'Error al comunicar con GCP.');

      const newDoc = { id: result.documentId, title: formData.title, content: formData.content, date: 'Recién indexado' };
      setDocuments([newDoc, ...documents]);
      setFormData({ title: '', content: '' });
      setSuccessMsg(`¡Procedimiento guardado con éxito!`);
      setTimeout(() => setSuccessMsg(''), 5000);
    } catch (error) {
      setErrorMsg(error.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  // ELIMINAR DOCUMENTO
  const handleDelete = async (id) => {
    if (!confirm("⚠️ ¿Estás seguro de eliminar este documento? Sofía perderá este conocimiento inmediatamente.")) return;
    setDeletingId(id);
    try {
      const res = await fetch(`/api/admin/knowledge?base=${activeBase}&id=${id}`, { method: 'DELETE' });
      if (res.ok) {
        setDocuments(documents.filter(d => d.id !== id));
        setSuccessMsg('Documento eliminado correctamente.');
        setTimeout(() => setSuccessMsg(''), 5000);
      } else throw new Error("Error eliminando documento");
    } catch (error) {
      setErrorMsg(error.message);
    } finally {
      setDeletingId(null);
    }
  };

  // EDITAR DOCUMENTO
  const handleEditSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/knowledge', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...editingDoc, base: activeBase })
      });
      if (res.ok) {
        setDocuments(documents.map(d => d.id === editingDoc.id ? editingDoc : d));
        setSuccessMsg('¡Documento actualizado con éxito!');
        setTimeout(() => setSuccessMsg(''), 5000);
        setEditingDoc(null);
      } else throw new Error("Error actualizando documento");
    } catch (error) {
      setErrorMsg(error.message);
    }
  };

  return (
    <div className="max-w-7xl mx-auto flex flex-col gap-6 animate-fadeIn">
      {/* Cabecera */}
      <div className="flex items-center justify-between bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600">
            <Bot className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-gray-900">Entrenamiento del Conocimiento (Vertex AI)</h2>
            <p className="text-sm text-gray-500">Inyecta y segmenta la información de la compañía en repositorios aislados.</p>
          </div>
        </div>
      </div>

      {/* Selector de Bases de Datos */}
      <div className="flex bg-gray-200 p-1.5 rounded-xl max-w-md shadow-inner">
        <button onClick={() => setActiveBase('basic')} className={`flex-1 py-2.5 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-all ${activeBase === 'basic' ? 'bg-white text-blue-600 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}>
          <Sparkles className="w-4 h-4" /> Base Básica (Sofía)
        </button>
        <button onClick={() => setActiveBase('tech')} className={`flex-1 py-2.5 rounded-lg font-bold text-sm flex items-center justify-center gap-2 transition-all ${activeBase === 'tech' ? 'bg-white text-purple-600 shadow-sm' : 'text-gray-600 hover:text-gray-900'}`}>
          <ShieldAlert className="w-4 h-4" /> Base Técnica
        </button>
      </div>

      {/* PANEL PROMPT OPS */}
      <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center text-purple-600">
            <Bot className="w-5 h-5" />
          </div>
          <h3 className="font-bold text-gray-900 text-lg">Directrices de Comportamiento (Prompt Ops)</h3>
        </div>
        <p className="text-sm text-gray-500 mb-4 ml-11">
          Modifica la personalidad y reglas de la IA en tiempo real. Los cambios afectarán inmediatamente a las nuevas llamadas.
        </p>
        <textarea
          className="w-full min-h-[200px] p-4 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:outline-none focus:ring-purple-500 font-mono text-sm resize-y text-gray-800 leading-relaxed shadow-inner"
          value={promptIA}
          onChange={(e) => setPromptIA(e.target.value)}
          placeholder="Cargando directrices..."
        />
        <div className="flex justify-end mt-4">
          <button
            onClick={async () => {
              setGuardandoPrompt(true);
              try {
                const response = await fetch('/api/admin/prompt', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ prompt: promptIA }) });
                if (response.ok) alert("¡Directrices actualizadas en vivo con éxito! 🚀");
              } catch (err) { alert("Error de conexión al guardar."); }
              setGuardandoPrompt(false);
            }}
            disabled={guardandoPrompt}
            className="bg-purple-600 hover:bg-purple-700 disabled:bg-purple-300 text-white px-6 py-2.5 rounded-xl font-bold flex items-center justify-center gap-2 transition-all shadow-sm"
          >
            {guardandoPrompt ? <Loader2 className="w-5 h-5 animate-spin" /> : <Sparkles className="w-5 h-5" />}
            {guardandoPrompt ? "Aplicando..." : "Aplicar Directrices en Vivo"}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-8">
        {/* FORMULARIO */}
        <div className="col-span-5 flex flex-col gap-6">
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col h-full">
            <h3 className="font-bold text-gray-800 mb-6 flex items-center gap-2">
              <BookOpen className={`w-5 h-5 ${activeBase === 'basic' ? 'text-blue-600' : 'text-purple-600'}`} /> Nuevo Documento
            </h3>
            {successMsg && <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl flex items-center gap-3 text-green-700 text-sm font-semibold"><CheckCircle2 className="w-5 h-5 flex-shrink-0" /> {successMsg}</div>}
            {errorMsg && <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-xl text-red-700 text-sm font-semibold">{errorMsg}</div>}
            
            <form onSubmit={handleSubmit} className="flex flex-col gap-5 flex-1">
              <div>
                <label className="text-sm font-bold text-gray-700 mb-2 flex items-center gap-2"><Type className="w-4 h-4 text-gray-400" /> Título</label>
                <input required name="title" value={formData.title} onChange={handleChange} className="w-full px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:outline-none focus:ring-blue-500 font-medium text-gray-800" />
              </div>
              <div className="flex-1 flex flex-col">
                <label className="text-sm font-bold text-gray-700 mb-2 flex items-center gap-2"><AlignLeft className="w-4 h-4 text-gray-400" /> Contenido</label>
                <textarea required name="content" value={formData.content} onChange={handleChange} className="w-full flex-1 min-h-[250px] px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl focus:ring-2 focus:outline-none focus:ring-blue-500 text-sm resize-none" />
              </div>
              <button type="submit" disabled={isSubmitting || !formData.title || !formData.content} className={`w-full mt-2 text-white py-3.5 rounded-xl font-bold flex items-center justify-center gap-2 shadow-sm ${activeBase === 'basic' ? 'bg-blue-600 hover:bg-blue-700 disabled:bg-blue-300' : 'bg-purple-600 hover:bg-purple-700 disabled:bg-purple-300'}`}>
                {isSubmitting ? <Loader2 className="w-5 h-5 animate-spin" /> : <Save className="w-5 h-5" />}
                {isSubmitting ? 'Inyectando...' : 'Guardar en Base'}
              </button>
            </form>
          </div>
        </div>

        {/* TABLA DE CONTENIDOS EN VIVO */}
        <div className="col-span-7">
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden h-full flex flex-col">
            <div className="p-6 border-b border-gray-200 flex items-center justify-between bg-gray-50">
              <h3 className="font-bold text-gray-800 flex items-center gap-2">
                <Database className="w-5 h-5 text-gray-500" /> Almacén: {activeBase === 'basic' ? 'callmanager-kb-v2' : 'callmanager-kb-tech'}
              </h3>
              <div className="flex items-center gap-3">
                <button onClick={fetchDocuments} className="p-2 bg-white border border-gray-200 text-gray-500 hover:text-blue-600 rounded-lg"><RefreshCw className={`w-4 h-4 ${isLoadingDocs ? 'animate-spin' : ''}`} /></button>
                <span className="px-3 py-1 bg-white border border-gray-200 text-gray-600 text-xs font-bold rounded-full">{documents.length} Docs</span>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-4">
              {isLoadingDocs ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 gap-3"><Loader2 className="w-8 h-8 animate-spin" /></div>
              ) : documents.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-gray-400 gap-2"><Database className="w-12 h-12 text-gray-300 mb-2" /></div>
              ) : (
                <div className="flex flex-col gap-2">
                  {documents.map((doc, i) => (
                    <div key={i} className={`flex items-center justify-between p-4 bg-white border rounded-xl transition-all shadow-sm ${activeBase === 'basic' ? 'border-gray-100 hover:border-blue-200 hover:bg-blue-50' : 'border-gray-100 hover:border-purple-200 hover:bg-purple-50'}`}>
                      <div className="flex items-center gap-4 overflow-hidden">
                        <div className={`w-10 h-10 text-white rounded-lg flex items-center justify-center font-bold shadow-sm flex-shrink-0 bg-gradient-to-br ${activeBase === 'basic' ? 'from-blue-500 to-blue-600' : 'from-purple-500 to-purple-600'}`}>
                          {doc.title.charAt(0).toUpperCase()}
                        </div>
                        <div className="overflow-hidden">
                          <p className="font-bold text-gray-800 text-sm truncate">{doc.title}</p>
                          <p className="text-[10px] font-mono text-gray-400 truncate mt-0.5">ID: {doc.id}</p>
                        </div>
                      </div>
                      
                      {/* BOTONERA DE ACCIONES */}
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button onClick={() => setViewingDoc(doc)} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-100 rounded-lg" title="Ver detalle"><Eye className="w-5 h-5" /></button>
                        <button onClick={() => setEditingDoc(doc)} className="p-2 text-gray-400 hover:text-green-600 hover:bg-green-100 rounded-lg" title="Editar"><Edit className="w-5 h-5" /></button>
                        <button onClick={() => handleDelete(doc.id)} disabled={deletingId === doc.id} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-100 rounded-lg" title="Eliminar">
                          {deletingId === doc.id ? <Loader2 className="w-5 h-5 animate-spin text-red-500" /> : <Trash2 className="w-5 h-5" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* 🔍 MODAL: LEER DOCUMENTO */}
      {viewingDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            <div className="p-5 border-b border-gray-100 flex justify-between bg-gray-50 items-center">
              <h3 className="font-bold text-lg text-gray-800 flex items-center gap-2"><BookOpen className="w-5 h-5 text-blue-600"/> {viewingDoc.title}</h3>
              <button onClick={() => setViewingDoc(null)} className="p-2 hover:bg-gray-200 rounded-lg"><X className="w-5 h-5 text-gray-500"/></button>
            </div>
            <div className="p-6 overflow-y-auto whitespace-pre-wrap font-mono text-sm text-gray-700 bg-white">
              {viewingDoc.content}
            </div>
          </div>
        </div>
      )}

      {/* ✏️ MODAL: EDITAR DOCUMENTO */}
      {editingDoc && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-gray-900/40 backdrop-blur-sm p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col">
            <div className="p-5 border-b border-gray-100 flex justify-between bg-gray-50 items-center">
              <h3 className="font-bold text-lg text-gray-800 flex items-center gap-2"><Edit className="w-5 h-5 text-green-600"/> Editar Documento</h3>
              <button onClick={() => setEditingDoc(null)} className="p-2 hover:bg-gray-200 rounded-lg"><X className="w-5 h-5 text-gray-500"/></button>
            </div>
            <form onSubmit={handleEditSubmit} className="p-6 flex flex-col gap-4">
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Título</label>
                <input value={editingDoc.title} onChange={e => setEditingDoc({...editingDoc, title: e.target.value})} className="w-full mt-1 px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl font-bold focus:ring-2 focus:ring-green-500 outline-none" />
              </div>
              <div>
                <label className="text-xs font-bold text-gray-500 uppercase">Contenido</label>
                <textarea value={editingDoc.content} onChange={e => setEditingDoc({...editingDoc, content: e.target.value})} className="w-full mt-1 h-[40vh] px-4 py-3 bg-gray-50 border border-gray-300 rounded-xl font-mono text-sm resize-none focus:ring-2 focus:ring-green-500 outline-none" />
              </div>
              <button type="submit" className="w-full mt-2 bg-green-600 hover:bg-green-700 text-white font-bold py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-sm transition-all">
                <Save className="w-5 h-5"/> Guardar Cambios en Vivo
              </button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
