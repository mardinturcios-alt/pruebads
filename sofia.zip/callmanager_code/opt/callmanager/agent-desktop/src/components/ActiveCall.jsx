'use client';

import { useEffect, useState } from 'react';
import { PhoneOff, Mic, MicOff, User, Clock, Brain, Sparkles, Bot, PhoneForwarded, Edit2, Save, X, Hash, Mail, Briefcase } from 'lucide-react';
import clsx from 'clsx';

// Importaciones de Firebase para ir por el contexto de la IA
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '@/lib/firebase-client';

export function ActiveCall({
  call,
  otherCalls,
  onHangup,
  onMute,
  isMuted,
  onTransfer,
  onAttendedTransfer,
  onMakeCall
}) {
  const isConnected = call.status === 'connected';

  // Estados para controlar el menú de transferencia
  const [showTransferMode, setShowTransferMode] = useState(false);
  const [transferTarget, setTransferTarget] = useState('');

  // Estados para el Screen Pop de la IA
  const [aiSession, setAiSession] = useState(null);
  const [isLoadingContext, setIsLoadingContext] = useState(true);

  // Estados para el Modo Edición de Usuario
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [formData, setFormData] = useState({
    nombre: '', peoplesoft_id: '', correo: '', area: '', jefe: ''
  });

  // VIGILANTE DE CONTEXTO: Va a buscar qué habló el usuario con Sofía IA
  useEffect(() => {
    if (!call.callerNumber || call.direction === 'outbound') {
      setIsLoadingContext(false);
      return;
    }

    const fetchAiSession = async () => {
      try {
        const q = query(
          collection(db, 'call_sessions'),
          where('callerNumber', '==', call.callerNumber)
        );
        const snap = await getDocs(q);
        
        if (!snap.empty) {
          const sessions = snap.docs.map(doc => doc.data());
          sessions.sort((a, b) => new Date(b.startedAt || 0) - new Date(a.startedAt || 0));
          setAiSession(sessions[0]);
        }
      } catch (e) {
        console.error("Error buscando sesión IA de Firebase:", e);
      } finally {
        setIsLoadingContext(false);
      }
    };

    fetchAiSession();
  }, [call.callerNumber, call.direction]);

  // Manejador para Iniciar Edición
  const handleEditClick = () => {
    setFormData({
      nombre: aiSession?.funcionario || '',
      peoplesoft_id: aiSession?.peoplesoft_id || '',
      correo: aiSession?.correo || '',
      area: aiSession?.area || '',
      jefe: aiSession?.jefe || ''
    });
    setIsEditing(true);
  };

  // Manejador para Guardar Cambios en PostgreSQL
  const handleSaveClick = async () => {
    setIsSaving(true);
    try {
      const host = typeof window !== 'undefined' ? window.location.hostname : 'localhost';
// 👇 Cambia la URL para que use el proxy global que acabamos de crear
      const response = await fetch(`/api/backend/usuarios/actualizar`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          telefono: call.callerNumber,
          ...formData
        })
      });

      if (response.ok) {
        // Actualizamos la vista local sin recargar
        setAiSession(prev => ({
          ...prev,
          funcionario: formData.nombre,
          peoplesoft_id: formData.peoplesoft_id,
          correo: formData.correo,
          area: formData.area,
          jefe: formData.jefe
        }));
        setIsEditing(false);
      } else {
        alert("Error al guardar en la base de datos.");
      }
    } catch (error) {
      console.error("Error guardando:", error);
      alert("Error de conexión al servidor.");
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      <div className="lg:col-span-1 space-y-4">
        {/* PANEL DE LLAMADA ACTIVA */}
        <div className="bg-white rounded-2xl border border-davivienda-gray-200 p-5 shadow-sm">
          <div className="flex items-center gap-3 mb-4">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${isConnected ? 'bg-davivienda-red/10' : 'bg-yellow-100 animate-pulse'}`}>
              <User className={`w-6 h-6 ${isConnected ? 'text-davivienda-red' : 'text-yellow-600'}`} />
            </div>
            <div>
              <p className="text-xs text-davivienda-gray-500 uppercase tracking-wide font-medium">
                {call.direction === 'outbound' ? 'Llamada Saliente' : 'Cliente en línea'}
              </p>
              <p className="font-semibold text-davivienda-gray-900 text-lg">
                {call.callerNumber}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 text-sm text-davivienda-gray-600 bg-gray-50 p-3 rounded-lg border border-gray-100 font-medium">
            <Clock className="w-4 h-4 text-blue-500" />
            {isConnected && call.startedAt ? (
              <CallTimer startedAt={call.startedAt} />
            ) : (
              <span className="font-mono text-gray-500 font-semibold animate-pulse">Llamando...</span>
            )}
            <span className={`ml-auto flex items-center gap-1 text-xs ${isConnected ? 'text-green-600' : 'text-yellow-600'}`}>
              <span className={`w-2 h-2 rounded-full ${isConnected ? 'bg-green-500 animate-pulse' : 'bg-yellow-500 animate-bounce'}`}></span>
              {isConnected ? 'Conectado' : 'Esperando'}
            </span>
          </div>
        </div>

        {/* BOTONERA DE ACCIONES */}
        <div className="bg-white rounded-2xl border border-davivienda-gray-200 p-4 shadow-sm text-center">
          <p className="text-xs font-bold text-davivienda-gray-500 uppercase tracking-wide mb-3">
            Acciones de Soporte
          </p>

          {/* Menú de Transferencia */}
          {showTransferMode ? (
            <div className="flex flex-col gap-3 bg-gray-50 p-3 rounded-xl border border-gray-200 text-left">
              <p className="text-xs font-bold text-gray-500 uppercase">¿A dónde transferir?</p>
              <div className="flex gap-2">
                <input
                  type="text" autoFocus placeholder="Extensión..."
                  className="w-full bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:border-blue-500"
                  value={transferTarget} onChange={(e) => setTransferTarget(e.target.value)}
                />
              </div>
              <div className="flex gap-2">
                <button onClick={() => { if (transferTarget.trim()) onTransfer(transferTarget.trim(), call.id); setShowTransferMode(false); }} className="flex-1 bg-gray-800 hover:bg-gray-900 text-white text-xs py-2 rounded-lg transition font-medium">Blind (Ciega)</button>
                <button onClick={() => { if (transferTarget.trim()) onMakeCall(transferTarget.trim()); setShowTransferMode(false); }} className="flex-1 bg-blue-500 hover:bg-blue-600 text-white text-xs py-2 rounded-lg transition font-medium">📞 Consultar</button>
              </div>
              {otherCalls && otherCalls.length > 0 && (
                <div className="mt-2 pt-2 border-t border-gray-200">
                  <p className="text-xs font-bold text-gray-500 mb-2">Unir con llamada actual:</p>
                  {otherCalls.map(otherCall => (
                    <button key={otherCall.id} onClick={() => { onAttendedTransfer(call.id, otherCall.id); setShowTransferMode(false); }} className="w-full flex items-center justify-between bg-green-100 hover:bg-green-200 text-green-800 text-xs px-3 py-2 rounded-lg transition font-bold">
                      <span>Línea: {otherCall.callerNumber}</span><span>🔀 Unir</span>
                    </button>
                  ))}
                </div>
              )}
              <button onClick={() => setShowTransferMode(false)} className="mt-1 text-xs text-gray-500 hover:text-gray-700 underline text-center w-full">Cancelar</button>
            </div>
          ) : (
            <div className="flex items-center justify-center gap-4">
              <button onClick={onMute} disabled={!isConnected} className={clsx('w-14 h-14 rounded-full flex items-center justify-center transition shadow-md', !isConnected ? 'bg-gray-100 text-gray-300 cursor-not-allowed' : isMuted ? 'bg-amber-500 hover:bg-amber-600 text-white hover:scale-105' : 'bg-gray-100 hover:bg-gray-200 text-gray-700 hover:scale-105')} title={isMuted ? 'Quitar mute' : 'Mute'}>
                {isMuted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
              </button>
              <button onClick={() => setShowTransferMode(true)} disabled={!isConnected} className={clsx('w-14 h-14 rounded-full flex items-center justify-center transition shadow-md', !isConnected ? 'bg-gray-100 text-gray-300 cursor-not-allowed' : 'bg-blue-500 hover:bg-blue-600 text-white hover:scale-105')} title="Transferir Llamada">
                <PhoneForwarded className="w-6 h-6" />
              </button>
              <button onClick={onHangup} className="w-14 h-14 rounded-full bg-red-500 hover:bg-red-600 text-white flex items-center justify-center transition shadow-md hover:scale-105" title="Colgar">
                <PhoneOff className="w-6 h-6" />
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="lg:col-span-2 space-y-4">
        {/* PANEL DEL COPILOTO IA & DATOS DEL USUARIO */}
        {isLoadingContext ? (
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl border border-purple-200 p-5 shadow-sm flex items-center gap-3 animate-pulse">
            <Brain className="w-6 h-6 text-purple-400" />
            <p className="text-sm font-bold text-purple-600">Sincronizando con Sofía IA...</p>
          </div>
        ) : aiSession ? (
          <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-2xl border border-purple-200 p-5 shadow-sm relative transition-all">
            
            <div className="flex items-center justify-between mb-4 border-b border-purple-200/50 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center shadow-sm">
                  <Brain className="w-4 h-4 text-white" />
                </div>
                <div>
                  <p className="text-sm font-bold text-purple-900">Contexto y Perfil de Usuario</p>
                </div>
              </div>
              
              {!isEditing ? (
                <button onClick={handleEditClick} className="flex items-center gap-1 text-xs font-bold bg-white text-purple-700 hover:bg-purple-100 border border-purple-200 px-3 py-1.5 rounded-full transition-colors shadow-sm">
                  <Edit2 className="w-3 h-3" /> Editar Datos
                </button>
              ) : (
                <div className="flex gap-2">
                  <button onClick={() => setIsEditing(false)} className="flex items-center gap-1 text-xs font-bold bg-white text-gray-500 hover:bg-gray-100 border border-gray-200 px-3 py-1.5 rounded-full transition-colors">
                    <X className="w-3 h-3" /> Cancelar
                  </button>
                  <button onClick={handleSaveClick} disabled={isSaving} className="flex items-center gap-1 text-xs font-bold bg-purple-600 text-white hover:bg-purple-700 border border-purple-700 px-3 py-1.5 rounded-full transition-colors shadow-sm">
                    {isSaving ? 'Guardando...' : <><Save className="w-3 h-3" /> Guardar</>}
                  </button>
                </div>
              )}
            </div>

            {/* MODO VISUALIZACIÓN vs MODO EDICIÓN */}
            {!isEditing ? (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4">
                <div className="bg-white/60 p-3 rounded-lg border border-purple-100 shadow-sm">
                  <p className="text-[10px] font-bold text-purple-500 uppercase tracking-wider mb-1 flex items-center gap-1"><User className="w-3 h-3"/> Funcionario</p>
                  <p className="text-sm font-bold text-gray-900 truncate">{aiSession.funcionario || 'No identificado'}</p>
                </div>
                <div className="bg-white/60 p-3 rounded-lg border border-purple-100 shadow-sm">
                  <p className="text-[10px] font-bold text-purple-500 uppercase tracking-wider mb-1 flex items-center gap-1"><Hash className="w-3 h-3"/> PeopleSoft ID</p>
                  <p className="text-sm font-bold text-gray-900 truncate">{aiSession.peoplesoft_id || '—'}</p>
                </div>
                <div className="bg-white/60 p-3 rounded-lg border border-purple-100 shadow-sm">
                  <p className="text-[10px] font-bold text-purple-500 uppercase tracking-wider mb-1 flex items-center gap-1"><Mail className="w-3 h-3"/> Correo</p>
                  <p className="text-xs font-bold text-gray-900 truncate">{aiSession.correo || '—'}</p>
                </div>
                <div className="bg-white/60 p-3 rounded-lg border border-purple-100 shadow-sm">
                  <p className="text-[10px] font-bold text-purple-500 uppercase tracking-wider mb-1 flex items-center gap-1"><Briefcase className="w-3 h-3"/> Área</p>
                  <p className="text-xs font-bold text-gray-900 truncate">{aiSession.area || '—'}</p>
                </div>
                <div className="bg-white/60 p-3 rounded-lg border border-purple-100 shadow-sm md:col-span-2">
                  <p className="text-[10px] font-bold text-purple-500 uppercase tracking-wider mb-1 flex items-center gap-1"><User className="w-3 h-3"/> Jefe Directo</p>
                  <p className="text-xs font-bold text-gray-900 truncate">{aiSession.jefe || '—'}</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 mb-4 bg-white p-4 rounded-xl shadow-inner border border-purple-200">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500 uppercase">Nombre</label>
                  <input type="text" value={formData.nombre} onChange={e => setFormData({...formData, nombre: e.target.value})} className="w-full text-sm border border-gray-300 rounded px-2 py-1.5 focus:border-purple-500 outline-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500 uppercase">PeopleSoft ID</label>
                  <input type="text" value={formData.peoplesoft_id} onChange={e => setFormData({...formData, peoplesoft_id: e.target.value})} className="w-full text-sm border border-gray-300 rounded px-2 py-1.5 focus:border-purple-500 outline-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500 uppercase">Correo</label>
                  <input type="email" value={formData.correo} onChange={e => setFormData({...formData, correo: e.target.value})} className="w-full text-sm border border-gray-300 rounded px-2 py-1.5 focus:border-purple-500 outline-none" />
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-gray-500 uppercase">Área</label>
                  <input type="text" value={formData.area} onChange={e => setFormData({...formData, area: e.target.value})} className="w-full text-sm border border-gray-300 rounded px-2 py-1.5 focus:border-purple-500 outline-none" />
                </div>
                <div className="space-y-1 md:col-span-2">
                  <label className="text-[10px] font-bold text-gray-500 uppercase">Jefe Directo</label>
                  <input type="text" value={formData.jefe} onChange={e => setFormData({...formData, jefe: e.target.value})} className="w-full text-sm border border-gray-300 rounded px-2 py-1.5 focus:border-purple-500 outline-none" />
                </div>
              </div>
            )}

            {/* MOTIVO DE ESCALAMIENTO */}
            <div className="pt-3 border-t border-purple-200/50">
              <p className="text-xs font-bold text-purple-800 mb-2 flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> INTENCIÓN / RAZÓN DE ESCALAMIENTO
              </p>
              <p className="text-sm text-gray-800 font-medium bg-white/80 p-3 rounded-md border border-purple-100/50 leading-relaxed">
                {aiSession.escalationReason || aiSession.intencion_detectada || 'Soporte General'}
              </p>
            </div>
          </div>
        ) : (
          <div className="bg-gray-50 rounded-2xl border border-gray-200 p-5 shadow-sm flex items-center gap-3">
             <Bot className="w-6 h-6 text-gray-400" />
             <p className="text-sm font-medium text-gray-500">Llamada directa. No hay contexto previo registrado por la IA.</p>
          </div>
        )}

        {/* TRANSCRIPCIÓN */}
        <div className="bg-white rounded-2xl border border-davivienda-gray-200 p-5 shadow-sm h-full max-h-[250px] flex flex-col">
          <div className="flex items-center gap-2 mb-4 border-b pb-3">
            <Sparkles className="w-5 h-5 text-blue-500" />
            <h3 className="font-bold text-gray-900">Transcripción de la IA</h3>
          </div>

          {aiSession?.messages && aiSession.messages.length > 0 ? (
            <div className="space-y-3 overflow-y-auto pr-2 flex-1">
              {aiSession.messages.map((msg, i) => (
                <div key={i} className={clsx('flex gap-2', msg.role === 'user' ? 'justify-end' : 'justify-start')}>
                  {msg.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0 shadow-sm border border-blue-200">
                      <Bot className="w-4 h-4 text-blue-600" />
                    </div>
                  )}
                  <div className={clsx('max-w-[80%] rounded-2xl px-4 py-2.5 text-sm shadow-sm', msg.role === 'user' ? 'bg-red-600 text-white rounded-br-none' : 'bg-gray-100 text-gray-800 border border-gray-200 rounded-bl-none')}>
                    {msg.content}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex-1 flex items-center justify-center flex-col text-gray-400">
              <Bot className={`w-12 h-12 mb-2 ${isConnected ? 'opacity-50 animate-pulse' : 'opacity-20'}`} />
              <p className="text-sm font-medium">Transcripción no disponible.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CallTimer({ startedAt }) {
  const [elapsed, setElapsed] = useState(0);
  useEffect(() => {
    if (!startedAt) return;
    const startMs = new Date(startedAt).getTime();
    setElapsed(Math.max(0, Math.floor((Date.now() - startMs) / 1000)));
    const id = setInterval(() => setElapsed(Math.max(0, Math.floor((Date.now() - startMs) / 1000))), 1000);
    return () => clearInterval(id);
  }, [startedAt]);
  const m = Math.floor(elapsed / 60);
  const s = elapsed % 60;
  return <span className="font-mono tabular-nums">{String(m).padStart(2, '0')}:{String(s).padStart(2, '0')}</span>;
}
