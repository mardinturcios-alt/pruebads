'use client';

import { create } from 'zustand';

export const useAgentStore = create((set, get) => ({
  session: null,
  setSession: (s) => set({
    session: s,
    maxLines: s?.maxLines || 5 // 🚀 Límite por defecto aumentado a 5 líneas simultáneas
  }),

  status: 'offline',
  setStatus: (s) => set({ status: s }),

  sipStatus: 'disconnected',
  setSipStatus: (s) => set({ sipStatus: s }),

  queuedCalls: [],
  setQueuedCalls: (calls) => set({ queuedCalls: calls }),

  incomingCall: null,
  setIncomingCall: (c) => set({ incomingCall: c }),

  maxLines: 5,
  calls: [],
  activeLineId: null,

  // 🚀 CEREBRO MULTILÍNEA SINCRONIZADO
  addCall: (newCall) => set((state) => {
    return {
      calls: [...state.calls, newCall],
      activeLineId: newCall.id, // Enfoca la nueva pestaña automáticamente
      activeCall: newCall,      // Mantiene la UI sincronizada
      status: 'oncall'
    };
  }),

  updateCallStatus: (callId, newStatus) => set((state) => {
    const updatedCalls = state.calls.map(c => c.id === callId ? { ...c, status: newStatus } : c);
    const active = updatedCalls.find(c => c.id === state.activeLineId) || null;
    return { calls: updatedCalls, activeCall: active };
  }),

  removeCall: (callId) => set((state) => {
    const remainingCalls = state.calls.filter(c => c.id !== callId);
    let newActiveLine = state.activeLineId;

    // Si cerramos la pestaña que estábamos viendo, enfocamos la siguiente (si hay)
    if (state.activeLineId === callId) {
      newActiveLine = remainingCalls.length > 0 ? remainingCalls[0].id : null;
    }
    const newActiveCall = remainingCalls.find(c => c.id === newActiveLine) || null;

    return {
      calls: remainingCalls,
      activeLineId: newActiveLine,
      activeCall: newActiveCall,
      status: remainingCalls.length === 0 ? 'available' : 'oncall'
    };
  }),

  switchLine: (callId) => set((state) => ({
    activeLineId: callId,
    activeCall: state.calls.find(c => c.id === callId) || null
  })),

  activeCall: null,
  setActiveCall: (c) => set((state) => ({
    activeCall: c,
    activeLineId: c ? c.id : null // Si la interfaz web cambia el activeCall, también cambia la pestaña
  })),

  reset: () => set({
    session: null, maxLines: 5, status: 'offline', sipStatus: 'disconnected',
    activeCall: null, calls: [], activeLineId: null, queuedCalls: [], incomingCall: null,
  }),
}));
